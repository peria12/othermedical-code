﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace Aurora.RBACService.API.Middleware
{
    public class AdTokenMiddleware
    {
        private readonly RequestDelegate _next;

        public AdTokenMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Check if the Authorization header exists
            if (context.Request.Headers.TryGetValue(CommonConstants.AUTH, out var authorizationHeader))
            {
                var token = authorizationHeader.ToString().Replace(CommonConstants.BEARER, string.Empty);
                GenericResponse<string> genericResponse = new GenericResponse<string>()
                {
                    HasError = true,
                    IsSuccess = false,
                    Message = ResponseMessage.STATUS_AUTHORIZATION_TOKEN_INVALID,
                    StatusCode = StatusCodes.Status401Unauthorized.ToString()
                };

                try
                {
                    var jwtHandler = new JwtSecurityTokenHandler();
                    if (jwtHandler.CanReadToken(token))
                    {
                        var jwtToken = jwtHandler.ReadJwtToken(token);

                        // Validate the expiration time
                        var expClaim = jwtToken.Claims.FirstOrDefault(c => c.Type == JwtRegisteredClaimNames.Exp);
                        if (expClaim != null && long.TryParse(expClaim.Value, out var exp))
                        {
                            var expiryDate = DateTimeOffset.FromUnixTimeSeconds(exp);
                            if (expiryDate <= DateTimeOffset.UtcNow)
                            {
                                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                                await context.Response.WriteAsJsonAsync(genericResponse);
                                return;
                            }
                        }

                        // Add token claims to the HttpContext user
                        var claimsIdentity = new ClaimsIdentity(jwtToken.Claims, CommonConstants.AZUREADBEARER);
                        var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);
                        context.User = claimsPrincipal;
                    }
                    else
                    {
                        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                        await context.Response.WriteAsJsonAsync(genericResponse);
                        return;
                    }
                }
                catch (Exception)
                {
                    context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                    await context.Response.WriteAsJsonAsync(genericResponse);
                    return;
                }
            }

            // Proceed to the next middleware if validation is successful
            await _next(context);
        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class AdTokenMiddlewareExtensions
    {
        public static IApplicationBuilder UseAdTokenMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<AdTokenMiddleware>();
        }
    }
}
