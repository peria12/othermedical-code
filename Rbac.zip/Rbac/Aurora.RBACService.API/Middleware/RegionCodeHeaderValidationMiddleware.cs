﻿namespace Aurora.RBACService.API.Middleware
{
    public class RegionCodeHeaderValidationMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IRegionCodeValidationHelper _regionCodeValidationHelper;

        public RegionCodeHeaderValidationMiddleware(RequestDelegate next, IRegionCodeValidationHelper regionCodeValidationHelper)
        {
            _next = next;
            _regionCodeValidationHelper = regionCodeValidationHelper;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                var validationResponse = _regionCodeValidationHelper.VerifyRegionCodeHeader(context.Request);

                if (validationResponse != null && validationResponse.HasError)
                {
                    context.Response.StatusCode = Convert.ToInt32(ResponseStatusCode.STATUS_NOTFOUND);
                    await context.Response.WriteAsync(validationResponse.Message);
                    return;
                }
                await _next(context);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"An error occured : {ex.Message}");
            }
        }
    }
}
