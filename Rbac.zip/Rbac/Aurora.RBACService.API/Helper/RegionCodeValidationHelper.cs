﻿using Aurora.RBACService.API.Resources;
using System.IdentityModel.Tokens.Jwt;

namespace Aurora.RBACService.API.Helper
{
    [ExcludeFromCodeCoverage]
    public class RegionCodeValidationHelper : IRegionCodeValidationHelper
    {
        public string GetUserIdByToken(HttpRequest request)
        {
            try
            {
                if (!request.Headers.TryGetValue(CommonConstants.AUTH, out var userToken) || !string.IsNullOrEmpty(userToken))
                {
                    userToken = userToken.ToString().Replace("bearer ", string.Empty);
                    userToken = userToken.ToString().Replace("Bearer ", string.Empty);
                    var handler = new JwtSecurityTokenHandler();
                    var token = handler.ReadJwtToken(userToken);
                    var claimsList = token.Claims.ToList();
                    if (claimsList.Any())
                    {
                        return claimsList[0].Value;
                    }
                }
            }
            catch (Exception)
            {
                return "";
            }
            return "";
        }

        public GenericResponse<string> VerifyRegionCodeHeader(HttpRequest request)
        {
            // Validate RegionCode header
            if (!request.Headers.TryGetValue(CommonConstants.HEADERREGIONCODE, out var regionCode) || string.IsNullOrEmpty(regionCode))
            {
                return new GenericResponse<string>
                {
                    IsSuccess = false,
                    HasError = true,
                    StatusCode = ResponseStatus.STATUS_BADREQUEST,
                    Message = Resource.RegionCodeRequired
                };
            }

            // Validate allowed region codes
            if (!RegionCode.AllowedRegionCodes.Contains<string>(regionCode))
            {
                return new GenericResponse<string>
                {
                    IsSuccess = false,
                    HasError = true,
                    StatusCode = ResponseStatus.STATUS_BADREQUEST,
                    Message = ResponseMessage.STATUS_INVALID_REGIONCODE
                };
            }

            // If validation passes
            return new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Result = regionCode
            };
        }
    }
}
