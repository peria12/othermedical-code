﻿namespace Aurora.RBACService.API.Helper
{
    public class ResponseMessageHelper : IResponseMessageHelper
    {
        public GenericResponse<string> GetSuccessResponseMessage(string message = "")
        {
            if (string.IsNullOrEmpty(message))
            {
                message = ResponseMessage.STATUS_DATA_ADDED;
            }
            return GetStatusResponseMessage(ResponseStatusCodes.Success, message);
        }
        public GenericResponse<string> GetSuccessDeletionResponseMessage(string message = "")
        {
            if (string.IsNullOrEmpty(message))
            {
                message = ResponseMessage.STATUS_DATA_DELETED;
            }
            return GetStatusResponseMessage(ResponseStatusCodes.Success, message);
        }
        public GenericResponse<string> GetSuccessUpdationResponseMessage(string message = "")
        {
            if (string.IsNullOrEmpty(message))
            {
                message = ResponseMessage.STATUS_DATA_UPDATED;
            }
            return GetStatusResponseMessage(ResponseStatusCodes.Success, message);
        }
        public GenericResponse<string> GetSuccessCreateResponseMessage(string message = "")
        {
            if (string.IsNullOrEmpty(message))
            {
                message = ResponseMessage.STATUS_DATA_ADDED;
            }
            return GetStatusResponseMessage(ResponseStatusCodes.Success_Create, message);
        }
        public GenericResponse<string> GetRecordCreationFailedResponseMessage(string message = "")
        {
            if (string.IsNullOrEmpty(message))
            {
                message = ValidationMessage.RECORD_CREATION_FAILED;
            }
            return GetFailureResponseMessage(ResponseStatusCodes.Forbidden, message);
        }
        public GenericResponse<string> GetRecordDeletionFailedResponseMessage(string message = "")
        {
            if (string.IsNullOrEmpty(message))
            {
                message = ResponseMessage.STATUS_DATA_DELETE_FAIL;
            }
            return GetFailureResponseMessage(ResponseStatusCodes.Forbidden, message);
        }
        public GenericResponse<string> GetRecordUpdationFailedResponseMessage(string message = "")
        {
            if (string.IsNullOrEmpty(message))
            {
                message = ResponseMessage.STATUS_DATA_UPDATE_FAIL;
            }
            return GetStatusResponseNotSuccessMessage(ResponseStatusCodes.BadRequest, message);
        }
        public GenericResponse<string> GetRecordNotFoundResponseMessage(string message = "")
        {
            if (string.IsNullOrEmpty(message))
            {
                message = ResponseMessage.STATUS_NODATA;
            }
            return GetStatusResponseNotSuccessMessage(ResponseStatusCodes.NotFound, message);
        }
        public GenericResponse<string> GetStatusResponseMessage(ResponseStatusCodes statusCode, string message)
        {
            return new GenericResponse<string>()
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ((int)statusCode).ToString(),
                Message = message
            };
        }

        /// <summary>
        /// Get the Status Response that is no success
        /// </summary>
        /// <param name="statusCode">status code to update in genric respponse</param>
        /// <param name="message">message that will update in generic response</param>
        /// <returns>GenericResponse</returns>
        public GenericResponse<string> GetStatusResponseNotSuccessMessage(ResponseStatusCodes statusCode, string message)
        {
            return new GenericResponse<string>()
            {
                HasError = true,
                IsSuccess = false,
                StatusCode = ((int)statusCode).ToString(),
                Message = message
            };
        }
        public GenericResponse<string> GetFailureResponseMessage(ResponseStatusCodes statusCode, string message)
        {
            return new GenericResponse<string>()
            {
                HasError = true,
                IsSuccess = false,
                StatusCode = ((int)statusCode).ToString(),
                Message = message
            };
        }
        public GenericResponse<string> GetFailureResponseMessage(string message)
        {
            return GetStatusResponseNotSuccessMessage(ResponseStatusCodes.InternalServerError, message);
        }

        public GenericResponse<string> GetErrorResponseMessage(string message)
        {
            return GetStatusResponseNotSuccessMessage(ResponseStatusCodes.Errored, message);
        }
        public GenericResponse<string> GetInternalServerErrorResponseMessage(string message = "")
        {
            if (string.IsNullOrEmpty(message))
            {
                message = ResponseMessage.STATUS_SERVER_ERROR;
            }
            return GetStatusResponseMessage(ResponseStatusCodes.InternalServerError, message);
        }
        public GenericResponse<string> GetRecordAlreadyExistResponseMessage(string message = "")
        {
            if (string.IsNullOrEmpty(message))
            {
                message = ResponseMessage.ALREADY_EXISTS;
            }
            return GetFailureResponseMessage(ResponseStatusCodes.Conflict, message);
        }
    }

    public class ResponseMessageHelper<T> : IResponseMessageHelper<T> where T : class
    {
        public GenericResponseList<T> GetStatusResponseMessage(List<T> resultList, ResponseStatusCodes statusCode, string message)
        {
            return new GenericResponseList<T>()
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ((int)statusCode).ToString(),
                Message = message,
                Result = resultList,
            };
        }
        public GenericResponseList<T> GetFailureStatusResponseMessage(List<T>? resultList, ResponseStatusCodes statusCode, string message)
        {
            return new GenericResponseList<T>()
            {
                HasError = true,
                IsSuccess = false,
                StatusCode = ((int)statusCode).ToString(),
                Message = message,
                Result = resultList,
            };
        }
        public GenericResponse<T> GetRecordFailureStatusResponseMessage(T? result, ResponseStatusCodes statusCode, string message)
        {
            return new GenericResponse<T>()
            {
                HasError = true,
                IsSuccess = false,
                StatusCode = ((int)statusCode).ToString(),
                Message = message,
                Result = result,
            };
        }
        public GenericResponseList<T> GetSuccessResponseMessage(List<T> resultList, ResponseStatusCodes statusCode, string message)
        {
            return new GenericResponseList<T>()
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ((int)statusCode).ToString(),
                Message = message,
                Result = resultList,
            };
        }
        public GenericResponse<T> GetRecordDetailSuccessResponseMessage(T result, ResponseStatusCodes statusCode, string message)
        {
            return new GenericResponse<T>()
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ((int)statusCode).ToString(),
                Message = message,
                Result = result,
            };
        }

        public GenericResponse<T> GetRecordDetailSuccessResponseMessage(T result, string message = "")
        {
            if (string.IsNullOrEmpty(message))
            {
                message = ResponseMessage.STATUS_DATA_FOUND;
            }

            return GetRecordDetailSuccessResponseMessage(result, ResponseStatusCodes.Success, message);
        }

        public GenericResponseList<T> GetRecordsNotFoundResponseMessage(string message = "")
        {
            if (string.IsNullOrEmpty(message))
            {
                message = ResponseMessage.STATUS_NODATA;
            }
            return GetFailureStatusResponseMessage(null, ResponseStatusCodes.RecordNotFound, message);
        }

        public GenericResponse<T> GetRecordNotFoundResponseMessage(string message = "")
        {
            if (string.IsNullOrEmpty(message))
            {
                message = ResponseMessage.STATUS_NODATA;
            }

            return GetRecordFailureStatusResponseMessage(null, ResponseStatusCodes.RecordNotFound, message);
        }

        public GenericResponse<T> GetRecordDetailErrorResponseMessage(string message = "")
        {
            if (string.IsNullOrEmpty(message))
            {
                message = ResponseMessage.STATUS_SERVER_ERROR;
            }

            return GetRecordFailureStatusResponseMessage(null, ResponseStatusCodes.InternalServerError, message);
        }
    }
}
