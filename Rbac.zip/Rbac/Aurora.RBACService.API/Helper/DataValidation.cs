﻿namespace Aurora.RBACService.API.Helper
{
    [ExcludeFromCodeCoverage]
    public class Result<T>
    {
        public bool IsSuccess { get; }
        public T Value { get; }
        public string? ValidationMessage { get; }
        private Result(bool isSuccess, T value, IEnumerable<ValidationError> errors)
        {
            IsSuccess = isSuccess;
            Value = value;
            if (errors?.Any() ?? false)
            {
                var jsonSettings = new JsonSerializerSettings
                {
                    ContractResolver = new DefaultContractResolver
                    {
                        NamingStrategy = new CamelCaseNamingStrategy()
                    }
                };
                ValidationMessage = JsonConvert.SerializeObject(errors, jsonSettings);
            }
        }
        public static Result<T> Success(T value) => new Result<T>(true, value, Enumerable.Empty<ValidationError>());
        public static Result<T> Failure(IEnumerable<ValidationError> errors) => new Result<T>(false, default, errors);
    }

    [ExcludeFromCodeCoverage]
    public class DataValidationResult
    {
        public bool IsValid { get; set; }
        public IEnumerable<ValidationError> Errors { get; set; } = Enumerable.Empty<ValidationError>();
    }

    [ExcludeFromCodeCoverage]
    public class ValidationError
    {
        public string? PropertyName { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
