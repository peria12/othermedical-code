﻿namespace Aurora.RBACService.API.Helper
{
    public interface IResponseMessageHelper
    {
        GenericResponse<string> GetSuccessResponseMessage(string message = "");
        GenericResponse<string> GetSuccessDeletionResponseMessage(string message = "");
        GenericResponse<string> GetSuccessUpdationResponseMessage(string message = "");
        GenericResponse<string> GetSuccessCreateResponseMessage(string message = "");
        GenericResponse<string> GetRecordCreationFailedResponseMessage(string message = "");
        GenericResponse<string> GetRecordDeletionFailedResponseMessage(string message = "");
        GenericResponse<string> GetRecordUpdationFailedResponseMessage(string message = "");
        GenericResponse<string> GetRecordNotFoundResponseMessage(string message = "");
        GenericResponse<string> GetStatusResponseMessage(ResponseStatusCodes statusCode, string message);
        GenericResponse<string> GetFailureResponseMessage(ResponseStatusCodes statusCode, string message);
        GenericResponse<string> GetFailureResponseMessage(string message);
        GenericResponse<string> GetErrorResponseMessage(string message);
        GenericResponse<string> GetInternalServerErrorResponseMessage(string message = "");
        GenericResponse<string> GetRecordAlreadyExistResponseMessage(string message = "");

    }
    public interface IResponseMessageHelper<T> where T : class
    {
        GenericResponseList<T> GetStatusResponseMessage(List<T> resultList, ResponseStatusCodes statusCode, string message);
        GenericResponseList<T> GetFailureStatusResponseMessage(List<T> resultList, ResponseStatusCodes statusCode, string message);
        GenericResponse<T> GetRecordFailureStatusResponseMessage(T result, ResponseStatusCodes statusCode, string message);
        GenericResponseList<T> GetSuccessResponseMessage(List<T> resultList, ResponseStatusCodes statusCode, string message);
        GenericResponse<T> GetRecordDetailSuccessResponseMessage(T result, ResponseStatusCodes statusCode, string message);
        GenericResponseList<T> GetRecordsNotFoundResponseMessage(string message = "");
        GenericResponse<T> GetRecordNotFoundResponseMessage(string message = "");
        GenericResponse<T> GetRecordDetailSuccessResponseMessage(T result, string message = "");
        GenericResponse<T> GetRecordDetailErrorResponseMessage(string message = "");
    }
}
