﻿namespace Aurora.RBACService.API.Helper
{
    public interface IRegionCodeValidationHelper
    {
        public string GetUserIdByToken(HttpRequest request);

        public GenericResponse<string> VerifyRegionCodeHeader(HttpRequest request);
    }
}
