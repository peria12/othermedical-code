﻿namespace Aurora.RBACService.API.Filters
{
    public class ValidationFilterAttribute : IActionFilter
    {
        public ValidationFilterAttribute() { }
        public void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext != null)
            {
                var headerErrors = ValidateHeaders(filterContext.HttpContext.Request.Headers, filterContext.HttpContext.Response.Headers);
                if (!string.IsNullOrEmpty(headerErrors))
                {
                    filterContext.HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                    filterContext.Result = new JsonResult(ResponseStatusCode.STATUS_BADREQUEST)
                    {
                        Value = new GenericResponse<string>
                        {
                            HasError = true,
                            IsSuccess = false,
                            Message = headerErrors,//TODO Translate // NOSONAR
                            MessageType = CommonConstants.ERROR,
                            StatusCode = ResponseStatusCode.STATUS_BADREQUEST,
                        },
                    };
                    return;
                }
                if (!filterContext.ModelState.IsValid)
                {
                    var response = new GenericResponse<string>
                    {
                        HasError = true,
                        IsSuccess = false,
                        Message = ModelValidationError(filterContext),
                        MessageType = CommonConstants.VALIDATION,
                        StatusCode = ResponseStatusCode.STATUS_BADREQUEST
                    };

                    filterContext.HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                    filterContext.Result = new JsonResult(response);
                    return;
                }
            }
        }
        public void OnActionExecuted(ActionExecutedContext filterContext)
        {
        }
        private string ModelValidationError(ActionExecutingContext context)
        {
            Dictionary<string, string> errorMessages = context.ModelState
              .SelectMany(ms => ms.Value!.Errors.Select(e => new
              {
                  ms.Key,
                  e.ErrorMessage
              })).ToDictionary(s => s.Key, s => s.ErrorMessage);

            string jsonVal = errorMessages.SerializeWithCamelCase();
            return jsonVal;
        }
        private string? ValidateHeaders(IHeaderDictionary requestHeaders, IHeaderDictionary responseHeaders)
        {
            string? message = string.Empty;

            string? regioncode = requestHeaders[CommonConstants.HEADERREGIONCODE];
            if (string.IsNullOrEmpty(regioncode))
            {
                message = CommonConstants.ERROR_HEADER_REGION_CODE_MISSING;
                return message;
            }

            //Correlation ID check
            string? correlationId = requestHeaders[CommonConstants.HEADERCORRELATIONID]
                    .FirstOrDefault<string>();
            if (string.IsNullOrEmpty(correlationId))
            {
                correlationId = Guid.NewGuid().ToString();
                requestHeaders[CommonConstants.HEADERCORRELATIONID] = correlationId;
                responseHeaders[CommonConstants.HEADERCORRELATIONID] = correlationId;
            }
            return message;
        }
    }
}
