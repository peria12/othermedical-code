﻿using System.Security.Cryptography;

namespace Aurora.RBACService.API.Extensions
{
    [ExcludeFromCodeCoverage]
    public static class StringExtension
    {
        public static string MaskMobileNumber(this string mobileNumber)
        {
            if (string.IsNullOrEmpty(mobileNumber) || mobileNumber.Length < 4)
                return "****";

            return "**** " + mobileNumber.Substring(mobileNumber.Length - 4);
        }

        public static string MaskEmailAddress(this string email)
        {
            if (string.IsNullOrEmpty(email))
                return "****@****";

            var emailParts = email.Split('@');
            if (emailParts.Length != 2 || emailParts[0].Length < 4)
                return "****@" + emailParts[1];

            return emailParts[0].Substring(0, 3) + "****@" + emailParts[1];
        }
        public static string GenerateOTP()
        {
            return RandomNumberGenerator.GetInt32(100000, 1000000).ToString();
        }
    }
}
