﻿namespace Aurora.RBACService.API.Extensions
{
    /// <summary>
    /// Configuration Azure key vault
    /// </summary>
    public static class AzureKeyVaultConfiguration
    {
        public static IConfigurationBuilder ConfigureAzureKeyVault(this IConfigurationBuilder config)
        {
            IConfigurationRoot root = config.Build();

            //Retrieve the KeyVault URI and Identity Client ID from the configuration.
            if (Convert.ToBoolean(root.GetSection(CommonConstants.ISKEYVAULTCONFIGURED).Value))
            {
                var keyVaultUri = root[CommonConstants.AZUREKEYVAULTURI];
                var identityClientId = root[CommonConstants.AZUREIDENTITYCLIENTID];

                var credentialOptions = new DefaultAzureCredentialOptions
                {
                    ExcludeSharedTokenCacheCredential = true,
                    ManagedIdentityClientId = identityClientId
                };

                var credential = new DefaultAzureCredential(credentialOptions);
                var keyVaultClient = new SecretClient(new Uri(keyVaultUri), credential);

                config.AddAzureKeyVault(keyVaultClient, new KeyVaultSecretManager());
            }
            return config;
        }
    }
}
