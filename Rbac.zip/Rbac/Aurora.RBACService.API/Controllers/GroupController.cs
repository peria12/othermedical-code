﻿namespace Aurora.RBACService.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GroupController : AuroraBaseController
    {
        private readonly IGroupCommandService _groupCommandService;
        private readonly IGroupQueryService _groupQueryService;

        public GroupController(IHttpContextAccessor httpContextAccessor,
            IGroupCommandService groupCommandService, IGroupQueryService groupQueryService)
           : base(httpContextAccessor)
        {
            _groupCommandService = groupCommandService;
            _groupQueryService = groupQueryService;
        }

        [HttpGet("GetGroup")]
        public async Task<ActionResult<CrossCutting.GenericResponse.GenericResponse<GetGroupDto>>> GetGroup([FromQuery] short roleId)
        {
            var result = await _groupQueryService.GetGroup(roleId);
            var apiResponse = ReturnGetResponse(result);

            return Ok(apiResponse);
        }

        [HttpGet("GetActiveGroupsList")]
        public async Task<ActionResult<CrossCutting.GenericResponse.GenericResponseList<GetGroupListDto>>> GetActiveGroupsList()
        {
            var result = await _groupQueryService.GetActiveGroupsList();
            var apiResponse = ReturnGetListResponse(result);

            return Ok(apiResponse);
        }

        [HttpGet("GetGroupPagedList")]
        public async Task<ActionResult<GenericResponsePagedList<GetGroupListDto>>> GetGroupPagedList(PaginationQuery pagination)
        {
            var result = await _groupQueryService.GetGroupPagedList(pagination);
            var apiResponse = ReturnGetPagedListResponse(result, pagination);

            return Ok(apiResponse);
        }

        [HttpPost("CreateGroup")]
        public async Task<ActionResult<GenericResponse2<short>>> CreateGroup([FromBody] CreateGroupDto group)
        {
            var result = await _groupCommandService.CreateGroup(group);
            var apiResponse = ReturnChangeResponse<short>(CrudType.Create, result.Value, !result.IsSuccess, result.ValidationMessage);

            return result.IsSuccess ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [HttpPut("EditGroup")]
        public async Task<ActionResult<GenericResponse2<bool>>> EditGroup([FromBody] EditGroupDto group)
        {
            var result = await _groupCommandService.EditGroup(group);
            var apiResponse = ReturnChangeResponse<bool>(CrudType.Edit, result.Value, !result.IsSuccess, result.ValidationMessage);

            return result.IsSuccess ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [HttpPost("UpdateUserGroupLink")]
        public async Task<ActionResult<GenericResponse2<bool>>> UpdateUserGroupLink([FromBody] UserGroupLinkDto link)
        {
            var result = await _groupCommandService.UpdateUserGroupLink(link);
            var apiResponse = ReturnChangeResponse<bool>(CrudType.Others, result);

            return Ok(apiResponse);
        }
    }
}
