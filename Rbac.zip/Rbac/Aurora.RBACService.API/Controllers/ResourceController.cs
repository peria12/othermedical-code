﻿namespace Aurora.RBACService.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResourceController : AuroraBaseController
    {
        private readonly IResourceQueryService _resourceQueryService;

        public ResourceController(IHttpContextAccessor httpContextAccessor,
            IResourceQueryService resourceQueryService)
           : base(httpContextAccessor)
        {
            _resourceQueryService = resourceQueryService;
        }

        [HttpGet("GetRoleResources")]
        public async Task<ActionResult<CrossCutting.GenericResponse.GenericResponse<GetRoleResourceDto>>> GetRoleResources([FromQuery] string groupType, [FromQuery] short? roleId)
        {
            var result = await _resourceQueryService.GetRoleResources(groupType, roleId);
            var apiResponse = ReturnGetResponse(result);

            return Ok(apiResponse);

        }

        [HttpGet("GetUserResourcesByGroup")]
        public async Task<ActionResult<CrossCutting.GenericResponse.GenericResponseList<GetUserResourceDto>>> GetUserResourcesByGroup([FromQuery] string groupName)
        {
            var result = await _resourceQueryService.GetUserResourcesByGroup(groupName);
            var apiResponse = ReturnGetListResponse(result);

            return Ok(apiResponse);
        }

        [HttpGet("GetUserResourcesBySubGroup")]
        public async Task<ActionResult<CrossCutting.GenericResponse.GenericResponseList<GetUserResourceDto>>> GetUserResourcesBySubGroup([FromQuery] string groupName, [FromQuery] string subGroupName)
        {
            var result = await _resourceQueryService.GetUserResourcesBySubGroup(groupName, subGroupName);
            var apiResponse = ReturnGetListResponse(result);

            return Ok(apiResponse);
        }

        [HttpGet("HasUserResourceAccess")]
        public async Task<ActionResult<GenericResponse2<bool>>> HasUserResourceAccess([FromQuery] string resourceName)
        {
            var result = await _resourceQueryService.HasUserResourceAccess(resourceName);
            var apiResponse = ReturnResponse<bool>(result, CommonConstants.SUCCESS);

            return Ok(apiResponse);
        }

        [HttpGet("CacheRoleResourceMatrix")]
        public async Task<ActionResult<GenericResponse2<bool>>> CacheRoleResourceMatrix()
        {
            var result = await _resourceQueryService.CacheRoleResourceMatrix();
            var apiResponse = ReturnResponse<bool>(result, CommonConstants.SUCCESS);

            return Ok(apiResponse);
        }

        [HttpGet("ClearRoleResourceMatrixCache")]
        public async Task<ActionResult<GenericResponse2<bool>>> ClearRoleResourceMatrixCache()
        {
            var result = await _resourceQueryService.ClearRoleResourceMatrixCache();
            var apiResponse = ReturnResponse<bool>(result, CommonConstants.SUCCESS);

            return Ok(apiResponse);
        }
    }
}
