﻿namespace Aurora.RBACService.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : AuroraBaseController
    {
        private readonly IRoleCommandService _roleCommandService;
        private readonly IRoleQueryService _roleQueryService;

        public RoleController(IHttpContextAccessor httpContextAccessor,
            IRoleCommandService roleCommandService,
            IRoleQueryService roleQueryService)
           : base(httpContextAccessor)
        {
            _roleCommandService = roleCommandService;
            _roleQueryService = roleQueryService;
        }

        [HttpGet("GetRole")]
        public async Task<ActionResult<CrossCutting.GenericResponse.GenericResponse<GetRoleDto>>> GetRole([FromQuery] short roleId)
        {
            var result = await _roleQueryService.GetRole(roleId);
            var apiResponse = ReturnGetResponse(result);

            return Ok(apiResponse);
        }

        [HttpGet("GetActiveRolesList")]
        public async Task<ActionResult<CrossCutting.GenericResponse.GenericResponseList<GetRoleListDto>>> GetActiveRolesList()
        {
            var result = await _roleQueryService.GetActiveRolesList();
            var apiResponse = ReturnGetListResponse(result);

            return Ok(apiResponse);
        }

        [HttpGet("GetRolePagedList")]
        public async Task<ActionResult<GenericResponsePagedList<GetRoleListDto>>> GetRolePagedList(PaginationQuery pagination)
        {
            var result = await _roleQueryService.GetRolePagedList(pagination);
            var apiResponse = ReturnGetPagedListResponse(result, pagination);

            return Ok(apiResponse);
        }

        [HttpPost("CreateRole")]
        public async Task<ActionResult<GenericResponse2<short>>> CreateRole([FromBody] CreateRoleDto role)
        {
            var result = await _roleCommandService.CreateRole(role);
            var apiResponse = ReturnChangeResponse<short>(CrudType.Create, result.Value, !result.IsSuccess, result.ValidationMessage);

            return result.IsSuccess ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [HttpPut("EditRole")]
        public async Task<ActionResult<GenericResponse2<bool>>> EditRole([FromBody] EditRoleDto role)
        {
            var result = await _roleCommandService.EditRole(role);
            var apiResponse = ReturnChangeResponse<bool>(CrudType.Edit, result.Value, !result.IsSuccess, result.ValidationMessage);

            return result.IsSuccess ? Ok(apiResponse) : BadRequest(apiResponse);
        }
    }
}
