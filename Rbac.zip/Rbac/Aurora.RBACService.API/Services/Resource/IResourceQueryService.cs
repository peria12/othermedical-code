﻿namespace Aurora.RBACService.API.Services.Resource
{
    public interface IResourceQueryService
    {
        Task<GetRoleResourceDto> GetRoleResources(string groupType, short? roleId);
        Task<List<string>> GetResourceNames(List<long> resourceIds);
        Task<List<GetUserResourceDto>> GetUserResourcesByGroup(string groupName);
        Task<List<GetUserResourceDto>> GetUserResourcesBySubGroup(string groupName, string subGroupName);
        Task<bool> HasUserResourceAccess(string resourceName);
        Task<bool> CacheRoleResourceMatrix();
        Task<bool> ClearRoleResourceMatrixCache();
    }
}
