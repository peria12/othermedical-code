﻿namespace Aurora.RBACService.API.Services.Resource
{
    [ExcludeFromCodeCoverage]
    public class ResourceQueryService : IResourceQueryService
    {
        private readonly ReadOnlyDbContext _readOnlyDbContext;
        private readonly ICommonService _commonService;
        private readonly IRedisCacheEnterpriseService _cacheService;

        public ResourceQueryService(ReadOnlyDbContext readOnlyDbContext,
            IRedisCacheEnterpriseService cacheService,
            ICommonService commonService)
        {
            _commonService = commonService;
            _readOnlyDbContext = readOnlyDbContext;
            _cacheService = cacheService;
        }

        public async Task<bool> CacheRoleResourceMatrix()
        {
            await ClearRoleResourceMatrixCache();
            var allRolesResources = await (from rm in _readOnlyDbContext.RoleResourceMasterMappings
                                           join rs in _readOnlyDbContext.ResourceMasters
                                            on rm.ResourceName equals rs.ResourceName
                                           where !rs.IsDeleted && !rm.IsDeleted
                                           select new RoleResourceMatrixDto
                                           {
                                               RoleId = rm.RoleId,
                                               ResourceName = rs.ResourceName,
                                               GroupType = rs.GroupType,
                                               GroupName = rs.GroupName,
                                               SubGroupName = rs.SubGroupName
                                           }).ToListAsync();

            var childResources = await (from rm in _readOnlyDbContext.RoleResourceMasterMappings
                                        join rs in _readOnlyDbContext.ResourceMasters
                                         on rm.ResourceName equals rs.ResourceName
                                        join drs in _readOnlyDbContext.DependentResources on rm.Id equals drs.ParentId
                                        join crs in _readOnlyDbContext.ResourceMasters on drs.ResourceId equals crs.Id
                                        where !rs.IsDeleted && !rm.IsDeleted
                                        select new RoleResourceMatrixDto
                                        {
                                            RoleId = rm.RoleId,
                                            ResourceName = crs.ResourceName,
                                            GroupType = crs.GroupType,
                                            GroupName = crs.GroupName,
                                            SubGroupName = crs.SubGroupName
                                        }).ToListAsync();

            if (allRolesResources == null)
                allRolesResources = new List<RoleResourceMatrixDto>();
            if (childResources?.Count > 0)
            {
                allRolesResources.AddRange(childResources);
            }

            _ = Task.Run(() => CacheRoleResourcesMatrixAsync(allRolesResources));

            return true;
        }

        public async Task<bool> ClearRoleResourceMatrixCache()
        {
            var key = $"{_commonService.GetRegionCode()}:rbac:rolematrix";
            return await _cacheService.DeleteSingleAsync(key);
        }

        public async Task<List<string>> GetResourceNames(List<long> resourceIds)
        {
            return await (from rm in _readOnlyDbContext.ResourceMasters
                          join id in resourceIds on rm.Id equals id
                          select rm.ResourceName
                          ).ToListAsync();
        }

        public async Task<GetRoleResourceDto> GetRoleResources(string groupType, short? roleId)
        {
            var roleResource = new GetRoleResourceDto();
            if (roleId != null)
            {
                var role = await _readOnlyDbContext.Roles.FindAsync(roleId.Value);
                if (role != null)
                {
                    roleResource.RoleId = role.Id;
                    roleResource.RoleName = role.RoleName;
                    roleResource.RoleDescription = role.RoleDescription;
                    roleResource.IsDeleted = role.IsDeleted;
                }
            }

            //Note prepare hierarcy for BE/FE            
            roleResource.Resources = new List<ResourceHierarchyDto>();

            return roleResource;
        }

        public async Task<List<GetUserResourceDto>> GetUserResourcesByGroup(string groupName)
        {
            // Step 1: Try to get from Redis cache
            var cachedResources = await GetUserResourcesByGroupAsync(groupName);
            if (cachedResources != null && cachedResources.Count != 0)
            {
                return cachedResources;
            }

            // Step 2: Fallback to database query
            int userId = _commonService.GetLoggedUserId();
            var userResources = from up in _readOnlyDbContext.UserProfiles
                                join rg in _readOnlyDbContext.GroupRoleMappings on up.GroupId equals rg.GroupId
                                join rm in _readOnlyDbContext.RoleResourceMasterMappings on rg.RoleId equals rm.RoleId
                                join rs in _readOnlyDbContext.ResourceMasters on rm.ResourceName equals rs.ResourceName
                                where up.UserId == userId && rs.GroupName == groupName
                                      && !rs.IsDeleted && !rm.IsDeleted && !rg.IsDeleted && !up.IsDeleted
                                select new GetUserResourceDto
                                {
                                    ResourceName = rs.ResourceName,
                                    SubGroupName = rs.SubGroupName
                                };

            var result = await userResources.Distinct().ToListAsync();

            // Step 3: Refresh the cache in background (non-blocking)
            _ = Task.Run(() => CacheRoleResourceMatrix()); // fire-and-forget; log if needed

            return result;
        }

        public async Task<List<GetUserResourceDto>> GetUserResourcesBySubGroup(string groupName, string subGroupName)
        {
            // Step 1: Try to get from Redis cache
            var cachedResources = await GetUserResourcesByGroupAsync(groupName, subGroupName);
            if (cachedResources != null && cachedResources.Count != 0)
            {
                return cachedResources;
            }

            // Step 2: Fallback to database query
            int userId = _commonService.GetLoggedUserId();
            var userResources = from up in _readOnlyDbContext.UserProfiles
                                join rg in _readOnlyDbContext.GroupRoleMappings on up.GroupId equals rg.GroupId
                                join rm in _readOnlyDbContext.RoleResourceMasterMappings on rg.RoleId equals rm.Id
                                join rs in _readOnlyDbContext.ResourceMasters on rm.ResourceName equals rs.ResourceName
                                where up.UserId == userId && rs.GroupName == groupName && rs.SubGroupName == subGroupName
                                    && !rs.IsDeleted && !rm.IsDeleted && !rg.IsDeleted && !up.IsDeleted
                                select new GetUserResourceDto
                                {
                                    ResourceName = rs.ResourceName,
                                    SubGroupName = rs.SubGroupName
                                };

            var result = await userResources.Distinct().ToListAsync();

            // Step 3: Refresh the cache in background (non-blocking)
            _ = Task.Run(() => CacheRoleResourceMatrix()); // fire-and-forget; log if needed

            return result;
        }

        public async Task<bool> HasUserResourceAccess(string resourceName)
        {
            int userId = _commonService.GetLoggedUserId();
            var userResources = from up in _readOnlyDbContext.UserProfiles
                                join rg in _readOnlyDbContext.GroupRoleMappings on up.GroupId equals rg.GroupId
                                join rm in _readOnlyDbContext.RoleResourceMasterMappings on rg.RoleId equals rm.Id
                                where up.UserId == userId && rm.ResourceName == resourceName
                                 && !rm.IsDeleted && !rg.IsDeleted && !up.IsDeleted
                                select rm;

            return await userResources.AnyAsync();
        }

        private async Task CacheRoleResourcesMatrixAsync(List<RoleResourceMatrixDto> allRolesResources)
        {
            var key = $"{_commonService.GetRegionCode()}:rbac:rolematrix";
            var expiry = TimeSpan.FromHours(24);
            await _cacheService.SetListAsync(key, allRolesResources, expiry);
        }

        private async Task<List<GetUserResourceDto>> GetUserResourcesByGroupAsync(string groupName, string? subGroupName = null)
        {
            var roles = _commonService.GetLoggedUserRoles();
            var key = $"{_commonService.GetRegionCode()}:rbac:rolematrix";

            if (roles == null || roles.Count == 0)
                return new List<GetUserResourceDto>();

            // Build OR condition for roleId filter
            var roleFilter = string.Join(" || ", roles.Select(r => $"@.RoleId == {r}"));

            // Build full JSONPath condition dynamically
            string jsonPath;
            if (!string.IsNullOrWhiteSpace(subGroupName))
            {
                jsonPath = $"$[?(@.GroupName == '{groupName}' && @.SubGroupName == '{subGroupName}' && ({roleFilter}))]";
            }
            else
            {
                jsonPath = $"$[?(@.GroupName == '{groupName}' && ({roleFilter}))]";
            }

            var matchingItems = await _cacheService.GetListAsync<RoleResourceMatrixDto>(key, jsonPath);

            if (matchingItems == null || matchingItems.Count == 0)
                return new List<GetUserResourceDto>();

            return matchingItems.Select(x => new GetUserResourceDto
            {
                SubGroupName = x.SubGroupName,
                ResourceName = x.ResourceName
            }).ToList();
        }
    }
}
