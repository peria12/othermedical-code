﻿namespace Aurora.RBACService.API.Services.Resource.Dto
{
    public class GetRoleResourceDto
    {
        public short? RoleId { get; set; }
        public string? RoleName { get; set; }
        public string? RoleDescription { get; set; }
        public bool IsDeleted { get; set; }
        public List<ResourceHierarchyDto>? Resources { get; set; }
    }
}
