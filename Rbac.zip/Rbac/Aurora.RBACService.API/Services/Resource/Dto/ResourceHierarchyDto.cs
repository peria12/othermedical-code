﻿namespace Aurora.RBACService.API.Services.Resource.Dto
{
    [ExcludeFromCodeCoverage]
    public class ResourceHierarchyDto
    {
        public long ResourceId { get; set; }
        public required string ResourceType { get; set; }
        public required string ResourceName { get; set; }
        public required string Display { get; set; }
        public long? ParentId { get; set; }
        public bool IsSelected { get; set; }
        public List<ResourceHierarchyDto>? Resources { get; set; }
    }
}
