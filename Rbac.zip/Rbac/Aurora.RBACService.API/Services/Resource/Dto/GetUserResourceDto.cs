﻿namespace Aurora.RBACService.API.Services.Resource.Dto
{
    public class GetUserResourceDto
    {
        public required string SubGroupName { get; set; }
        public required string ResourceName { get; set; }
    }
}
