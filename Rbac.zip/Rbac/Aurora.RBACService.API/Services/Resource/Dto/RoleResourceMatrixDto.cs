﻿namespace Aurora.RBACService.API.Services.Resource.Dto
{
    [ExcludeFromCodeCoverage]
    public class RoleResourceMatrixDto
    {
        public short RoleId { get; set; }
        public required string ResourceName { get; set; }
        public required string GroupType { get; set; }
        public required string GroupName { get; set; }
        public required string SubGroupName { get; set; }
    }
}
