﻿namespace Aurora.RBACService.API.Services.Role
{
    public interface IRoleQueryService
    {
        Task<GetRoleDto> GetRole(short id);
        Task<Domain.Entities.RBAC.Role?> GetRoleEntity(short id);
        Task<List<RoleResourceMasterMapping>> GetRoleResourceMapEntities(short roleId);
        Task<List<GetRoleListDto>> GetActiveRolesList();
        Task<PaginationResult<GetRoleListDto>> GetRolePagedList(PaginationQuery pagination);
        Task<DataValidationResult> ValidateCreateInputAsync(CreateRoleDto input);
        Task<DataValidationResult> ValidateEditInputAsync(EditRoleDto input);
        Task<List<RoleResourceMatrixDto>> GetRoleResourceMatrixByRoleIdAsync(short roleId);
    }
}
