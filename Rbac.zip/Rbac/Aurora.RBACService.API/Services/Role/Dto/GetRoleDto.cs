﻿namespace Aurora.RBACService.API.Services.Role.Dto
{
    public class GetRoleDto
    {
        public short Id { get; set; }
        public required string RoleName { get; set; }
        public string? RoleDescription { get; set; }
        public bool IsDeleted { get; set; }
    }
}
