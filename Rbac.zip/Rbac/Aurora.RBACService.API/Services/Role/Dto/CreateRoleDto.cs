﻿namespace Aurora.RBACService.API.Services.Role.Dto
{
    public class CreateRoleDto
    {
        [MaxLength(50, ErrorMessage = "RoleName has maximum length of 50 characters.")]
        [Required(ErrorMessage = "RoleName is mandatory.")]
        public required string RoleName { get; set; }

        [MaxLength(200, ErrorMessage = "RoleDescription has maximum length of 200 characters.")]
        public string? RoleDescription { get; set; }

        public bool? IsDeleted { get; set; } = false;

        public List<long>? ResourceIds { get; set; }
    }
}
