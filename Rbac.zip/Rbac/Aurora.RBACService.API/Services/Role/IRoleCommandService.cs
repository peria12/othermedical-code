﻿namespace Aurora.RBACService.API.Services.Role
{
    public interface IRoleCommandService
    {
        Task<Result<short>> CreateRole(CreateRoleDto role);
        Task<Result<bool>> EditRole(EditRoleDto role);
    }
}
