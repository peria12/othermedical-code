﻿namespace Aurora.RBACService.API.Services.Role
{
    [ExcludeFromCodeCoverage]
    public class RoleCommandService : IRoleCommandService
    {
        private readonly ReadWriteDbContext _readWriteDbContext;
        private readonly ICommonService _commonService;
        private readonly IRoleQueryService _roleQueryService;
        private readonly IResourceQueryService _resourceQueryService;
        private readonly IMapper _mapper;
        private readonly IRedisCacheEnterpriseService _cacheService;

        public RoleCommandService(ReadWriteDbContext readWriteDbContext,
            ICommonService commonService,
            IRoleQueryService roleQueryService,
            IResourceQueryService resourceQueryService,
            IMapper mapper,
            IRedisCacheEnterpriseService cacheService)
        {
            _commonService = commonService;
            _readWriteDbContext = readWriteDbContext;
            _roleQueryService = roleQueryService;
            _resourceQueryService = resourceQueryService;
            _mapper = mapper;
            _cacheService = cacheService;
        }

        public async Task<Result<short>> CreateRole(CreateRoleDto role)
        {
            var validationResult = await _roleQueryService.ValidateCreateInputAsync(role);
            if (!validationResult.IsValid)
                return Result<short>.Failure(validationResult.Errors);

            short createdRoleId;

            using var transaction = await _readWriteDbContext.Database.BeginTransactionAsync();
            try
            {
                createdRoleId = await InsertRoleEntityAsync(role);

                if (role.ResourceIds?.Count == 0)
                {
                    await InsertRoleResourceMappingsAsync(createdRoleId, role.ResourceIds);
                }

                await transaction.CommitAsync();
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }

            _ = Task.Run(() => UpdateRedisRoleMatrixAsync(createdRoleId, isEdit: false));

            return Result<short>.Success(createdRoleId);
        }

        private async Task<short> InsertRoleEntityAsync(CreateRoleDto role)
        {
            var entity = _mapper.Map<Domain.Entities.RBAC.Role>(role);
            entity.CreatedDate = DateTime.UtcNow;
            entity.CreatedBy = _commonService.GetLoggedUserName();

            await _readWriteDbContext.Roles.AddAsync(entity);
            await _readWriteDbContext.SaveChangesAsync();

            return entity.Id;
        }

        private async Task InsertRoleResourceMappingsAsync(short roleId, List<long>? resourceIds)
        {
            if (resourceIds == null || resourceIds.Count == 0)
                return;

            var username = _commonService.GetLoggedUserName();
            var utcNow = DateTime.UtcNow;
            var resourceNames = await _resourceQueryService.GetResourceNames(resourceIds);

            var roleResourceMapInsertList = resourceNames.Select(resourceName => new RoleResourceMasterMapping
            {
                RoleId = roleId,
                ResourceName = resourceName,
                CreatedBy = username,
                CreatedDate = utcNow
            }).ToList();

            await _readWriteDbContext.RoleResourceMasterMappings.AddRangeAsync(roleResourceMapInsertList);
            await _readWriteDbContext.SaveChangesAsync();
        }


        public async Task<Result<bool>> EditRole(EditRoleDto role)
        {
            var entity = await _roleQueryService.GetRoleEntity(role.Id);
            if (entity == null)
                return Result<bool>.Success(false);

            var validationResult = await _roleQueryService.ValidateEditInputAsync(role);
            if (!validationResult.IsValid)
                return Result<bool>.Failure(validationResult.Errors);

            using var transaction = await _readWriteDbContext.Database.BeginTransactionAsync();
            try
            {
                var username = _commonService.GetLoggedUserName();
                var utcNow = DateTime.UtcNow;

                var updatedEntity = _mapper.Map(role, entity);
                updatedEntity.UpdatedDate = utcNow;
                updatedEntity.UpdatedBy = username;

                _readWriteDbContext.Roles.Update(updatedEntity);
                await _readWriteDbContext.SaveChangesAsync();

                if (role.ResourceIds?.Count > 0)
                {
                    await HandleRoleResourceMappingsAsync(updatedEntity.Id, role.ResourceIds, username, utcNow);
                }

                await transaction.CommitAsync();
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }

            _ = Task.Run(() => UpdateRedisRoleMatrixAsync(role.Id, isEdit: true));
            return Result<bool>.Success(true);
        }

        private async Task HandleRoleResourceMappingsAsync(short roleId, List<long> resourceIds, string username, DateTime utcNow)
        {
            var existingMappings = await _roleQueryService.GetRoleResourceMapEntities(roleId);
            var resourceNames = await _resourceQueryService.GetResourceNames(resourceIds);

            if (existingMappings?.Count == 0)
            {
                var newMappings = resourceNames.Select(name => new RoleResourceMasterMapping
                {
                    RoleId = roleId,
                    ResourceName = name,
                    CreatedBy = username,
                    CreatedDate = utcNow
                });

                await _readWriteDbContext.RoleResourceMasterMappings.AddRangeAsync(newMappings);
                await _readWriteDbContext.SaveChangesAsync();
                return;
            }

            UpdateExistingRoleResourceMappings(existingMappings, resourceNames, username, utcNow);

            var additionalMappings = GetNewResourceMappings(roleId, resourceNames, existingMappings, username, utcNow);
            if (additionalMappings.Count > 0)
            {
                await _readWriteDbContext.RoleResourceMasterMappings.AddRangeAsync(additionalMappings);
            }

            await _readWriteDbContext.SaveChangesAsync();
        }

        private void UpdateExistingRoleResourceMappings(List<RoleResourceMasterMapping> existingMappings, List<string> resourceNames, string username, DateTime utcNow)
        {
            var toUpdate = existingMappings
                .Where(em => resourceNames.Contains(em.ResourceName) && em.IsDeleted)
                .ToList();

            foreach (var mapping in toUpdate)
            {
                mapping.IsDeleted = false;
                mapping.UpdatedBy = username;
                mapping.UpdatedDate = utcNow;
            }

            if (toUpdate.Count > 0)
                _readWriteDbContext.RoleResourceMasterMappings.UpdateRange(toUpdate);
        }
        private static List<RoleResourceMasterMapping> GetNewResourceMappings(short roleId, List<string> resourceNames, List<RoleResourceMasterMapping> existingMappings, string username, DateTime utcNow)
        {
            var existingNames = existingMappings.Select(x => x.ResourceName).ToHashSet();

            return resourceNames
                .Where(name => !existingNames.Contains(name))
                .Select(name => new RoleResourceMasterMapping
                {
                    RoleId = roleId,
                    ResourceName = name,
                    CreatedBy = username,
                    CreatedDate = utcNow
                })
                .ToList();
        }

        private async Task UpdateRedisRoleMatrixAsync(short roleId, bool isEdit = false)
        {
            var roleMatrixes = await _roleQueryService.GetRoleResourceMatrixByRoleIdAsync(roleId);
            var key = $"{_commonService.GetRegionCode()}:rbac:rolematrix";


            if (isEdit)
            {
                var jsonPath = $"$[?(@.RoleId == {roleId})]";
                await _cacheService.DeleteByJsonPathAsync(key, jsonPath);
            }

            foreach (RoleResourceMatrixDto roleResourceMatrixDto in roleMatrixes)
            {
                _ = _cacheService.AddToJsonListAsync(key, roleResourceMatrixDto);
            }
        }
    }
}
