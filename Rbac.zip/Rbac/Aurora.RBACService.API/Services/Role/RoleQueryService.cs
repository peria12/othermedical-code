﻿namespace Aurora.RBACService.API.Services.Role
{
    [ExcludeFromCodeCoverage]
    public class RoleQueryService : IRoleQueryService
    {
        private readonly ReadOnlyDbContext _readOnlyDbContext;
        private readonly IMapper _mapper;

        public RoleQueryService(ReadOnlyDbContext readOnlyDbContext,
            IMapper mapper)
        {
            _readOnlyDbContext = readOnlyDbContext;
            _mapper = mapper;
        }

        public async Task<GetRoleDto> GetRole(short id)
        {
            var role = await _readOnlyDbContext.Roles.FindAsync(id);
            return _mapper.Map<GetRoleDto>(role);
        }

        public async Task<Domain.Entities.RBAC.Role?> GetRoleEntity(short id)
        {
            return await _readOnlyDbContext.Roles.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<RoleResourceMasterMapping>> GetRoleResourceMapEntities(short roleId)
        {
            return await _readOnlyDbContext.RoleResourceMasterMappings
                .Where(x => x.RoleId == roleId)
                .ToListAsync();
        }

        public async Task<List<GetRoleListDto>> GetActiveRolesList()
        {
            var roles = await _readOnlyDbContext.Roles
                 .Where(x => !x.IsDeleted).ToListAsync();

            return _mapper.Map<List<GetRoleListDto>>(roles);
        }

        public Task<PaginationResult<GetRoleListDto>> GetRolePagedList(PaginationQuery pagination)
        {
            throw new NotImplementedException();
        }

        public async Task<DataValidationResult> ValidateCreateInputAsync(CreateRoleDto input)
        {
            var errors = new List<ValidationError>();
            var normalizedName = input.RoleName.ToUpper();

            var existingItems = await _readOnlyDbContext.Roles
                .Where(x => x.RoleName.Equals(normalizedName, StringComparison.CurrentCultureIgnoreCase))
                .Select(x => new { x.RoleName })
                .ToListAsync();
            if (existingItems.Any(x => x.RoleName.Equals(normalizedName, StringComparison.CurrentCultureIgnoreCase)))
            {
                errors.Add(new ValidationError
                {
                    PropertyName = nameof(CreateRoleDto.RoleName),
                    ErrorMessage = $"Role '{input.RoleName}' already exists in the system."
                });
            }

            return new DataValidationResult
            {
                IsValid = errors.Count == 0,
                Errors = errors
            };
        }

        public async Task<DataValidationResult> ValidateEditInputAsync(EditRoleDto input)
        {
            var errors = new List<ValidationError>();
            var normalizedName = input.RoleName.ToUpper();

            var existingItems = await _readOnlyDbContext.Roles
                .Where(x => x.Id != input.Id && x.RoleName.Equals(normalizedName, StringComparison.CurrentCultureIgnoreCase))
                .Select(x => new { x.RoleName })
                .ToListAsync();
            if (existingItems.Any(x => x.RoleName.Equals(normalizedName, StringComparison.CurrentCultureIgnoreCase)))
            {
                errors.Add(new ValidationError
                {
                    PropertyName = nameof(EditRoleDto.RoleName),
                    ErrorMessage = $"Role '{input.RoleName}' already exists in the system."
                });
            }

            return new DataValidationResult
            {
                IsValid = errors.Count == 0,
                Errors = errors
            };
        }

        public async Task<List<RoleResourceMatrixDto>> GetRoleResourceMatrixByRoleIdAsync(short roleId)
        {
            var allRolesResources = await (from rm in _readOnlyDbContext.RoleResourceMasterMappings
                                           join rs in _readOnlyDbContext.ResourceMasters
                                            on rm.ResourceName equals rs.ResourceName
                                           where !rs.IsDeleted && !rm.IsDeleted && rm.RoleId == roleId
                                           select new RoleResourceMatrixDto
                                           {
                                               RoleId = rm.RoleId,
                                               ResourceName = rs.ResourceName,
                                               GroupType = rs.GroupType,
                                               GroupName = rs.GroupName,
                                               SubGroupName = rs.SubGroupName
                                           }).ToListAsync();

            var childResources = await (from rm in _readOnlyDbContext.RoleResourceMasterMappings
                                        join rs in _readOnlyDbContext.ResourceMasters
            on rm.ResourceName equals rs.ResourceName
                                        join drs in _readOnlyDbContext.DependentResources on rm.Id equals drs.ParentId
                                        join crs in _readOnlyDbContext.ResourceMasters on drs.ResourceId equals crs.Id
                                        where !rs.IsDeleted && !rm.IsDeleted && rm.RoleId == roleId
                                        select new RoleResourceMatrixDto
                                        {
                                            RoleId = rm.RoleId,
                                            ResourceName = crs.ResourceName,
                                            GroupType = crs.GroupType,
                                            GroupName = crs.GroupName,
                                            SubGroupName = crs.SubGroupName
                                        }).ToListAsync();

            if (allRolesResources == null)
                allRolesResources = new List<RoleResourceMatrixDto>();
            if (childResources?.Count > 0)
            {
                allRolesResources.AddRange(childResources);
            }
            return allRolesResources;
        }
    }
}
