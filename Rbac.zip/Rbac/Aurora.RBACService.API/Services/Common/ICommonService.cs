﻿namespace Aurora.RBACService.API.Services.Common
{
    public interface ICommonService
    {
        int GetLoggedUserId();
        string GetLoggedUserName();
        List<short> GetLoggedUserRoles();
        string GetRegionCode();
    }
}
