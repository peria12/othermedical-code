﻿namespace Aurora.RBACService.API.Services.Common
{
    public class CommonService : ICommonService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public CommonService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
        }

        public int GetLoggedUserId()
        {
            if (_httpContextAccessor.HttpContext?.Items.TryGetValue("LOGGED_IN_USER_ID", out var userId) == true && userId != null)
            {
                return Convert.ToInt32(userId);
            }

            throw new ArgumentException("Invalid session, userId not found");
        }

        public string GetLoggedUserName()
        {
            if (_httpContextAccessor.HttpContext?.Items.TryGetValue("LOGGED_IN_USERNAME", out var username) == true && username != null)
            {
                return username.ToString()!;
            }

            throw new ArgumentException("Invalid session, username not found");
        }

        public List<short> GetLoggedUserRoles()
        {
            if (_httpContextAccessor.HttpContext?.Items.TryGetValue("LOGGED_IN_USER_ROLES", out var roles) == true && roles is List<short> roleList)
            {
                return roleList;
            }

            return new List<short>();
        }

        public string GetRegionCode()
        {
            if (_httpContextAccessor.HttpContext?.Items.TryGetValue("RegionCode", out var regionCode) == true && regionCode != null)
            {
                return regionCode.ToString()!;
            }

            throw new ArgumentException("Region Code not found");
        }
    }
}
