﻿namespace Aurora.RBACService.API.Services.Group
{
    public class GroupQueryService : IGroupQueryService
    {
        private readonly ReadOnlyDbContext _readOnlyDbContext;
        private readonly IMapper _mapper;

        public GroupQueryService(ReadOnlyDbContext readOnlyDbContext
            , IMapper mapper)
        {
            _readOnlyDbContext = readOnlyDbContext;
            _mapper = mapper;
        }

        public async Task<GetGroupDto> GetGroup(short id)
        {
            var group = await _readOnlyDbContext.Groups.FindAsync(id);
            var groupDto = _mapper.Map<GetGroupDto>(group);

            var roleIds = await _readOnlyDbContext.GroupRoleMappings
                .Where(x => x.GroupId == id && !x.IsDeleted)
                .Select(x => x.RoleId)
                .ToListAsync();

            groupDto.RoleIds = roleIds;

            return groupDto;
        }

        public async Task<Domain.Entities.RBAC.Group?> GetGroupEntity(short id)
        {
            return await _readOnlyDbContext.Groups.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<GetGroupListDto>> GetActiveGroupsList()
        {
            var groups = await _readOnlyDbContext.Groups
                .Where(x => !x.IsDeleted).ToListAsync();

            return _mapper.Map<List<GetGroupListDto>>(groups);
        }

        public Task<PaginationResult<GetGroupListDto>> GetGroupPagedList(PaginationQuery pagination)
        {
            throw new NotImplementedException();
        }

        public async Task<DataValidationResult> ValidateCreateInputAsync(CreateGroupDto input)
        {
            var errors = new List<ValidationError>();
            var normalizedName = input.GroupName.ToUpper();

            var existingItems = await _readOnlyDbContext.Groups
                .Where(x => x.GroupName == input.GroupName)
                .Select(x => new { x.GroupName })
                .ToListAsync();

            if (existingItems.Any(x => x.GroupName.Equals(normalizedName, StringComparison.CurrentCultureIgnoreCase)))
            {
                errors.Add(new ValidationError
                {
                    PropertyName = nameof(CreateGroupDto.GroupName),
                    ErrorMessage = $"Group '{input.GroupName}' already exists in the system."
                });
            }

            return new DataValidationResult
            {
                IsValid = errors.Count == 0,
                Errors = errors
            };
        }

        public async Task<DataValidationResult> ValidateEditInputAsync(EditGroupDto input)
        {
            var errors = new List<ValidationError>();
            var normalizedName = input.GroupName.ToUpper();

            var existingItems = await _readOnlyDbContext.Groups
                .Where(x => x.Id != input.Id && x.GroupName == input.GroupName)
                .Select(x => new { x.GroupName })
                .ToListAsync();

            if (existingItems.Any(x => x.GroupName.Equals(normalizedName, StringComparison.CurrentCultureIgnoreCase)))
            {
                errors.Add(new ValidationError
                {
                    PropertyName = nameof(EditGroupDto.GroupName),
                    ErrorMessage = $"Group '{input.GroupName}' already exists in the system."
                });
            }

            return new DataValidationResult
            {
                IsValid = errors.Count == 0,
                Errors = errors
            };
        }

        public async Task<List<GroupRoleMapping>> GetGroupRoleMappings(short groupId)
        {
            return await _readOnlyDbContext.GroupRoleMappings
                .Where(gr => gr.GroupId == groupId)
                .ToListAsync();
        }

        public async Task<UserProfile?> GetUserProfileByUserAndGroupAsync(int userId, short groupId)
        {
            return await _readOnlyDbContext.UserProfiles
                .FirstOrDefaultAsync(x => x.UserId == userId && x.GroupId == groupId);
        }
    }
}
