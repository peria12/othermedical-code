﻿namespace Aurora.RBACService.API.Services.Group
{
    public interface IGroupQueryService
    {
        Task<GetGroupDto> GetGroup(short id);
        Task<Domain.Entities.RBAC.Group?> GetGroupEntity(short id);
        Task<List<GetGroupListDto>> GetActiveGroupsList();
        Task<PaginationResult<GetGroupListDto>> GetGroupPagedList(PaginationQuery pagination);
        Task<DataValidationResult> ValidateCreateInputAsync(CreateGroupDto input);
        Task<DataValidationResult> ValidateEditInputAsync(EditGroupDto input);
        Task<List<GroupRoleMapping>> GetGroupRoleMappings(short groupId);
        Task<UserProfile?> GetUserProfileByUserAndGroupAsync(int userId, short groupId);
    }
}
