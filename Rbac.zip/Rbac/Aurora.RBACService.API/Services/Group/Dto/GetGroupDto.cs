﻿namespace Aurora.RBACService.API.Services.Group.Dto
{
    public class GetGroupDto
    {
        public short Id { get; set; }
        public required string GroupName { get; set; }
        public string? GroupDescription { get; set; }
        public bool IsDeleted { get; set; }
        public List<short>? RoleIds { get; set; }
    }
}
