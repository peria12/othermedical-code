﻿namespace Aurora.RBACService.API.Services.Group.Dto
{
    public class UserGroupLinkDto
    {
        public required int UserId { get; set; }
        public required short GroupId { get; set; }
        public bool IsDeleted { get; set; } = false;
    }
}
