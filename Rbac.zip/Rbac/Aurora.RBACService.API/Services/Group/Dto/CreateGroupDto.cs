﻿namespace Aurora.RBACService.API.Services.Group.Dto
{
    public class CreateGroupDto
    {
        [MaxLength(50, ErrorMessage = "GroupName has maximum length of 50 characters.")]
        [Required(ErrorMessage = "GroupName is mandatory.")]
        public required string GroupName { get; set; }

        [MaxLength(200, ErrorMessage = "GroupDescription has maximum length of 200 characters.")]
        public string? GroupDescription { get; set; }

        public bool? IsDeleted { get; set; } = false;

        public List<short>? RoleIds { get; set; }
    }
}
