﻿namespace Aurora.RBACService.API.Services.Group
{
    public class GroupCommandService : IGroupCommandService
    {
        private readonly ReadWriteDbContext _readWriteDbContext;
        private readonly ICommonService _commonService;
        private readonly IGroupQueryService _groupQueryService;
        private readonly IMapper _mapper;
        private readonly ILogger<GroupCommandService> _logger;

        public GroupCommandService(ReadWriteDbContext readWriteDbContext,
            ICommonService commonService,
            IGroupQueryService groupQueryService,
            IMapper mapper,
            ILogger<GroupCommandService> logger)
        {
            _commonService = commonService;
            _readWriteDbContext = readWriteDbContext;
            _groupQueryService = groupQueryService;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<Result<short>> CreateGroup(CreateGroupDto group)
        {
            var validationResult = await _groupQueryService.ValidateCreateInputAsync(group);
            if (!validationResult.IsValid)
            {
                return Result<short>.Failure(validationResult.Errors);
            }

            using var transaction = await _readWriteDbContext.Database.BeginTransactionAsync();
            try
            {
                var entity = _mapper.Map<Domain.Entities.RBAC.Group>(group);
                entity.CreatedDate = DateTime.UtcNow;
                entity.CreatedBy = _commonService.GetLoggedUserName();

                await _readWriteDbContext.Groups.AddAsync(entity);
                await _readWriteDbContext.SaveChangesAsync();

                if (group.RoleIds != null && group.RoleIds.Count > 0)
                {
                    var roleMappings = group.RoleIds.Select(roleId => new GroupRoleMapping
                    {
                        GroupId = entity.Id,
                        RoleId = roleId,
                        CreatedBy = entity.CreatedBy,
                        CreatedDate = entity.CreatedDate,
                        IsDeleted = false
                    }).ToList();

                    await _readWriteDbContext.GroupRoleMappings.AddRangeAsync(roleMappings);
                    await _readWriteDbContext.SaveChangesAsync();
                }

                await transaction.CommitAsync();

                return Result<short>.Success(entity.Id);
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                throw;
            }
        }

        public async Task<Result<bool>> EditGroup(EditGroupDto group)
        {
            var entity = await _groupQueryService.GetGroupEntity(group.Id);
            if (entity == null)
                return Result<bool>.Success(false);

            var validationResult = await _groupQueryService.ValidateEditInputAsync(group);
            if (!validationResult.IsValid)
                return Result<bool>.Failure(validationResult.Errors);

            using var transaction = await _readWriteDbContext.Database.BeginTransactionAsync();
            try
            {
                var updatedEntity = _mapper.Map(group, entity);
                updatedEntity.UpdatedDate = DateTime.UtcNow;
                updatedEntity.UpdatedBy = _commonService.GetLoggedUserName();

                _readWriteDbContext.Groups.Update(updatedEntity);
                await _readWriteDbContext.SaveChangesAsync();

                // Step 1: Get existing mappings
                var existingMappings = await _groupQueryService.GetGroupRoleMappings(group.Id);
                var newRoleIds = group.RoleIds ?? new List<short>();
                var existingRoleIds = existingMappings.Select(x => x.RoleId).ToHashSet();

                var toReactivate = existingMappings
                    .Where(x => newRoleIds.Contains(x.RoleId) && x.IsDeleted)
                    .ToList();

                foreach (var mapping in toReactivate)
                {
                    mapping.IsDeleted = false;
                    mapping.UpdatedBy = updatedEntity.UpdatedBy;
                    mapping.UpdatedDate = updatedEntity.UpdatedDate;
                }

                var toAdd = newRoleIds
                    .Where(roleId => !existingRoleIds.Contains(roleId))
                    .Select(roleId => new GroupRoleMapping
                    {
                        GroupId = group.Id,
                        RoleId = roleId,
                        CreatedBy = updatedEntity.UpdatedBy!,
                        CreatedDate = updatedEntity.UpdatedDate!.Value,
                        IsDeleted = false
                    }).ToList();

                var toSoftDelete = existingMappings
                    .Where(x => !newRoleIds.Contains(x.RoleId) && !x.IsDeleted)
                    .ToList();

                foreach (var mapping in toSoftDelete)
                {
                    mapping.IsDeleted = true;
                    mapping.UpdatedBy = updatedEntity.UpdatedBy;
                    mapping.UpdatedDate = updatedEntity.UpdatedDate;
                }

                if (toReactivate.Count != 0)
                    _readWriteDbContext.GroupRoleMappings.UpdateRange(toReactivate);

                if (toSoftDelete.Count != 0)
                    _readWriteDbContext.GroupRoleMappings.UpdateRange(toSoftDelete);

                if (toAdd.Count != 0)
                    await _readWriteDbContext.GroupRoleMappings.AddRangeAsync(toAdd);

                await _readWriteDbContext.SaveChangesAsync();
                await transaction.CommitAsync();

                return Result<bool>.Success(true);
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }
        }

        public async Task<bool> UpdateUserGroupLink(UserGroupLinkDto link)
        {
            try
            {
                var existingLink = await _groupQueryService.GetUserProfileByUserAndGroupAsync(link.UserId, link.GroupId);

                if (existingLink == null)
                {
                    _logger.LogWarning("UserGroupLink not found for UserId: {UserId}, GroupId: {GroupId}", link.UserId, link.GroupId);
                    return false;
                }

                if (existingLink.IsDeleted == link.IsDeleted)
                {
                    _logger.LogInformation("No change in UserGroupLink for UserId: {UserId}", link.UserId);
                    return true;
                }

                existingLink.IsDeleted = link.IsDeleted;
                existingLink.UpdatedDate = DateTime.UtcNow;
                existingLink.UpdatedBy = _commonService.GetLoggedUserName();

                await _readWriteDbContext.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to update UserGroupLink for UserId: {UserId}", link.UserId);
                return false;
            }
        }

    }
}
