﻿namespace Aurora.RBACService.API.Services.Group
{
    public interface IGroupCommandService
    {
        Task<Result<short>> CreateGroup(CreateGroupDto group);
        Task<Result<bool>> EditGroup(EditGroupDto group);
        Task<bool> UpdateUserGroupLink(UserGroupLinkDto link);
    }
}
