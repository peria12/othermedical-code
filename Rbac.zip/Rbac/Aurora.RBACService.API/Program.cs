namespace Aurora.RBACService.API
{
    [ExcludeFromCodeCoverage]
    public static class Program
    {
        static string? env = string.Empty;
        public static void Main(string[] args)
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
              .AddJsonFile("appsettings.json")
              .AddEnvironmentVariables()
              .Build();
            env = configuration.GetSection("Env").Value;

            CreateHostBuilder(args).Build().Run();
        }
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                 .ConfigureAppConfiguration((a, config) =>
                 {
                     config.AddJsonFile($"appsettings.{env}.json");
                     config.ConfigureAzureKeyVault();

                 })
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
