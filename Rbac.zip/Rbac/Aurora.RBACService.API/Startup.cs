﻿namespace Aurora.RBACService.API
{
    [ExcludeFromCodeCoverage]
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            bool isApiVersioningConfigured = false;
            services.AddProblemDetails();
            if (isApiVersioningConfigured)
            {
                services.AddApiVersioning(options =>
                {
                    options.DefaultApiVersion = new ApiVersion(1, 0);
                    options.AssumeDefaultVersionWhenUnspecified = true;
                    options.ReportApiVersions = true;
                    options.ApiVersionReader = ApiVersionReader.Combine(new UrlSegmentApiVersionReader(), new HeaderApiVersionReader("X-Api-Version"));
                }
                ).AddApiExplorer(options =>
                {
                    options.GroupNameFormat = "'v'VVV";
                    options.SubstituteApiVersionInUrl = true;
                });
            }

            // Add services to the container.
            services.AddControllers().AddJsonOptions(options =>
             {
                 options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
             });

            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen(c =>
             {
                 c.OperationFilter<AddRegionCodeHeaderParameter>();
                 c.EnableAnnotations();
                 c.SwaggerDoc("v1", new OpenApiInfo { Title = "RBACService Web API", Version = "v1" });
                 c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                 {
                     Name = "Authorization",
                     Type = SecuritySchemeType.Http,
                     Scheme = "Bearer",
                     BearerFormat = "JWT",
                     In = ParameterLocation.Header,
                     Description = "Enter 'Bearer' followed by a space and your JWT token in the text input below. Example: \"Bearer tokenValue\""
                 });
                 c.AddSecurityRequirement(new OpenApiSecurityRequirement
                 {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            },
                            In = ParameterLocation.Header,
                        },
                        Array.Empty<string>()
                    }
                 });
             });

            services.AddAutoMapper(Assembly.GetExecutingAssembly());

            //Azure AD Code
            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddMicrosoftIdentityWebApi(Configuration.GetSection("AzureAd"));

            //Db Context
            services.AddScoped(s => new ReadWriteDbContext(Configuration));
            services.AddScoped(s => new ReadOnlyDbContext(Configuration));

            //Registering Services from separate file
            services.AddScoped<ValidationFilterAttribute>();
            services.AddControllers(options =>
             {
                 options.Filters.AddService<ValidationFilterAttribute>();

             }).ConfigureApiBehaviorOptions(options =>
             {
                 options.SuppressModelStateInvalidFilter = true;
             });

            string? instrumentationKey = Configuration[CommonConstants.APPINSIGHTSINSTRUMENTATIONKEY];
            services.AddApplicationInsightsTelemetry(instrumentationKey);

            // Configure ILogger for Application Insights
            services.AddLogging(loggingBuilder =>
            {
                loggingBuilder.AddConsole();
                loggingBuilder.AddDebug();

                loggingBuilder.AddFilter<ApplicationInsightsLoggerProvider>(
                    category: null,
                    logLevel => logLevel >= LogLevel.Information
                );
            });

            services.AddApplicationInsightsTelemetry(options =>
            {
                options.EnablePerformanceCounterCollectionModule = false;
                options.EnableAdaptiveSampling = false;
                options.EnableDebugLogger = true;
            });
            // Enable Dependency Tracking with SQL Command Text
            services.ConfigureTelemetryModule<Microsoft.ApplicationInsights.DependencyCollector.DependencyTrackingTelemetryModule>(
             (module, options) =>
             {
                 Microsoft.ApplicationInsights.AspNetCore.Extensions.ApplicationInsightsServiceOptions aspNetCoreOptions = options;
                 module.EnableSqlCommandTextInstrumentation = true;
             });

            services.AddServiceDependencies();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddCrossCuttingConcerns(Configuration);
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                MigrationScriptHelper.GenerateMigrationScript("MigrationDbContext").ConfigureAwait(false);
            }
            app.UseSwagger();
            app.UseSwaggerUI();
            app.Use(async (context, next) =>
            {
                if (context.Request.Path == "/" || context.Request.Path == "/index.html")
                {
                    context.Response.Redirect("/swagger/index.html");
                    return;
                }
                await next();
            });
            //added to unblock CORS
            string[]? allowedCors = Configuration.GetSection(CommonConstants.ALLOWEDCORS).Get<string[]>();
            if (allowedCors != null)
            {
                app.UseCors(policy =>
                {
                    policy.WithOrigins(allowedCors)
                    .AllowAnyHeader()
                    .AllowAnyMethod();
                });
            }

            app.UseMiddleware<AdTokenMiddleware>();
            app.UseMiddleware<RegionCodeHeaderValidationMiddleware>();
            app.UseMiddleware<ExceptionHandlingMiddleware>();
            app.UseHttpsRedirection();
            app.UseHsts();
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoint =>
            {
                endpoint.MapControllers();
            });

            // Apply migrations for all databases

            string? applyMigration = Configuration[CommonConstants.IsApplyMigration]?.ToString();
            if (applyMigration == "true")
            {
                // Apply migrations for all databases
                using IServiceScope scope = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>().CreateScope();
                MigrationManager.ApplyMigrations(scope.ServiceProvider).ConfigureAwait(false);
            }
        }
    }

    [ExcludeFromCodeCoverage]
    public class AddRegionCodeHeaderParameter : IOperationFilter
    {
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            if (operation.Parameters == null)
                operation.Parameters = new List<OpenApiParameter>();

            operation.Parameters.Add(new OpenApiParameter
            {
                Name = CommonConstants.HEADERREGIONCODE,
                In = ParameterLocation.Header,
                Required = true,
                Schema = new OpenApiSchema
                {
                    Type = "string",
                    Description = CommonConstants.HEADERREGIONCODEDESCRIPTION,
                }
            });
        }
    }
}
