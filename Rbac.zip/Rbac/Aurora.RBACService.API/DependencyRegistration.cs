﻿namespace Aurora.RBACService.API
{
    public static class DependencyRegistration
    {
        public static IServiceCollection AddServiceDependencies(this IServiceCollection services)
        {
            services.AddTransient<ICommonService, CommonService>();
            services.AddTransient<IGroupQueryService, GroupQueryService>();
            services.AddTransient<IGroupCommandService, GroupCommandService>();
            services.AddTransient<IRoleQueryService, RoleQueryService>();
            services.AddTransient<IRoleQueryService, RoleQueryService>();
            services.AddTransient<IResourceQueryService, ResourceQueryService>();

            services.AddSingleton<IRegionCodeValidationHelper, RegionCodeValidationHelper>();

            return services;
        }
    }
}
