﻿namespace Aurora.RBACService.API
{
    [ExcludeFromCodeCoverage]
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            // Groups
            CreateMap<CreateGroupDto, Group>().ReverseMap();
            CreateMap<EditGroupDto, Group>().ReverseMap();
            CreateMap<Group, GetGroupDto>().ReverseMap();
            CreateMap<Group, GetGroupListDto>().ReverseMap();

            // Roles
            CreateMap<CreateRoleDto, Role>().ReverseMap();
            CreateMap<EditRoleDto, Role>().ReverseMap();
            CreateMap<Role, GetRoleDto>().ReverseMap();
            CreateMap<Role, GetRoleListDto>().ReverseMap();
        }
    }
}
