﻿namespace Aurora.RBACService.Domain.Entities.RBAC
{
    [ExcludeFromCodeCoverage]
    [Table("DependentResources", Schema = "rbac")]
    [Index(nameof(ParentId), Name = "IX_DependentResources_ParentId", IsUnique = false)]
    [Index(nameof(ParentId), nameof(ResourceId), Name = "IX_DependentResources_ParentId_ResourceId", IsUnique = true)]
    [Comment("Associates child and parent resources within the RBAC system")]
    public class DependentResource : AuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Comment("Unique identifier for each dependent record")]
        public long Id { get; set; }
        [Comment("Parent resource record Id from ResourceMaster")]
        public long ParentId { get; set; }
        [Comment("Dependent resource record Id from ResourceMaster")]
        public long ResourceId { get; set; }
    }
}
