﻿namespace Aurora.RBACService.Domain.Entities.RBAC
{
    [ExcludeFromCodeCoverage]
    [Table("GroupRoleMapping", Schema = "rbac")]
    [Index(nameof(GroupId), nameof(RoleId), Name = "IX_GroupRoleMapping_GroupId_RoleId", IsUnique = true)]
    [Index(nameof(GroupId), Name = "IX_GroupRoleMapping_GroupId", IsUnique = false)]
    [Comment("Maps user groups to roles for access control")]
    public class GroupRoleMapping : AuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Comment("Primary key for the GroupRoleMapping table")]
        public short Id { get; set; }

        [Comment("Foreign key referencing the Group")]
        public required short GroupId { get; set; }

        [Comment("Foreign key referencing the Role")]
        public required short RoleId { get; set; }

        [Comment("Navigation property: Group associated with this mapping")]
        public Group? Group { get; set; }

        [Comment("Navigation property: Role associated with this mapping")]
        public Role? Role { get; set; }
    }
}
