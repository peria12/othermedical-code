﻿namespace Aurora.RBACService.Domain.Entities.RBAC
{
    [ExcludeFromCodeCoverage]
    [Table("UserProfile", Schema = "rbac")]
    [Index(nameof(UserId), nameof(GroupId), Name = "IX_UserProfile_UserId_GroupId", IsUnique = true)]
    [Index(nameof(UserId), Name = "IX_UserProfile_UserId", IsUnique = false)]
    [Index(nameof(GroupId), Name = "IX_UserProfile_GroupId", IsUnique = false)]
    [Comment("Associates users with groups within the RBAC system")]
    public class UserProfile : AuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Comment("Unique identifier for each user profile record")]
        public int Id { get; set; }

        [Comment("Unique identifier for the user of the system")]
        public required int UserId { get; set; }

        [Comment("Foreign key referencing the user's group")]
        public required short GroupId { get; set; }

        [Comment("Navigation property: Group to which the user belongs")]
        public Group? Group { get; set; }
    }
}
