﻿namespace Aurora.RBACService.Domain.Entities.RBAC
{
    [ExcludeFromCodeCoverage]
    [Table("Roles", Schema = "rbac")]
    [Index(nameof(RoleName), Name = "IX_Roles_RoleName", IsUnique = true)]
    [Comment("Contains role definitions for users")]
    public class Role : AuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Comment("Primary key of the Roles table")]
        public short Id { get; set; }

        [MaxLength(50)]
        [Comment("Unique name of the role")]
        public required string RoleName { get; set; }

        [MaxLength(200)]
        [Comment("Optional description of the role")]
        public string? RoleDescription { get; set; }

        [Comment("Navigation property: Mappings between role and resources")]
        public ICollection<RoleResourceMasterMapping>? RoleResourceMasterMappings { get; set; }

        [Comment("Navigation property: Mappings between groups and this role")]
        public ICollection<GroupRoleMapping>? GroupRoleMappings { get; set; }
    }
}
