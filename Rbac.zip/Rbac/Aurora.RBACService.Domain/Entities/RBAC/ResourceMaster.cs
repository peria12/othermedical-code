﻿namespace Aurora.RBACService.Domain.Entities.RBAC
{
    [ExcludeFromCodeCoverage]
    [Table("ResourceMaster", Schema = "rbac")]
    [Index(nameof(ResourceName), Name = "IX_ResourceMaster_ResourceName", IsUnique = true)]
    [Index(nameof(GroupType), Name = "IX_ResourceMaster_GroupType", IsUnique = false)]
    [Index(nameof(GroupName), Name = "IX_ResourceMaster_GroupName", IsUnique = false)]
    [Index(nameof(GroupName), nameof(SubGroupName), Name = "IX_ResourceMaster_GroupName_SubGroupName", IsUnique = false)]
    [Comment("Defines resources that can be linked to roles for access control")]
    public class ResourceMaster : AuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Comment("Primary key for the ResourceMaster table")]
        public long Id { get; set; }

        [MaxLength(25)]
        [Comment("Optional source identifier (e.g., Aurora)")]
        public string? Source { get; set; }

        [MaxLength(20)]
        [Comment("Optional unique code for the resource")]
        public string? Code { get; set; }

        [MaxLength(100)]
        [Comment("Display name of the resource")]
        public required string Display { get; set; }

        [MaxLength(200)]
        [Comment("Detailed definition or description of the resource")]
        public string? Definition { get; set; }

        [MaxLength(50)]
        [Comment("Unique name of the resource")]
        public required string ResourceName { get; set; }

        [Comment("Foreign key to the ResourceType table")]
        public required short ResourceTypeId { get; set; }

        [Comment("Optional foreign key to parent resource for hierarchy")]
        public long? ParentId { get; set; }

        [MaxLength(10)]
        [Comment("Group classification for the resource (e.g., FE, BE)")]
        public required string GroupType { get; set; }

        [MaxLength(100)]
        [Comment("Group name used to categorize the resource")]
        public required string GroupName { get; set; }

        [MaxLength(100)]
        [Comment("Sub-group name within the group")]
        public required string SubGroupName { get; set; }

        [Comment("Release number if versioned")]
        public short? ReleaseNo { get; set; }

        [Comment("Version number if versioned")]
        public short? VersionNo { get; set; }

        [Comment("Navigation property to the resource type")]
        public ResourceType? ResourceType { get; set; }
    }
}
