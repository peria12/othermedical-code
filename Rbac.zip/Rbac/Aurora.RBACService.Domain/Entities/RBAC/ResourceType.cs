﻿namespace Aurora.RBACService.Domain.Entities.RBAC
{
    [ExcludeFromCodeCoverage]
    [Table("ResourceType", Schema = "rbac")]
    [Index(nameof(ResourceTypeName), Name = "IX_ResourceType_ResourceTypeName", IsUnique = true)]
    [Comment("Defines the classification of resources used in role-based access control")]
    public class ResourceType : AuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Comment("Primary key of the ResourceType table")]
        public short Id { get; set; }

        [MaxLength(50)]
        [Comment("Name of the resource type")]
        public required string ResourceTypeName { get; set; }

        [MaxLength(200)]
        [Comment("Optional description providing more details about the resource type")]
        public string? ResourceTypeDescription { get; set; }

        [Comment("Navigation property: Collection of resources belonging to this type")]
        public ICollection<ResourceMaster>? ResourceMasters { get; set; }
    }
}
