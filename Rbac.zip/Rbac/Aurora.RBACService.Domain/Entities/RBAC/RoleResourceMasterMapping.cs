﻿namespace Aurora.RBACService.Domain.Entities.RBAC
{
    [ExcludeFromCodeCoverage]
    [Table("RoleResourceMasterMapping", Schema = "rbac")]
    [Index(nameof(RoleId), nameof(ResourceName), Name = "IX_RoleResourceMapping_RoleId_ResourceName", IsUnique = true)]
    [Index(nameof(RoleId), Name = "IX_RoleResourceMapping_RoleId", IsUnique = false)]
    [Comment("Maps roles to specific resources, defining access control rules")]
    public class RoleResourceMasterMapping : AuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Comment("Primary key for the RoleResourceMasterMapping table")]
        public long Id { get; set; }

        [Comment("Foreign key referencing the Role")]
        public required short RoleId { get; set; }

        [Comment("Name of the resource linked to the role")]
        public required string ResourceName { get; set; }

        [Comment("Navigation property: Role associated with this mapping")]
        public Role? Role { get; set; }

        [Comment("Navigation property: Resource master reference (if applicable)")]
        public ResourceMaster? ResourceMaster { get; set; }
    }
}

