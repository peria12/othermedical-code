﻿namespace Aurora.RBACService.Domain.Entities.RBAC
{
    [ExcludeFromCodeCoverage]
    [Table("Groups", Schema = "rbac")]
    [Index(nameof(GroupName), Name = "IX_Groups_GroupName", IsUnique = true)]
    [Comment("Contains group definitions for User")]
    public class Group : AuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Comment("Primary key for the Groups table")]
        public short Id { get; set; }

        [MaxLength(50)]
        [Comment("Name of the group")]
        public required string GroupName { get; set; }

        [MaxLength(200)]
        [Comment("Description of the group")]
        public string? GroupDescription { get; set; }

        [Comment("Indicates if the group is obsolete")]
        public bool IsObsolete { get; set; }

        [Comment("Indicates if the type of the group")]
        public byte? GroupTypeId { get; set; }

        [Comment("Navigation property: Users associated with this group")]
        public ICollection<UserProfile>? UserProfiles { get; set; }

        [Comment("Navigation property: Role mappings for this group")]
        public ICollection<GroupRoleMapping>? GroupRoleMappings { get; set; }
    }
}
