﻿namespace Aurora.RBACService.Domain
{
    [ExcludeFromCodeCoverage]
    public class AuditableEntity
    {
        [Comment("Indicates whether the record is soft-deleted")]
        public bool IsDeleted { get; set; }

        [MaxLength(50)]
        [Comment("Username or ID of the user who created the record")]
        public required string CreatedBy { get; set; }

        [Comment("Timestamp when the record was created")]
        public DateTime CreatedDate { get; set; }

        [MaxLength(50)]
        [Comment("Username or ID of the user who last updated the record")]
        public string? UpdatedBy { get; set; }

        [Comment("Timestamp when the record was last updated")]
        public DateTime? UpdatedDate { get; set; }
    }
}
