﻿namespace Aurora.RBACService.Tests.API.Middleware
{
    public class RegionCodeHeaderValidationMiddlewareTests
    {
        private readonly Mock<RequestDelegate> _mockNext;
        private readonly Mock<IRegionCodeValidationHelper> _mockRegionCodeValidationHelper;
        private readonly RegionCodeHeaderValidationMiddleware _middleware;

        public RegionCodeHeaderValidationMiddlewareTests()
        {
            _mockNext = new Mock<RequestDelegate>();
            _mockRegionCodeValidationHelper = new Mock<IRegionCodeValidationHelper>();
            _middleware = new RegionCodeHeaderValidationMiddleware(_mockNext.Object, _mockRegionCodeValidationHelper.Object);
        }

        [Fact]
        public async Task InvokeAsync_ValidRegionCode_ShouldCallNextMiddleware()
        {
            GenericResponse<string> result = null!;
            // Arrange
            var context = new DefaultHttpContext();
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(result); // No error

            // Act
            await _middleware.InvokeAsync(context);

            // Assert
            _mockNext.Verify(next => next(context), Times.Once);
        }

        [Fact]
        public async Task InvokeAsync_InvalidRegionCode_ShouldReturnNotFoundStatusCode()
        {
            // Arrange
            var context = new DefaultHttpContext();
            var errorMessage = "Invalid Region Code";
            var response = new GenericResponse<string>
            {
                HasError = true,
                Message = errorMessage
            };

            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(response);

            var responseBodyStream = new MemoryStream();
            context.Response.Body = responseBodyStream;

            // Act
            await _middleware.InvokeAsync(context);

            // Assert
            context.Response.StatusCode.Should().Be(Convert.ToInt32(ResponseStatusCode.STATUS_NOTFOUND));

            responseBodyStream.Seek(0, SeekOrigin.Begin);
            var reader = new StreamReader(responseBodyStream);
            var responseBody = await reader.ReadToEndAsync();
            responseBody.Should().Be(errorMessage);

            _mockNext.Verify(next => next(context), Times.Never);
        }

        [Fact]
        public async Task InvokeAsync_ExceptionThrown_ShouldWrapAndThrowException()
        {
            // Arrange
            var context = new DefaultHttpContext();
            var exceptionMessage = "Test exception";

            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Throws(new Exception(exceptionMessage));

            // Act
            Func<Task> act = async () => await _middleware.InvokeAsync(context);

            // Assert
            await act.Should().ThrowAsync<Exception>()
                .WithMessage($"An error occured : {exceptionMessage}");

            _mockNext.Verify(next => next(context), Times.Never);
        }
    }
}
