﻿namespace Aurora.RBACService.Tests.API.Middleware
{
    public class AdTokenMiddlewareTests
    {
        private readonly Mock<RequestDelegate> _next;
        private readonly AdTokenMiddleware _middleware;
        private readonly DefaultHttpContext _httpContext;

        public AdTokenMiddlewareTests()
        {
            _next = new Mock<RequestDelegate>();
            _middleware = new AdTokenMiddleware(_next.Object);
            _httpContext = new DefaultHttpContext();
        }

        [Fact]
        public async Task InvokeAsync_Should_Proceed_If_No_Authorization_Header()
        {
            await _middleware.InvokeAsync(_httpContext);
            _next.Verify(n => n.Invoke(_httpContext), Times.Once);
        }

        [Fact]
        public async Task InvokeAsync_Should_Return_401_If_Token_Is_Invalid()
        {
            _httpContext.Request.Headers[CommonConstants.AUTH] = "Bearer invalid_token";

            await _middleware.InvokeAsync(_httpContext);

            _httpContext.Response.StatusCode.Should().Be(StatusCodes.Status401Unauthorized);
        }

        [Fact]
        public async Task InvokeAsync_Should_Return_401_If_Token_Expired()
        {
            var expiredToken = GenerateJwtToken(expired: true);
            _httpContext.Request.Headers[CommonConstants.AUTH] = $"Bearer {expiredToken}";

            await _middleware.InvokeAsync(_httpContext);

            _httpContext.Response.StatusCode.Should().Be(StatusCodes.Status401Unauthorized);
        }

        [Fact]
        public async Task InvokeAsync_Should_Set_User_Claims_If_Token_Is_Valid()
        {
            var validToken = GenerateJwtToken(expired: false);
            _httpContext.Request.Headers[CommonConstants.AUTH] = $"Bearer {validToken}";

            await _middleware.InvokeAsync(_httpContext);

            _httpContext.User.Identity!.IsAuthenticated.Should().BeTrue();
            _next.Verify(n => n.Invoke(_httpContext), Times.Once);
        }

        private static string GenerateJwtToken(bool expired)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var claims = new[] { new Claim(JwtRegisteredClaimNames.Exp,
            new DateTimeOffset(expired ? DateTime.UtcNow.AddSeconds(-10) : DateTime.UtcNow.AddMinutes(10)).ToUnixTimeSeconds().ToString()) };
            var token = new JwtSecurityToken(claims: claims);
            return tokenHandler.WriteToken(token);
        }

        [Fact]
        public void UseAdTokenMiddleware_ShouldReturnSameApplicationBuilderInstance()
        {
            // Arrange
            var mockAppBuilder = new Mock<IApplicationBuilder>(MockBehavior.Strict);

            // The key fix: Ensure `UseMiddleware<T>` is called on the actual object.
            mockAppBuilder.Setup(m => m.Use(It.IsAny<Func<RequestDelegate, RequestDelegate>>()))
                          .Returns(mockAppBuilder.Object);

            // Act
            var result = mockAppBuilder.Object.UseAdTokenMiddleware();

            // Assert
            result.Should().Be(mockAppBuilder.Object);
        }
    }
}
