﻿namespace Aurora.RBACService.Tests.API.Controllers.Group
{
    public class GroupControllerTests
    {
        private readonly GroupController _controller;
        private readonly Mock<IGroupCommandService> _mockGroupCommandService;
        private readonly Mock<IGroupQueryService> _mockGroupQueryService;
        private readonly Mock<IHttpContextAccessor> _mockHttpContextAccessor;

        public GroupControllerTests()
        {
            _mockGroupCommandService = new Mock<IGroupCommandService>();
            _mockGroupQueryService = new Mock<IGroupQueryService>();
            _mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
            _controller = new GroupController(_mockHttpContextAccessor.Object, _mockGroupCommandService.Object, _mockGroupQueryService.Object);
        }

        [Fact]
        public async Task GetGroup_ReturnsOkResult_WithValidData()
        {
            // Arrange
            short roleId = 1;

            var expectedResponse = new GetGroupDto
            {
                Id = roleId,
                GroupName = "Test Group",
                GroupDescription = "Sample description",
                IsDeleted = false,
                RoleIds = new List<short> { 101, 102 }
            };

            _mockGroupQueryService
                .Setup(service => service.GetGroup(roleId))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetGroup(roleId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponse<GetGroupDto>>(okResult.Value);

            Assert.NotNull(response.Result);
            Assert.Equal(expectedResponse.Id, response.Result!.Id);
            Assert.Equal(expectedResponse.GroupName, response.Result!.GroupName);
            Assert.Equal(expectedResponse.GroupDescription, response.Result!.GroupDescription);
            Assert.Equal(expectedResponse.IsDeleted, response.Result!.IsDeleted);
            Assert.Equal(expectedResponse.RoleIds, response.Result!.RoleIds);
        }

        [Fact]
        public async Task GetGroup_ReturnsOkResult_WithNoData()
        {
            // Arrange
            short roleId = 99;

            _mockGroupQueryService
            .Setup(service => service.GetGroup(roleId))
            .ReturnsAsync((GetGroupDto?)null!);

            // Act
            var result = await _controller.GetGroup(roleId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponse<GetGroupDto>>(okResult.Value);

            Assert.Null(response.Result);
            Assert.Equal(LanguageTranslator.Instance.Translate(CommonConstants._languageCode, LanguageResourceGeneralKeys.STATUS_NODATA), response.Message);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task GetActiveGroupsList_ReturnsOkResult_WithValidData()
        {
            // Arrange
            var expectedResponse = new List<GetGroupListDto>
        {
            new GetGroupListDto { Id = 1, GroupName = "Group A", GroupDescription = "Description A", IsDeleted = false },
            new GetGroupListDto { Id = 2, GroupName = "Group B", GroupDescription = "Description B", IsDeleted = false }
        };

            _mockGroupQueryService
                .Setup(service => service.GetActiveGroupsList())
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetActiveGroupsList();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponseList<GetGroupListDto>>(okResult.Value);

            Assert.NotNull(response.Result);
            Assert.Equal(expectedResponse.Count, response.Result!.Count());

            // Validate first item in the list
            var firstExpected = expectedResponse[0];
            var firstResult = response.Result!.First();

            Assert.Equal(firstExpected.Id, firstResult.Id);
            Assert.Equal(firstExpected.GroupName, firstResult.GroupName);
            Assert.Equal(firstExpected.GroupDescription, firstResult.GroupDescription);
            Assert.Equal(firstExpected.IsDeleted, firstResult.IsDeleted);
        }

        [Fact]
        public async Task GetActiveGroupsList_ReturnsOkResult_WithNoData()
        {
            // Arrange
            _mockGroupQueryService
                .Setup(service => service.GetActiveGroupsList())
                .ReturnsAsync(new List<GetGroupListDto>());

            // Act
            var result = await _controller.GetActiveGroupsList();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponseList<GetGroupListDto>>(okResult.Value);

            Assert.Empty(response.Result!);
            Assert.Equal(LanguageTranslator.Instance.Translate(CommonConstants._languageCode, LanguageResourceGeneralKeys.STATUS_NODATA), response.Message);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task GetGroupPagedList_ShouldReturnOk_WhenNoDataFound()
        {
            // Arrange
            var pagination = new PaginationQuery(1, 10);
            var mockData = new PaginationResult<GetGroupListDto>
            {
                TotalCount = 0,
                Records = new List<GetGroupListDto>().AsQueryable()
            };

            _mockGroupQueryService.Setup(service => service.GetGroupPagedList(pagination))
                .ReturnsAsync(mockData);

            // Act
            var response = await _controller.GetGroupPagedList(pagination);

            // Assert
            var result = Assert.IsType<ActionResult<GenericResponsePagedList<GetGroupListDto>>>(response);
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var apiResponse = Assert.IsType<GenericResponsePagedList<PaginationResult<GetGroupListDto>>>(okResult.Value);

            Assert.True(apiResponse.IsSuccess);
            Assert.False(apiResponse.HasError);
            Assert.Equal(0, apiResponse.Count);
            Assert.Empty(apiResponse.Result!);
        }

        [Fact]
        public async Task GetGroupPagedList_ShouldReturnOk_WhenDataExists()
        {
            // Arrange
            var pagination = new PaginationQuery(1, 10);
            var mockData = new PaginationResult<GetGroupListDto>
            {
                TotalCount = 2,
                Records = new List<GetGroupListDto>
    {
        new GetGroupListDto { Id = 1, GroupName = "Group A", GroupDescription = "Description A", IsDeleted = false },
        new GetGroupListDto { Id = 2, GroupName = "Group B", GroupDescription = "Description B", IsDeleted = false }
    }.AsQueryable()
            };

            _mockGroupQueryService.Setup(service => service.GetGroupPagedList(pagination))
                .ReturnsAsync(mockData);

            // Act
            var response = await _controller.GetGroupPagedList(pagination);

            // Assert
            var result = Assert.IsType<ActionResult<GenericResponsePagedList<GetGroupListDto>>>(response);
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var apiResponse = Assert.IsType<GenericResponsePagedList<PaginationResult<GetGroupListDto>>>(okResult.Value);

            Assert.NotNull(apiResponse);
            Assert.True(apiResponse.IsSuccess);
            Assert.Equal(2, apiResponse.Count);
        }

        [Fact]
        public async Task CreateGroup_ReturnsOkResult_WhenCreationIsSuccessful()
        {
            // Arrange
            var groupDto = new CreateGroupDto { GroupName = "New Group", GroupDescription = "New Description" };
            var expectedResult = Result<short>.Success(1);

            _mockGroupCommandService
                .Setup(service => service.CreateGroup(groupDto))
                .ReturnsAsync(expectedResult);

             _controller.ReturnChangeResponse<short>(
                CrudType.Create, expectedResult.Value, validationFailed: false, expectedResult.ValidationMessage);

            // Act
            var result = await _controller.CreateGroup(groupDto);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponse2<short>>(okResult.Value);

            Assert.True(response.IsSuccess);
            Assert.False(response.HasError);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
            Assert.Equal(expectedResult.Value, response.Result);
        }

        [Fact]
        public async Task EditGroup_ReturnsOkResult_WhenEditIsSuccessful()
        {
            // Arrange
            var groupDto = new EditGroupDto { Id = 1, GroupName = "Updated Group", GroupDescription = "Updated Description" };
            var expectedResult = Result<bool>.Success(true);

            _mockGroupCommandService
                .Setup(service => service.EditGroup(groupDto))
                .ReturnsAsync(expectedResult);

            _controller.ReturnChangeResponse<bool>(
                CrudType.Edit, expectedResult.Value, !expectedResult.IsSuccess, expectedResult.ValidationMessage);

            // Act
            var result = await _controller.EditGroup(groupDto);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponse2<bool>>(okResult.Value);

            Assert.True(response.IsSuccess);
            Assert.False(response.HasError);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
            Assert.True(response.Result);
        }

        [Fact]
        public async Task UpdateUserGroupLink_ShouldReturnOk_WhenUpdateIsSuccessful()
        {
            // Arrange
            var mockDto = new UserGroupLinkDto { UserId = 1, GroupId = 3, IsDeleted = false };

            _mockGroupCommandService.Setup(service => service.UpdateUserGroupLink(mockDto))
                .ReturnsAsync(true);

            // Act
            var response = await _controller.UpdateUserGroupLink(mockDto);

            // Assert
            var result = Assert.IsType<ActionResult<GenericResponse2<bool>>>(response);
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var apiResponse = Assert.IsType<GenericResponse2<bool>>(okResult.Value);

            Assert.True(apiResponse.IsSuccess);
            Assert.False(apiResponse.HasError);
            Assert.True(apiResponse.Result);
        }

        [Fact]
        public async Task UpdateUserGroupLink_ShouldReturnOk_WithFailureResponse_WhenUpdateFails()
        {
            // Arrange
            var mockDto = new UserGroupLinkDto { UserId = 1, GroupId = 2, IsDeleted = false };
            _mockGroupCommandService.Setup(service => service.UpdateUserGroupLink(mockDto))
                .ReturnsAsync(false);

            // Act
            var response = await _controller.UpdateUserGroupLink(mockDto);

            // Assert
            var result = Assert.IsType<ActionResult<GenericResponse2<bool>>>(response);
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var apiResponse = Assert.IsType<GenericResponse2<bool>>(okResult.Value);
            Assert.False(apiResponse.Result);
        }
    }
}
