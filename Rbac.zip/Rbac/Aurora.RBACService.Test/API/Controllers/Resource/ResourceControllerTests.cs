﻿namespace Aurora.RBACService.Tests.API.Controllers.Resource
{
    public class ResourceControllerTests
    {
        private readonly ResourceController _controller;
        private readonly Mock<IResourceQueryService> _mockResourceQueryService;
        private readonly Mock<IHttpContextAccessor> _mockHttpContextAccessor;

        public ResourceControllerTests()
        {
            _mockResourceQueryService = new Mock<IResourceQueryService>();
            _mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
            _controller = new ResourceController(_mockHttpContextAccessor.Object, _mockResourceQueryService.Object);
        }

        [Fact]
        public async Task GetRoleResources_ReturnsOkResult_WithValidData()
        {
            // Arrange
            string groupType = "FE";
            short roleId = 1;

            var expectedResponse = new GetRoleResourceDto
            {
                RoleId = roleId,
                RoleName = "Admin",
                RoleDescription = "Administrator Role",
                IsDeleted = false,
                Resources = new List<ResourceHierarchyDto>()
            };

            _mockResourceQueryService
                .Setup(service => service.GetRoleResources(groupType, roleId))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetRoleResources(groupType, roleId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<RBACService.CrossCutting.GenericResponse.GenericResponse<GetRoleResourceDto>>(okResult.Value);

            Assert.NotNull(response.Result);
            Assert.Equal(expectedResponse.RoleId, response.Result!.RoleId);
            Assert.Equal(expectedResponse.RoleName, response.Result!.RoleName);
            Assert.Equal(expectedResponse.RoleDescription, response.Result!.RoleDescription);
            Assert.Equal(expectedResponse.IsDeleted, response.Result!.IsDeleted);

        }

        [Fact]
        public async Task GetRoleResources_WithNonExistentRoleId_ReturnsEmptyRoleData()
        {
            // Arrange
            string groupType = "FE";
            short roleId = 999; // Assuming 999 doesn't exist

            var expectedResponse = new GetRoleResourceDto
            {
                RoleId = null,
                RoleName = null,
                RoleDescription = null,
                IsDeleted = true,
                Resources = new List<ResourceHierarchyDto>()
            };

            _mockResourceQueryService
                .Setup(service => service.GetRoleResources(groupType, roleId))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetRoleResources(groupType, roleId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<RBACService.CrossCutting.GenericResponse.GenericResponse<GetRoleResourceDto>>(okResult.Value);

            Assert.NotNull(response.Result);
            Assert.Null(response.Result!.RoleId);
            Assert.Null(response.Result.RoleName);
        }

        [Fact]
        public async Task GetUserResourcesByGroup_ReturnsOkResult_WithValidData()
        {
            // Arrange
            string groupName = "Admins";

            var expectedResources = new List<GetUserResourceDto>
            {
                new GetUserResourceDto { ResourceName = "Dashboard", SubGroupName = "Main" },
                new GetUserResourceDto { ResourceName = "Reports", SubGroupName = "Analytics" }
            };

            _mockResourceQueryService
                .Setup(service => service.GetUserResourcesByGroup(groupName))
                .ReturnsAsync(expectedResources);

            // Act
            var result = await _controller.GetUserResourcesByGroup(groupName);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<RBACService.CrossCutting.GenericResponse.GenericResponseList<GetUserResourceDto>>(okResult.Value);

            Assert.NotNull(response.Result);
            Assert.Equal(2, response.Result!.Count());
            Assert.Equal("Dashboard", response.Result.First().ResourceName);
            Assert.Equal("Main", response.Result.First().SubGroupName);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task GetUserResourcesByGroup_WithNullGroupName_ReturnsOkResult_WithEmptyList()
        {
            // Arrange
            string? groupName = null;

            var expectedResources = new List<GetUserResourceDto>();

            _mockResourceQueryService.Setup(service => service.GetUserResourcesByGroup(It.IsAny<string>()))
            .ReturnsAsync(expectedResources);

            // Act
            var result = await _controller.GetUserResourcesByGroup(groupName ?? string.Empty);

            // Assert
            var actionResult = Assert.IsType<ActionResult<RBACService.CrossCutting.GenericResponse.GenericResponseList<GetUserResourceDto>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<RBACService.CrossCutting.GenericResponse.GenericResponseList<GetUserResourceDto>>(okResult.Value);

            Assert.NotNull(response.Result);
            Assert.Empty(response.Result);
        }

        [Fact]
        public async Task GetUserResourcesBySubGroup_ReturnsOkResult_WithValidData()
        {
            // Arrange
            string groupName = "Admins";
            string subGroupName = "Managers";

            var expectedResources = new List<GetUserResourceDto>
            {
                new GetUserResourceDto { ResourceName = "User Management", SubGroupName = "Managers" },
                new GetUserResourceDto { ResourceName = "Reports", SubGroupName = "Managers" }
            };

            _mockResourceQueryService
                .Setup(service => service.GetUserResourcesBySubGroup(groupName, subGroupName))
                .ReturnsAsync(expectedResources);

            // Act
            var result = await _controller.GetUserResourcesBySubGroup(groupName, subGroupName);

            // Assert
            var actionResult = Assert.IsType<ActionResult<RBACService.CrossCutting.GenericResponse.GenericResponseList<GetUserResourceDto>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<RBACService.CrossCutting.GenericResponse.GenericResponseList<GetUserResourceDto>>(okResult.Value);

            Assert.NotNull(response.Result);
            Assert.Equal(2, response.Result!.Count());
            Assert.Equal("User Management", response.Result.First().ResourceName);
            Assert.Equal("Managers", response.Result.First().SubGroupName);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task GetUserResourcesBySubGroup_WithNoMatchingSubGroup_ReturnsEmptyList()
        {
            // Arrange
            string groupName = "Admins";
            string subGroupName = "UnknownSubGroup";

            var expectedResources = new List<GetUserResourceDto>();

            _mockResourceQueryService
                .Setup(service => service.GetUserResourcesBySubGroup(groupName, subGroupName))
                .ReturnsAsync(expectedResources);

            // Act
            var result = await _controller.GetUserResourcesBySubGroup(groupName, subGroupName);

            // Assert
            var actionResult = Assert.IsType<ActionResult<RBACService.CrossCutting.GenericResponse.GenericResponseList<GetUserResourceDto>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<RBACService.CrossCutting.GenericResponse.GenericResponseList<GetUserResourceDto>>(okResult.Value);

            Assert.NotNull(response.Result);
            Assert.Empty(response.Result);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task HasUserResourceAccess_ReturnsOkResult_WithTrue()
        {
            // Arrange
            string resourceName = "Reports";

            _mockResourceQueryService
                .Setup(service => service.HasUserResourceAccess(resourceName))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.HasUserResourceAccess(resourceName);

            // Assert
            var actionResult = Assert.IsType<ActionResult<RBACService.CrossCutting.GenericResponse.GenericResponse2<bool>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<RBACService.CrossCutting.GenericResponse.GenericResponse2<bool>>(okResult.Value);

            Assert.NotNull(response.Result);
            Assert.True(response.Result!.Value);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task HasUserResourceAccess_WithNonExistentResource_ReturnsFalse()
        {
            // Arrange
            string resourceName = "NonExistentResource";

            _mockResourceQueryService
                .Setup(service => service.HasUserResourceAccess(resourceName))
                .ReturnsAsync(false);

            // Act
            var result = await _controller.HasUserResourceAccess(resourceName);

            // Assert
            var actionResult = Assert.IsType<ActionResult<RBACService.CrossCutting.GenericResponse.GenericResponse2<bool>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<RBACService.CrossCutting.GenericResponse.GenericResponse2<bool>>(okResult.Value);

            Assert.NotNull(response.Result);
            Assert.False(response.Result!.Value);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task CacheRoleResourceMatrix_ReturnsOkResult_WithTrue()
        {
            // Arrange
            _mockResourceQueryService
                .Setup(service => service.CacheRoleResourceMatrix())
                .ReturnsAsync(true);

            // Act
            var result = await _controller.CacheRoleResourceMatrix();

            // Assert
            var actionResult = Assert.IsType<ActionResult<RBACService.CrossCutting.GenericResponse.GenericResponse2<bool>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<RBACService.CrossCutting.GenericResponse.GenericResponse2<bool>>(okResult.Value);

            Assert.NotNull(response.Result);
            Assert.True(response.Result!.Value);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task CacheRoleResourceMatrix_WhenCacheFails_ReturnsFalse()
        {
            // Arrange
            _mockResourceQueryService
                .Setup(service => service.CacheRoleResourceMatrix())
                .ReturnsAsync(false);

            // Act
            var result = await _controller.CacheRoleResourceMatrix();

            // Assert
            var actionResult = Assert.IsType<ActionResult<RBACService.CrossCutting.GenericResponse.GenericResponse2<bool>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<RBACService.CrossCutting.GenericResponse.GenericResponse2<bool>>(okResult.Value);

            Assert.NotNull(response.Result);
            Assert.False(response.Result!.Value);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task ClearRoleResourceMatrixCache_ReturnsOkResult_WithTrue()
        {
            // Arrange
            _mockResourceQueryService
                .Setup(service => service.ClearRoleResourceMatrixCache())
                .ReturnsAsync(true);

            // Act
            var result = await _controller.ClearRoleResourceMatrixCache();

            // Assert
            var actionResult = Assert.IsType<ActionResult<RBACService.CrossCutting.GenericResponse.GenericResponse2<bool>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<RBACService.CrossCutting.GenericResponse.GenericResponse2<bool>>(okResult.Value);

            Assert.NotNull(response.Result);
            Assert.True(response.Result!.Value);
            Assert.True(response.IsSuccess);
        }


        [Fact]
        public async Task ClearRoleResourceMatrixCache_WhenCacheFails_ReturnsFalse()
        {
            // Arrange
            _mockResourceQueryService
                .Setup(service => service.ClearRoleResourceMatrixCache())
                .ReturnsAsync(false);

            // Act
            var result = await _controller.ClearRoleResourceMatrixCache();

            // Assert
            var actionResult = Assert.IsType<ActionResult<RBACService.CrossCutting.GenericResponse.GenericResponse2<bool>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<RBACService.CrossCutting.GenericResponse.GenericResponse2<bool>>(okResult.Value);

            Assert.NotNull(response.Result);
            Assert.False(response.Result!.Value);
            Assert.True(response.IsSuccess);
        }

    }
}
