﻿namespace Aurora.RBACService.Tests.API.Controllers.Role
{
    public class RoleControllerTest
    {
        private readonly RoleController _controller;
        private readonly Mock<IRoleCommandService> _roleCommandMock;
        private readonly Mock<IRoleQueryService> _roleQueryMock;
        private readonly Mock<IHttpContextAccessor> _mockHttpAccessor;

        public RoleControllerTest()
        {
            // Mocks for the constructor
            _roleCommandMock = new Mock<IRoleCommandService>();
            _roleQueryMock = new Mock<IRoleQueryService>();
            _mockHttpAccessor = new Mock<IHttpContextAccessor>();

            // Instantiate the controller
            _controller = new RoleController(
                _mockHttpAccessor.Object,
                _roleCommandMock.Object,
                _roleQueryMock.Object
            );
        }

        [Fact]
        public async Task GetRole_ValidId_ReturnsOkResult()
        {
            // Arrange
            short roleId = 1;
            var getRoleDto = new GetRoleDto { Id = roleId, RoleName = "Admin" };
            _roleQueryMock.Setup(s => s.GetRole(roleId)).ReturnsAsync(getRoleDto);

            // Act
            var result = await _controller.GetRole(roleId);

            // Assert
            Assert.NotNull(result);
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var dataResponse = Assert.IsType<RBACService.CrossCutting.GenericResponse.GenericResponse<GetRoleDto>>(okResult.Value);
            Assert.True(dataResponse.IsSuccess);
            Assert.Equal(roleId, dataResponse.Result!.Id);
        }



        [Fact]
        public async Task CreateRole_Success_ReturnsOkResult()
        {
            var createRoleDto = new CreateRoleDto
            {
                RoleName = "Admin",
                RoleDescription = "Administrator Role",
                IsDeleted = false,
                ResourceIds = new List<long> { 1, 2, 3 }
            };

            var result = Result<short>.Success(1);
            _roleCommandMock.Setup(s => s.CreateRole(createRoleDto)).ReturnsAsync(result);

            var response = await _controller.CreateRole(createRoleDto);

            var okObjectResult = Assert.IsType<OkObjectResult>(response.Result);
            var apiResponse = Assert.IsType<GenericResponse2<short>>(okObjectResult.Value);
            Assert.True(apiResponse.IsSuccess);
            Assert.Equal((short)1, apiResponse.Result!.Value);
        }


        [Fact]
        public async Task EditRole_Returns_Success_When_Role_Is_Edited()
        {
            // Arrange
            var roleDto = new EditRoleDto
            {
                Id = 1,
                RoleName = "Admin",
                RoleDescription = "Administrator",
                IsDeleted = false
            };

            var mockResult = Result<bool>.Success(true);
            _roleCommandMock.Setup(service => service.EditRole(roleDto))
                .ReturnsAsync(mockResult);

            // Act
            var result = await _controller.EditRole(roleDto);
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponse2<bool>>(okResult.Value);

            // Assert
            Assert.True(response.IsSuccess);
            Assert.False(response.HasError);
            Assert.True(response.Result);
        }

        [Fact]
        public async Task EditRole_Handles_Exception()
        {
            // Arrange
            var roleDto = new EditRoleDto
            {
                Id = 1,
                RoleName = "Admin",
                RoleDescription = "Administrator",
                IsDeleted = false
            };

            _roleCommandMock.Setup(service => service.EditRole(roleDto))
                .ThrowsAsync(new System.Exception("Database error"));

            // Act & Assert
            await Assert.ThrowsAsync<System.Exception>(() => _controller.EditRole(roleDto));
        }


        [Fact]
        public async Task GetActiveRolesList_ShouldReturnOk_WithExpectedData()
        {
            // Arrange
            var mockRoles = new List<GetRoleListDto>
            {
                new GetRoleListDto { Id = 1, RoleName = "Admin", RoleDescription = "Administrator role", IsDeleted = false },
                new GetRoleListDto { Id = 2, RoleName = "User", RoleDescription = "Standard user role", IsDeleted = false }
            };

            _roleQueryMock.Setup(service => service.GetActiveRolesList()).ReturnsAsync(mockRoles);

            var expectedResponse = new RBACService.CrossCutting.GenericResponse.GenericResponseList<GetRoleListDto>
            {
                Result = mockRoles,
                Message = "Success",
                StatusCode = "200",
                IsSuccess = true,
                HasError = false
            };

            // Act
            var result = await _controller.GetActiveRolesList();
            var okResult = result.Result as OkObjectResult;

            // Debugging check
            Assert.NotNull(okResult);
            Assert.NotNull(okResult.Value);

            var apiResponse = okResult.Value as RBACService.CrossCutting.GenericResponse.GenericResponseList<GetRoleListDto>;

            // Assert
            Assert.NotNull(apiResponse);
            Assert.True(apiResponse.IsSuccess);
            Assert.False(apiResponse.HasError);
            Assert.Equal(expectedResponse.StatusCode, apiResponse.StatusCode);
            Assert.Equal("Admin", apiResponse.Result!.First().RoleName);
            Assert.Equal("User", apiResponse.Result!.Skip(1).First().RoleName);
        }

        [Fact]
        public async Task GetRolePagedList_Handles_Exception()
        {
            // Arrange
            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 10 };

            _roleQueryMock.Setup(service => service.GetRolePagedList(paginationQuery))
                .ThrowsAsync(new System.Exception("Database error"));

            // Act & Assert
            await Assert.ThrowsAsync<System.Exception>(() => _controller.GetRolePagedList(paginationQuery));
        }

        [Fact]
        public async Task GetRolePagedList_Returns_EmptyList()
        {
            // Arrange
            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 10 };
            var mockPagedList = new PaginationResult<GetRoleListDto>
            {
                TotalCount = 0,
                Records = new List<GetRoleListDto>().AsQueryable() // Ensure IQueryable
            };

            _roleQueryMock.Setup(service => service.GetRolePagedList(paginationQuery))
                .ReturnsAsync(mockPagedList);

            // Act
            var result = await _controller.GetRolePagedList(paginationQuery);
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponsePagedList<PaginationResult<GetRoleListDto>>>(okResult.Value);

            // Assert
            Assert.True(response.IsSuccess);
            Assert.Equal(0, response.Count);
        }

        [Fact]
        public async Task GetRolePagedList_Returns_ValidPagedList()
        {
            // Arrange
            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 10 };
            var mockPagedList = new PaginationResult<GetRoleListDto>
            {
                TotalCount = 2,
                Records = new List<GetRoleListDto>
            {
                new GetRoleListDto { Id = 1, RoleName = "Admin", RoleDescription = "Administrator", IsDeleted = false },
                new GetRoleListDto { Id = 2, RoleName = "User", RoleDescription = "Standard User", IsDeleted = false }
            }.AsQueryable() // Ensure IQueryable
            };

            _roleQueryMock.Setup(service => service.GetRolePagedList(paginationQuery))
                .ReturnsAsync(mockPagedList);

            // Act
            var result = await _controller.GetRolePagedList(paginationQuery);
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponsePagedList<PaginationResult<GetRoleListDto>>>(okResult.Value);

            // Assert
            Assert.True(response.IsSuccess);
            Assert.Equal(2, response.Count);
            Assert.NotNull(response.Result);
        }
    }
}

