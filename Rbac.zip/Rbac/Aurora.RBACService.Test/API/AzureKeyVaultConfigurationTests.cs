﻿namespace Aurora.RBACService.Tests.API
{
    public class AzureKeyVaultConfigurationTests
    {
        [Fact]
        public void ConfigureAzureKeyVault_ShouldAddAzureKeyVault_WhenKeyVaultIsConfigured()
        {
            // Arrange
            var mockConfig = new Mock<IConfigurationBuilder>();
            var mockRootConfig = new Mock<IConfigurationRoot>();

            // Mock the configuration values
            mockRootConfig.Setup(config => config.GetSection(CommonConstants.ISKEYVAULTCONFIGURED).Value)
                .Returns("true"); // Simulate that the Key Vault is configured
            mockRootConfig.Setup(config => config[CommonConstants.AZUREKEYVAULTURI])
                .Returns("https://mykeyvault.vault.azure.net/");
            mockRootConfig.Setup(config => config[CommonConstants.AZUREIDENTITYCLIENTID])
                .Returns("identity-client-id");

            mockConfig.Setup(config => config.Build())
                .Returns(mockRootConfig.Object);

            // Act
            var result = mockConfig.Object.ConfigureAzureKeyVault();

            // Assert: Check if the result is not null, indicating Azure Key Vault is added
            Assert.NotNull(result);
        }

        [Fact]
        public void ConfigureAzureKeyVault_ShouldNotAddAzureKeyVault_WhenKeyVaultIsNotConfigured()
        {
            // Arrange
            var mockConfig = new Mock<IConfigurationBuilder>();
            var mockRootConfig = new Mock<IConfigurationRoot>();

            // Mock the configuration values
            mockRootConfig.Setup(config => config.GetSection(CommonConstants.ISKEYVAULTCONFIGURED).Value)
                .Returns("false"); // Simulate that the Key Vault is not configured

            mockConfig.Setup(config => config.Build())
                .Returns(mockRootConfig.Object);

            // Act
            var result = mockConfig.Object.ConfigureAzureKeyVault();

            // Assert: Ensure the configuration is returned without adding Key Vault
            Assert.NotNull(result);
        }
    }
}
