﻿namespace Aurora.RBACService.Tests.API.Helper
{
    public class ResponseMessageHelperGenericTests
    {
        private readonly ResponseMessageHelper _responseMessageHelper;
        private readonly ResponseMessageHelper<object> _responseMessageHelperGeneric;

        public ResponseMessageHelperGenericTests()
        {
            _responseMessageHelper = new ResponseMessageHelper();
            _responseMessageHelperGeneric = new ResponseMessageHelper<object>();
        }

        [Fact]
        public void GetRecordsNotFoundResponseMessage_ShouldReturnCorrectResponse()
        {
            // Arrange
            var message = "No records found.";
            var expectedResponse = new GenericResponseList<object>()
            {
                HasError = true,
                IsSuccess = false,
                StatusCode = ((int)ResponseStatusCodes.RecordNotFound).ToString(),
                Message = message,
                Result = null
            };

            // Act
            var response = _responseMessageHelperGeneric.GetRecordsNotFoundResponseMessage(message);

            // Assert
            Assert.Equal(expectedResponse.Message, response.Message);
            Assert.Equal(expectedResponse.StatusCode, response.StatusCode);
            Assert.Equal(expectedResponse.HasError, response.HasError);
            Assert.Equal(expectedResponse.IsSuccess, response.IsSuccess);
        }
        [Fact]
        public void GetSuccessResponseMessage_ShouldReturnSuccessResponse_WhenMessageIsEmpty()
        {
            // Arrange
            var helper = new ResponseMessageHelper();

            // Act
            var result = helper.GetSuccessResponseMessage();

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(((int)ResponseStatusCodes.Success).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_DATA_ADDED);
        }

        [Fact]
        public void GetSuccessDeletionResponseMessage_ShouldReturnSuccessDeletionResponse_WhenMessageIsEmpty()
        {
            // Arrange
            var helper = new ResponseMessageHelper();

            // Act
            var result = helper.GetSuccessDeletionResponseMessage();

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(((int)ResponseStatusCodes.Success).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_DATA_DELETED);
        }

        [Fact]
        public void GetSuccessUpdationResponseMessage_ShouldReturnSuccessUpdateResponse_WhenMessageIsEmpty()
        {
            // Arrange
            var helper = new ResponseMessageHelper();

            // Act
            var result = helper.GetSuccessUpdationResponseMessage();

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(((int)ResponseStatusCodes.Success).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_DATA_UPDATED);
        }

        [Fact]
        public void GetRecordCreationFailedResponseMessage_ShouldReturnFailure_WhenMessageIsEmpty()
        {
            // Arrange
            var helper = new ResponseMessageHelper();

            // Act
            var result = helper.GetRecordCreationFailedResponseMessage();

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponseStatusCodes.Forbidden).ToString());
            result.Message.Should().Be(ValidationMessage.RECORD_CREATION_FAILED);
        }

        [Fact]
        public void GetRecordNotFoundResponseMessage_ShouldReturnFailure_WhenMessageIsEmpty()
        {
            // Arrange
            var helper = new ResponseMessageHelper();

            // Act
            var result = helper.GetRecordNotFoundResponseMessage();

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponseStatusCodes.NotFound).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public void GetInternalServerErrorResponseMessage_ShouldReturnError_WhenMessageIsEmpty()
        {
            // Arrange
            var helper = new ResponseMessageHelper();

            // Act
            var result = helper.GetInternalServerErrorResponseMessage();

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(((int)ResponseStatusCodes.InternalServerError).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_SERVER_ERROR);
        }

        [Fact]
        public void GetRecordAlreadyExistResponseMessage_ShouldReturnFailure_WhenMessageIsEmpty()
        {
            // Arrange
            var helper = new ResponseMessageHelper();

            // Act
            var result = helper.GetRecordAlreadyExistResponseMessage();

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponseStatusCodes.Conflict).ToString());
            result.Message.Should().Be(ResponseMessage.ALREADY_EXISTS);
        }

        [Fact]
        public void GetSuccessCreateResponseMessage_ShouldReturnSuccessCreateResponse_WhenMessageIsEmpty()
        {
            // Arrange
            var helper = new ResponseMessageHelper();

            // Act
            var result = helper.GetSuccessCreateResponseMessage();

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(((int)ResponseStatusCodes.Success_Create).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_DATA_ADDED);
        }

        [Fact]
        public void GetStatusResponseMessage_ShouldReturnCorrectResponseForSuccess()
        {
            // Arrange
            var message = "Operation successful";
            var statusCode = ResponseStatusCodes.Success;
            var expectedResponse = new GenericResponse<string>()
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ((int)statusCode).ToString(),
                Message = message
            };

            // Act
            var result = _responseMessageHelper.GetStatusResponseMessage(statusCode, message);

            // Assert
            Assert.Equal(expectedResponse.Message, result.Message);
            Assert.Equal(expectedResponse.StatusCode, result.StatusCode);
            Assert.Equal(expectedResponse.HasError, result.HasError);
            Assert.Equal(expectedResponse.IsSuccess, result.IsSuccess);
        }

        [Fact]
        public void GetStatusResponseNotSuccessMessage_ShouldReturnCorrectResponseForFailure()
        {
            // Arrange
            var message = "Operation failed";
            var statusCode = ResponseStatusCodes.BadRequest;
            var expectedResponse = new GenericResponse<string>()
            {
                HasError = true,
                IsSuccess = false,
                StatusCode = ((int)statusCode).ToString(),
                Message = message
            };

            // Act
            var result = _responseMessageHelper.GetStatusResponseNotSuccessMessage(statusCode, message);

            // Assert
            Assert.Equal(expectedResponse.Message, result.Message);
            Assert.Equal(expectedResponse.StatusCode, result.StatusCode);
            Assert.Equal(expectedResponse.HasError, result.HasError);
            Assert.Equal(expectedResponse.IsSuccess, result.IsSuccess);
        }
        [Fact]
        public void GetRecordFailureStatusResponseMessage_ShouldReturnFailureResponse()
        {
            // Arrange
            var message = "Operation failed";
            var statusCode = ResponseStatusCodes.BadRequest;

            // Act
            var result = _responseMessageHelperGeneric.GetRecordFailureStatusResponseMessage(null, statusCode, message);

            // Assert
            result.HasError.Should().BeTrue();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(((int)statusCode).ToString());
            result.Message.Should().Be(message);
            result.Result.Should().BeNull();
        }

        [Fact]
        public void GetSuccessResponseMessage_ShouldReturnSuccessResponse()
        {
            // Arrange
            var message = "Operation successful";
            var statusCode = ResponseStatusCodes.Success;
            var resultList = new List<object> { new { Id = 1, Name = "Test" } };

            // Act
            var result = _responseMessageHelperGeneric.GetSuccessResponseMessage(resultList, statusCode, message);

            // Assert
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(((int)statusCode).ToString());
            result.Message.Should().Be(message);
            result.Result.Should().NotBeNull();
            result.Result.Should().HaveCount(1);
        }

        [Fact]
        public void GetRecordDetailSuccessResponseMessage_ShouldReturnSuccessResponse()
        {
            // Arrange
            var message = "Record found";
            var statusCode = ResponseStatusCodes.Success;
            var resultObject = new { Id = 1, Name = "Test" };

            // Act
            var result = _responseMessageHelperGeneric.GetRecordDetailSuccessResponseMessage(resultObject, statusCode, message);

            // Assert
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(((int)statusCode).ToString());
            result.Message.Should().Be(message);
            result.Result.Should().NotBeNull();
        }

        [Fact]
        public void GetRecordsNotFoundResponseMessage_ShouldReturnNotFoundResponse()
        {
            // Arrange
            var expectedMessage = ResponseMessage.STATUS_NODATA;

            // Act
            var result = _responseMessageHelperGeneric.GetRecordsNotFoundResponseMessage();

            // Assert
            result.HasError.Should().BeTrue();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(((int)ResponseStatusCodes.RecordNotFound).ToString());
            result.Message.Should().Be(expectedMessage);
            result.Result.Should().BeNull();
        }

        [Fact]
        public void GetRecordNotFoundResponseMessage_ShouldReturnNotFoundResponse()
        {
            // Arrange
            var expectedMessage = ResponseMessage.STATUS_NODATA;

            // Act
            var result = _responseMessageHelperGeneric.GetRecordNotFoundResponseMessage();

            // Assert
            result.HasError.Should().BeTrue();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(((int)ResponseStatusCodes.RecordNotFound).ToString());
            result.Message.Should().Be(expectedMessage);
            result.Result.Should().BeNull();
        }

        [Fact]
        public void GetRecordDetailSuccessResponseMessage_ShouldReturnSuccessResponseWithDefaultMessage()
        {
            // Arrange
            var expectedMessage = ResponseMessage.STATUS_DATA_FOUND;
            var resultObject = new { Id = 1, Name = "Test" };

            // Act
            var result = _responseMessageHelperGeneric.GetRecordDetailSuccessResponseMessage(resultObject);

            // Assert
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponseStatusCodes.Success).ToString());
            result.Message.Should().Be(expectedMessage);
            result.Result.Should().NotBeNull();
        }

        [Fact]
        public void GetRecordDetailErrorResponseMessage_ShouldReturnServerErrorResponse()
        {
            // Arrange
            var expectedMessage = ResponseMessage.STATUS_SERVER_ERROR;

            // Act
            var result = _responseMessageHelperGeneric.GetRecordDetailErrorResponseMessage();

            // Assert
            result.HasError.Should().BeTrue();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(((int)ResponseStatusCodes.InternalServerError).ToString());
            result.Message.Should().Be(expectedMessage);
            result.Result.Should().BeNull();
        }
        [Fact]
        public void GetRecordDeletionFailedResponseMessage_ShouldReturnFailure_WhenMessageIsEmpty()
        {
            // Arrange
            var helper = new ResponseMessageHelper();

            // Act
            var result = helper.GetRecordDeletionFailedResponseMessage();

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponseStatusCodes.Forbidden).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_DATA_DELETE_FAIL);
        }
        [Fact]
        public void GetRecordUpdationFailedResponseMessage_ShouldReturnFailure_WhenMessageIsEmpty()
        {
            // Arrange
            var helper = new ResponseMessageHelper();

            // Act
            var result = helper.GetRecordUpdationFailedResponseMessage();

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponseStatusCodes.BadRequest).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_DATA_UPDATE_FAIL);
        }

        [Fact]
        public void GetFailureResponseMessage_Should_Return_Failure_Response()
        {
            // Arrange
            string message = "Failure occurred";

            // Act
            var response = _responseMessageHelper.GetFailureResponseMessage(message);

            // Assert
            response.Should().NotBeNull();
            response.StatusCode.Should().Be(((int)ResponseStatusCodes.InternalServerError).ToString());
            response.Message.Should().Be(message);
            response.HasError.Should().BeTrue();
            response.IsSuccess.Should().BeFalse();
        }

        [Fact]
        public void GetErrorResponseMessage_Should_Return_Error_Response()
        {
            // Arrange
            string message = "An error occurred";

            // Act
            var response = _responseMessageHelper.GetErrorResponseMessage(message);

            // Assert
            response.Should().NotBeNull();
            response.StatusCode.Should().Be(((int)ResponseStatusCodes.Errored).ToString());
            response.Message.Should().Be(message);
            response.HasError.Should().BeTrue();
            response.IsSuccess.Should().BeFalse();
        }

        [Fact]
        public void GetStatusResponseMessage_ShouldReturnSuccessResponse_WithResults()
        {
            // Arrange
            var resultList = new List<object> { "Item1", "Item2" };  // Sample results
            var statusCode = ResponseStatusCodes.Success;
            var message = "Operation successful";

            // Act
            var result = _responseMessageHelperGeneric.GetStatusResponseMessage(resultList, statusCode, message);

            // Assert
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(((int)statusCode).ToString());
            result.Message.Should().Be(message);
            result.Result.Should().BeEquivalentTo(resultList);  // Verifies the Results list is correct
        }

        [Fact]
        public void GetStatusResponseMessage_ShouldReturnSuccessResponse_WithEmptyResults()
        {
            // Arrange
            var resultList = new List<object>();  // Empty list
            var statusCode = ResponseStatusCodes.Success;
            var message = "Operation successful, but no data returned";

            // Act
            var result = _responseMessageHelperGeneric.GetStatusResponseMessage(resultList, statusCode, message);

            // Assert
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(((int)statusCode).ToString());
            result.Message.Should().Be(message);
            result.Result.Should().BeEmpty();  // Verifies that Results list is empty
        }

        [Fact]
        public void GetStatusResponseMessage_ShouldReturnSuccessResponse_WithNullResults()
        {
            // Arrange
            List<object> resultList = null!;  // Null list
            var statusCode = ResponseStatusCodes.Success;
            var message = "Operation successful, but no data returned";

            // Act
            var result = _responseMessageHelperGeneric.GetStatusResponseMessage(resultList, statusCode, message);

            // Assert
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(((int)statusCode).ToString());
            result.Message.Should().Be(message);
            result.Result.Should().BeNull();  // Verifies that Results is null
        }
    }
}