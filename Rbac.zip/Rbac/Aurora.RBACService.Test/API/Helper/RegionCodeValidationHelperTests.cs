﻿namespace Aurora.RBACService.Tests.API.Helper
{
    public class RegionCodeValidationHelperTests
    {
        [Fact]
        public void GetUserIdByToken_ShouldReturnUserId_WhenTokenIsValid()
        {
            // Arrange
            var helper = new RegionCodeValidationHelper();
            var userId = "12345";
            var token = GenerateValidJwtToken(userId);

            var context = new DefaultHttpContext();
            context.Request.Headers.Append("Authorization", $"Bearer {token}");

            // Act
            var result = helper.GetUserIdByToken(context.Request);

            // Assert
            result.Should().Be(userId);
        }

        [Fact]
        public void GetUserIdByToken_ShouldReturnEmptyString_WhenTokenIsInvalid()
        {
            // Arrange
            var helper = new RegionCodeValidationHelper();
            var invalidToken = "invalid.token.string";

            var context = new DefaultHttpContext();
            // Append Authorization header with an invalid token
            context.Request.Headers.Append("Authorization", $"Bearer {invalidToken}");

            // Act
            var result = helper.GetUserIdByToken(context.Request);

            // Assert
            result.Should().Be("");
        }

        [Fact]
        public void VerifyRegionCodeHeader_ShouldReturnError_WhenRegionCodeIsMissing()
        {
            // Arrange
            var helper = new RegionCodeValidationHelper();

            var context = new DefaultHttpContext();
            // Do not set the RegionCode header

            // Act
            var result = helper.VerifyRegionCodeHeader(context.Request);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
            result.Message.Should().Be(Resource.RegionCodeRequired);
        }

        [Fact]
        public void VerifyRegionCodeHeader_ShouldReturnError_WhenRegionCodeIsNotAllowed()
        {
            // Arrange
            var helper = new RegionCodeValidationHelper();
            var invalidRegionCode = "InvalidRegion"; // Assuming this is not in the allowed region codes list

            var context = new DefaultHttpContext();
            // Append invalid region code header
            context.Request.Headers.Append(CommonConstants.HEADERREGIONCODE, invalidRegionCode);

            // Act
            var result = helper.VerifyRegionCodeHeader(context.Request);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
            result.Message.Should().Be(ResponseMessage.STATUS_INVALID_REGIONCODE);
        }

        [Fact]
        public void VerifyRegionCodeHeader_ShouldReturnSuccess_WhenRegionCodeIsValid()
        {
            // Arrange
            var helper = new RegionCodeValidationHelper();
            var validRegionCode = "IDN"; // Assuming "US" is a valid region code in RegionCode.AllowedRegionCodes

            var context = new DefaultHttpContext();
            // Append valid region code header
            context.Request.Headers.Append(CommonConstants.HEADERREGIONCODE, validRegionCode);

            // Act
            var result = helper.VerifyRegionCodeHeader(context.Request);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            result.Result.Should().Be(validRegionCode);
        }

        private static string GenerateValidJwtToken(string userId)
        {
            var claims = new[] { new System.Security.Claims.Claim("sub", userId) };

            // Use a fixed 128-bit (16-byte) secret key for HS256
            var fixedKey = "12345678901234567890123456789012";  // 128-bit key (16 characters)

            var securityKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(Encoding.UTF8.GetBytes(fixedKey));
            var credentials = new Microsoft.IdentityModel.Tokens.SigningCredentials(securityKey, Microsoft.IdentityModel.Tokens.SecurityAlgorithms.HmacSha256);

            var tokenDescriptor = new JwtSecurityToken(
                issuer: "yourIssuer",
                audience: "yourAudience",
                claims: claims,
                expires: DateTime.UtcNow.AddHours(1),
                signingCredentials: credentials
            );

            var tokenHandler = new JwtSecurityTokenHandler();
            return tokenHandler.WriteToken(tokenDescriptor);
        }
    }
}
