﻿namespace Aurora.RBACService.Tests.API
{
    public class DependencyRegistrationTests
    {
        [Fact]
        public void Should_Register_RegionCodeValidationHelper_AsSingleton()
        {
            // Arrange
            var serviceCollection = new ServiceCollection();

            // Act
            serviceCollection.AddServiceDependencies();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            // Assert
            var regionCodeValidationHelper = serviceProvider.GetService<IRegionCodeValidationHelper>();
            Assert.NotNull(regionCodeValidationHelper);
            Assert.IsType<RegionCodeValidationHelper>(regionCodeValidationHelper);
        }

        [Fact]
        public void Should_Register_PatientInformationQueryService_AsScoped()
        {
            // Arrange
            var serviceCollection = new ServiceCollection();

            // Act
            serviceCollection.AddServiceDependencies();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            // Assert
            Assert.True(true);

            //todo: use this test method to write test when any scoped service available 
        }
    }
}
