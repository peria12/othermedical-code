﻿namespace Aurora.RBACService.Tests.API.Filters
{
    public class ValidationFilterAttributeTests
    {
        private readonly ValidationFilterAttribute _validationFilter;

        public ValidationFilterAttributeTests()
        {
            _validationFilter = new ValidationFilterAttribute();
        }

        [Fact]
        public void OnActionExecuting_ShouldReturnBadRequest_WhenHeaderRegionCodeIsMissing()
        {
            // Arrange
            var headers = new HeaderDictionary(); // No HEADERREGIONCODE
            var context = CreateActionExecutingContext(headers);

            // Act
            _validationFilter.OnActionExecuting(context);

            // Assert
            context.HttpContext.Response.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);
            context.Result.Should().BeOfType<JsonResult>();

            var jsonResult = context.Result as JsonResult;
            var response = jsonResult?.Value as GenericResponse<string>;

            response.Should().NotBeNull();
            response!.HasError.Should().BeTrue();
            response.IsSuccess.Should().BeFalse();
            response.Message.Should().Be(CommonConstants.ERROR_HEADER_REGION_CODE_MISSING);
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
        }

        [Fact]
        public void OnActionExecuting_ShouldAssignCorrelationId_WhenMissing()
        {
            // Arrange
            var headers = new HeaderDictionary { { CommonConstants.HEADERREGIONCODE, "TestRegion" } };
            var context = CreateActionExecutingContext(headers);

            // Act
            _validationFilter.OnActionExecuting(context);

            // Assert
            context.HttpContext.Request.Headers.ContainsKey(CommonConstants.HEADERCORRELATIONID).Should().BeTrue();
            context.HttpContext.Response.Headers.ContainsKey(CommonConstants.HEADERCORRELATIONID).Should().BeTrue();
        }

        [Fact]
        public void OnActionExecuting_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var headers = new HeaderDictionary
        {
            { CommonConstants.HEADERREGIONCODE, "TestRegion" },
            { CommonConstants.HEADERCORRELATIONID, "12345" }
        };
            var context = CreateActionExecutingContext(headers);
            context.ModelState.AddModelError("TestField", "Test error message");

            // Act
            _validationFilter.OnActionExecuting(context);

            // Assert
            context.HttpContext.Response.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);
            context.Result.Should().BeOfType<JsonResult>();

            var jsonResult = context.Result as JsonResult;
            var response = jsonResult?.Value as GenericResponse<string>;

            response.Should().NotBeNull();
            response!.HasError.Should().BeTrue();
            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
            response.Message.Should().Contain("TestField"); // Ensure model state errors are returned
        }

        [Fact]
        public void OnActionExecuting_ShouldPass_WhenHeadersAndModelStateAreValid()
        {
            // Arrange
            var headers = new HeaderDictionary
        {
            { CommonConstants.HEADERREGIONCODE, "TestRegion" },
            { CommonConstants.HEADERCORRELATIONID, "12345" }
        };
            var context = CreateActionExecutingContext(headers);

            // Act
            _validationFilter.OnActionExecuting(context);

            // Assert
            context.Result.Should().BeNull();
        }

        [Fact]
        public void OnActionExecuted_ShouldNotModifyContext()
        {
            // Arrange
            var context = new ActionExecutedContext(
                new ActionContext
                {
                    HttpContext = new DefaultHttpContext(),
                    RouteData = new Microsoft.AspNetCore.Routing.RouteData(),
                    ActionDescriptor = new Microsoft.AspNetCore.Mvc.Controllers.ControllerActionDescriptor()
                },
                new List<IFilterMetadata>(),
                new Mock<Controller>().Object
            );

            // Act
            _validationFilter.OnActionExecuted(context);

            // Assert
            context.Exception.Should().BeNull();
            context.Result.Should().BeNull();
        }

        private static ActionExecutingContext CreateActionExecutingContext(IHeaderDictionary headers)
        {
            var httpContext = new DefaultHttpContext();
            foreach (var header in headers)
            {
                httpContext.Request.Headers[header.Key] = header.Value;
            }

            return new ActionExecutingContext(
                new ActionContext
                {
                    HttpContext = httpContext,
                    RouteData = new Microsoft.AspNetCore.Routing.RouteData(),
                    ActionDescriptor = new Microsoft.AspNetCore.Mvc.Controllers.ControllerActionDescriptor()
                },
                new List<IFilterMetadata>(),
                new Dictionary<string, object?>(),
                new Mock<Controller>().Object);
        }
    }
}
