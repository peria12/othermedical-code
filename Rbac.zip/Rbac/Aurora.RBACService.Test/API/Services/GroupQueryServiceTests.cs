﻿namespace Aurora.RBACService.Tests.API.Services
{
    public class GroupQueryServiceTests
    {
        private readonly ReadOnlyDbContext _dbContext;
        private readonly IMapper _mapper;
        private readonly GroupQueryService _service;

        public GroupQueryServiceTests()
        {
            var connection = new SqliteConnection("Filename=:memory:");
            connection.Open();

            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseSqlite(connection)
                .Options;

            _dbContext = new ReadOnlyDbContext(options);
            _dbContext.Database.EnsureCreated();

            _mapper = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Group, GetGroupDto>().ReverseMap();
                cfg.CreateMap<Group, GetGroupListDto>().ReverseMap();
            }).CreateMapper();

            SeedTestData(_dbContext);
            _service = new GroupQueryService(_dbContext, _mapper);
        }

        private static void SeedTestData(ReadOnlyDbContext context)
        {
            context.Groups.AddRange(
                new Group { Id = 1, GroupName = "Admin", IsDeleted = false, CreatedBy = "Admin" },
                new Group { Id = 2, GroupName = "Editor", IsDeleted = true, CreatedBy = "Admin" }
            );

            context.Roles.AddRange(
                new Domain.Entities.RBAC.Role { Id = 100, RoleName = "Admin", CreatedBy = "Admin" },
                new Domain.Entities.RBAC.Role { Id = 101, RoleName = "Editor", CreatedBy = "Admin" }
            );


            context.GroupRoleMappings.AddRange(
                new GroupRoleMapping { Id = 1, GroupId = 1, RoleId = 100, IsDeleted = false, CreatedBy = "Admin" },
                new GroupRoleMapping { Id = 2, GroupId = 1, RoleId = 101, IsDeleted = true, CreatedBy = "Admin" }
            );

            context.UserProfiles.Add(
                new UserProfile { Id = 1, UserId = 1, GroupId = 1, CreatedBy = "Admin" }
            );

            context.SaveChanges();
        }

        [Fact]
        public async Task GetGroup_ReturnsGroupWithRoleIds()
        {
            var result = await _service.GetGroup(1);

            Assert.NotNull(result);
            Assert.Equal("Admin", result.GroupName);
            //Assert.Contains(100, result.RoleIds);
            //Assert.DoesNotContain(101, result.RoleIds); // because IsDeleted = true
        }

        [Fact]
        public async Task GetGroupEntity_ReturnsCorrectEntity()
        {
            var result = await _service.GetGroupEntity(1);

            Assert.NotNull(result);
            Assert.Equal("Admin", result.GroupName);
        }

        [Fact]
        public async Task GetGroupEntity_ReturnsNull_WhenNotFound()
        {
            var result = await _service.GetGroupEntity(99);
            Assert.Null(result);
        }

        [Fact]
        public async Task GetActiveGroupsList_ReturnsOnlyActiveGroups()
        {
            var result = await _service.GetActiveGroupsList();

            Assert.Single(result);
            Assert.Equal("Admin", result[0].GroupName);
        }

        [Fact]
        public async Task ValidateCreateInputAsync_ReturnsError_WhenDuplicateExists()
        {
            var result = await _service.ValidateCreateInputAsync(new CreateGroupDto { GroupName = "Admin" });

            Assert.False(result.IsValid);
            Assert.Single(result.Errors);
        }

        [Fact]
        public async Task ValidateCreateInputAsync_ReturnsValid_WhenNoDuplicates()
        {
            var result = await _service.ValidateCreateInputAsync(new CreateGroupDto { GroupName = "Viewer" });

            Assert.True(result.IsValid);
        }

        [Fact]
        public async Task ValidateEditInputAsync_ReturnsError_WhenDuplicateExists()
        {
            var result = await _service.ValidateEditInputAsync(new EditGroupDto { Id = 99, GroupName = "Admin" });

            Assert.False(result.IsValid);
        }

        [Fact]
        public async Task ValidateEditInputAsync_ReturnsValid_WhenNoDuplicates()
        {
            var result = await _service.ValidateEditInputAsync(new EditGroupDto { Id = 1, GroupName = "Viewer" });

            Assert.True(result.IsValid);
        }

        [Fact]
        public async Task GetGroupRoleMappings_ReturnsList()
        {
            var result = await _service.GetGroupRoleMappings(1);

            Assert.Equal(2, result.Count);
        }

        [Fact]
        public async Task GetUserProfileByUserAndGroupAsync_ReturnsMatch()
        {
            var result = await _service.GetUserProfileByUserAndGroupAsync(1, 1);

            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetUserProfileByUserAndGroupAsync_ReturnsNull_WhenNoMatch()
        {
            var result = await _service.GetUserProfileByUserAndGroupAsync(99, 1);
            Assert.Null(result);
        }
    }
}