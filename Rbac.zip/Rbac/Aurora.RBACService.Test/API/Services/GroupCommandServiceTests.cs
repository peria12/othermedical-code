﻿namespace Aurora.RBACService.Tests.API.Services
{
    public class GroupCommandServiceTests
    {
        private readonly Mock<ICommonService> _commonServiceMock = new();
        private readonly Mock<IGroupQueryService> _groupQueryServiceMock = new();
        private readonly Mock<IMapper> _mapperMock = new();
        private readonly Mock<ILogger<GroupCommandService>> _loggerMock = new();

        private readonly ReadWriteDbContext _dbContext;
        private readonly DbConnection _connection;

        private readonly GroupCommandService _service;

        public GroupCommandServiceTests()
        {
            _connection = new SqliteConnection("DataSource=:memory:");
            _connection.Open();

            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseSqlite(_connection)
                .Options;

            var config = new ConfigurationBuilder().Build();

            _dbContext = new ReadWriteDbContext(config, options);
            _dbContext.Database.EnsureCreated();

            _service = new GroupCommandService(
                _dbContext,
                _commonServiceMock.Object,
                _groupQueryServiceMock.Object,
                _mapperMock.Object,
                _loggerMock.Object);
        }

        [Fact]
        public async Task CreateGroup_ShouldReturnFailure_WhenValidationFails()
        {
            var dto = new CreateGroupDto { GroupName = "GroupName" };
            _groupQueryServiceMock.Setup(x => x.ValidateCreateInputAsync(dto))
                .ReturnsAsync(new DataValidationResult
                {
                    IsValid = false,
                    Errors = new List<ValidationError> {
                        new ValidationError {
                            PropertyName = "GroupName",
                            ErrorMessage = "Group already exists."
                        }
                    }
                });

            var result = await _service.CreateGroup(dto);

            result.IsSuccess.Should().BeFalse();
            result.ValidationMessage.Should().Contain("Group already exists");
        }

        [Fact]
        public async Task CreateGroup_ShouldInsertGroupWithoutMappings_WhenNoRolesProvided()
        {
            var dto = new CreateGroupDto
            {
                GroupName = "No Role Group",
                GroupDescription = "Group with no roles"
            };

            _groupQueryServiceMock.Setup(x => x.ValidateCreateInputAsync(dto))
                .ReturnsAsync(new DataValidationResult { IsValid = true });

            _commonServiceMock.Setup(x => x.GetLoggedUserName()).Returns("tester");

            _mapperMock.Setup(x => x.Map<Group>(dto)).Returns(new Group
            {
                GroupName = dto.GroupName,
                GroupDescription = dto.GroupDescription,
                CreatedBy = "",
                CreatedDate = DateTime.MinValue,
                IsDeleted = false
            });

            var result = await _service.CreateGroup(dto);

            result.IsSuccess.Should().BeTrue();
            var savedGroup = await _dbContext.Groups.FirstOrDefaultAsync(g => g.GroupName == dto.GroupName);
            savedGroup.Should().NotBeNull();

            var roleMappings = await _dbContext.GroupRoleMappings.CountAsync(m => m.GroupId == savedGroup!.Id);
            roleMappings.Should().Be(0);
        }

        [Fact]
        public async Task CreateGroup_ShouldInsertGroupAndMappings_WhenValid()
        {
            var role1 = new Domain.Entities.RBAC.Role { Id = 1, RoleName = "Admin", CreatedBy = "Admin" };
            var role2 = new Domain.Entities.RBAC.Role { Id = 2, RoleName = "Editor", CreatedBy = "Admin" };
            await _dbContext.Roles.AddRangeAsync(role1, role2);
            await _dbContext.SaveChangesAsync();


            var dto = new CreateGroupDto
            {
                GroupName = "Test Group",
                GroupDescription = "A test group",
                RoleIds = new List<short> { 1, 2 },
                IsDeleted = false
            };

            _groupQueryServiceMock.Setup(x => x.ValidateCreateInputAsync(dto))
                .ReturnsAsync(new DataValidationResult { IsValid = true });

            _commonServiceMock.Setup(x => x.GetLoggedUserName()).Returns("tester");

            _mapperMock.Setup(x => x.Map<Group>(dto)).Returns(new Group
            {
                GroupName = dto.GroupName,
                GroupDescription = dto.GroupDescription,
                CreatedBy = "",
                CreatedDate = DateTime.MinValue,
                IsDeleted = false
            });

            var result = await _service.CreateGroup(dto);

            result.IsSuccess.Should().BeTrue();
            result.Value.Should().BeGreaterThan(0);

            var savedGroup = await _dbContext.Groups.FirstOrDefaultAsync(g => g.GroupName == dto.GroupName);
            savedGroup.Should().NotBeNull();
            savedGroup!.GroupDescription.Should().Be(dto.GroupDescription);

            var roleMappings = await _dbContext.GroupRoleMappings
                .CountAsync(m => m.GroupId == savedGroup.Id);
            roleMappings.Should().Be(2);
        }

        [Fact]
        public async Task CreateGroup_ShouldRollback_WhenExceptionThrown()
        {
            var dto = new CreateGroupDto { GroupName = "ExGroup", RoleIds = new List<short> { 1 } };

            _groupQueryServiceMock.Setup(x => x.ValidateCreateInputAsync(dto)).ReturnsAsync(new DataValidationResult { IsValid = true });
            _commonServiceMock.Setup(x => x.GetLoggedUserName()).Returns("tester");
            _mapperMock.Setup(x => x.Map<Group>(dto)).Returns(new Group { GroupName = dto.GroupName, CreatedBy = "Admin" });

            _dbContext.Groups.Add(new Group { GroupName = "placeholder", CreatedBy = "Admin" });
            await _dbContext.SaveChangesAsync();

            _dbContext.GroupRoleMappings.Add(new GroupRoleMapping { GroupId = -1, RoleId = 1, CreatedBy = "Admin" });

            Func<Task> action = async () => await _service.CreateGroup(dto);

            await action.Should().ThrowAsync<Exception>();
        }

        [Fact]
        public async Task EditGroup_ShouldReturnFalse_WhenGroupNotFound()
        {
            _groupQueryServiceMock.Setup(x => x.GetGroupEntity(It.IsAny<short>())).ReturnsAsync((Group)null!);

            var result = await _service.EditGroup(new EditGroupDto { Id = 1, GroupName = "GroupName" });

            result.IsSuccess.Should().BeTrue();
            result.Value.Should().BeFalse();
        }

        [Fact]
        public async Task EditGroup_ShouldReturnFailure_WhenValidationFails()
        {
            var dto = new EditGroupDto { Id = 100, GroupName = "InvalidEdit" };

            _groupQueryServiceMock.Setup(x => x.GetGroupEntity(dto.Id)).ReturnsAsync(new Group { GroupName = "InvalidEdit", CreatedBy = "Admin" });
            _groupQueryServiceMock.Setup(x => x.ValidateEditInputAsync(dto)).ReturnsAsync(new DataValidationResult
            {
                IsValid = false,
                Errors = new List<ValidationError> { new ValidationError { PropertyName = "GroupName", ErrorMessage = "Invalid" } }
            });

            var result = await _service.EditGroup(dto);

            result.IsSuccess.Should().BeFalse();
            result.ValidationMessage.Should().Contain("Invalid");
        }

        [Fact]
        public async Task EditGroup_ShouldRollback_WhenExceptionThrown()
        {
            var dto = new EditGroupDto { Id = 1, GroupName = "EditTest" };
            var existingGroup = new Group { Id = 1, GroupName = "OldName", CreatedBy = "Admin" };

            await _dbContext.Groups.AddAsync(existingGroup);
            await _dbContext.SaveChangesAsync();

            _groupQueryServiceMock.Setup(x => x.GetGroupEntity(dto.Id)).ReturnsAsync(existingGroup);
            _groupQueryServiceMock.Setup(x => x.ValidateEditInputAsync(dto)).ReturnsAsync(new DataValidationResult { IsValid = true });
            _mapperMock.Setup(x => x.Map(dto, existingGroup)).Returns(existingGroup);
            _commonServiceMock.Setup(x => x.GetLoggedUserName()).Returns("editor");

            // Simulate exception
            _dbContext.Add(new GroupRoleMapping { GroupId = -1, RoleId = 1, CreatedBy = "Admin" });

            Func<Task> action = async () => await _service.EditGroup(dto);

            await action.Should().ThrowAsync<Exception>();
        }

        [Fact]
        public async Task UpdateUserGroupLink_ShouldReturnFalse_WhenUserGroupNotFound()
        {
            _groupQueryServiceMock.Setup(x => x.GetUserProfileByUserAndGroupAsync(1, 1)).ReturnsAsync((UserProfile)null!);

            var result = await _service.UpdateUserGroupLink(new UserGroupLinkDto { UserId = 1, GroupId = 1 });

            result.Should().BeFalse();
        }

        [Fact]
        public async Task UpdateUserGroupLink_ShouldReturnTrue_WhenNoChange()
        {
            var userProfile = new UserProfile { UserId = 1, GroupId = 1, IsDeleted = false, CreatedBy = "Admin" };
            _groupQueryServiceMock.Setup(x => x.GetUserProfileByUserAndGroupAsync(1, 1)).ReturnsAsync(userProfile);

            var result = await _service.UpdateUserGroupLink(new UserGroupLinkDto { UserId = 1, GroupId = 1, IsDeleted = false });

            result.Should().BeTrue();
        }

        [Fact]
        public async Task UpdateUserGroupLink_ShouldUpdate_WhenChangeDetected()
        {
            var userProfile = new UserProfile { UserId = 1, GroupId = 1, IsDeleted = false, CreatedBy = "Admin" };
            _groupQueryServiceMock.Setup(x => x.GetUserProfileByUserAndGroupAsync(1, 1)).ReturnsAsync(userProfile);
            _commonServiceMock.Setup(x => x.GetLoggedUserName()).Returns("Admin");

            var result = await _service.UpdateUserGroupLink(new UserGroupLinkDto { UserId = 1, GroupId = 1, IsDeleted = true });

            result.Should().BeTrue();
        }

        [Fact]
        public async Task UpdateUserGroupLink_ShouldLogError_WhenExceptionOccurs()
        {
            _groupQueryServiceMock.Setup(x => x.GetUserProfileByUserAndGroupAsync(It.IsAny<int>(), It.IsAny<short>())).ThrowsAsync(new Exception("DB error"));

            var result = await _service.UpdateUserGroupLink(new UserGroupLinkDto { UserId = 1, GroupId = 1 });

            result.Should().BeFalse();
        }
        [Fact]
        public async Task EditGroup_ShouldUpdateGroupAndMappings_WhenValid()
        {
            // Arrange
            var group = new Group { Id = 1, GroupName = "OriginalGroup", CreatedBy = "seed", CreatedDate = DateTime.UtcNow };
            var roles = new List<Domain.Entities.RBAC.Role>
            {
                new Domain.Entities.RBAC.Role { Id = 1, RoleName = "Reader" , CreatedBy = "Admin"},
                new Domain.Entities.RBAC.Role { Id = 2, RoleName = "Writer" , CreatedBy = "Admin"},
                new Domain.Entities.RBAC.Role { Id = 3, RoleName = "Admin" , CreatedBy = "Admin"}
            };
            var existingMappings = new List<GroupRoleMapping>
            {
                new GroupRoleMapping { GroupId = 1, RoleId = 1, IsDeleted = false, CreatedBy = "Admin" }, // Should be deleted
                new GroupRoleMapping { GroupId = 1, RoleId = 2, IsDeleted = true,CreatedBy = "Admin"  }   // Should be reactivated
            };

            await _dbContext.Groups.AddAsync(group);
            await _dbContext.Roles.AddRangeAsync(roles);
            await _dbContext.GroupRoleMappings.AddRangeAsync(existingMappings);
            await _dbContext.SaveChangesAsync();

            var dto = new EditGroupDto { Id = 1, GroupName = "UpdatedGroup", RoleIds = new List<short> { 2, 3 } };

            _groupQueryServiceMock.Setup(x => x.GetGroupEntity(dto.Id)).ReturnsAsync(group);
            _groupQueryServiceMock.Setup(x => x.ValidateEditInputAsync(dto)).ReturnsAsync(new DataValidationResult { IsValid = true });
            _groupQueryServiceMock.Setup(x => x.GetGroupRoleMappings(dto.Id)).ReturnsAsync(existingMappings);
            _commonServiceMock.Setup(x => x.GetLoggedUserName()).Returns("editor");

            _mapperMock.Setup(x => x.Map(dto, group)).Returns(group);

            // Act
            var result = await _service.EditGroup(dto);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Value.Should().BeTrue();

            var updatedMappings = await _dbContext.GroupRoleMappings
                .Where(m => m.GroupId == dto.Id && !m.IsDeleted)
                .ToListAsync();
            updatedMappings.Select(m => m.RoleId).Should().BeEquivalentTo(new short[] { 2, 3 });
        }
    }

}
