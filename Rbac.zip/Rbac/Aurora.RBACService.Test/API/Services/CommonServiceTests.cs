﻿namespace Aurora.RBACService.Tests.API.Services
{
    public class CommonServiceTests
    {
        private readonly Mock<IHttpContextAccessor> _httpContextAccessorMock;
        private readonly DefaultHttpContext _httpContext;
        private readonly CommonService _service;

        public CommonServiceTests()
        {
            _httpContextAccessorMock = new Mock<IHttpContextAccessor>();
            _httpContext = new DefaultHttpContext();
            _httpContextAccessorMock.Setup(x => x.HttpContext).Returns(_httpContext);
            _service = new CommonService(_httpContextAccessorMock.Object);
        }

        [Fact]
        public void Constructor_ShouldThrow_WhenNullAccessor()
        {
            Assert.Throws<ArgumentNullException>(() => new CommonService(null!));
        }

        [Fact]
        public void GetLoggedUserId_ShouldReturnUserId_WhenExists()
        {
            _httpContext.Items["LOGGED_IN_USER_ID"] = 1001;
            var result = _service.GetLoggedUserId();
            Assert.Equal(1001, result);
        }

        [Fact]
        public void GetLoggedUserId_ShouldThrow_WhenKeyMissing()
        {
            Assert.Throws<ArgumentException>(() => _service.GetLoggedUserId());
        }

        [Fact]
        public void GetLoggedUserId_ShouldThrow_WhenValueIsNull()
        {
            _httpContext.Items["LOGGED_IN_USER_ID"] = null;
            Assert.Throws<ArgumentException>(() => _service.GetLoggedUserId());
        }

        [Fact]
        public void GetLoggedUserName_ShouldReturnUsername_WhenExists()
        {
            _httpContext.Items["LOGGED_IN_USERNAME"] = "testuser";
            var result = _service.GetLoggedUserName();
            Assert.Equal("testuser", result);
        }

        [Fact]
        public void GetLoggedUserName_ShouldThrow_WhenKeyMissing()
        {
            Assert.Throws<ArgumentException>(() => _service.GetLoggedUserName());
        }

        [Fact]
        public void GetLoggedUserName_ShouldThrow_WhenValueIsNull()
        {
            _httpContext.Items["LOGGED_IN_USERNAME"] = null;
            Assert.Throws<ArgumentException>(() => _service.GetLoggedUserName());
        }

        [Fact]
        public void GetLoggedUserRoles_ShouldReturnList_WhenExists()
        {
            var roles = new List<short> { 1, 2 };
            _httpContext.Items["LOGGED_IN_USER_ROLES"] = roles;
            var result = _service.GetLoggedUserRoles();
            Assert.Equal(roles, result);
        }

        [Fact]
        public void GetLoggedUserRoles_ShouldReturnEmptyList_WhenKeyMissing()
        {
            var result = _service.GetLoggedUserRoles();
            Assert.Empty(result);
        }

        [Fact]
        public void GetLoggedUserRoles_ShouldReturnEmptyList_WhenValueIsNotList()
        {
            _httpContext.Items["LOGGED_IN_USER_ROLES"] = "invalid";
            var result = _service.GetLoggedUserRoles();
            Assert.Empty(result);
        }

        [Fact]
        public void GetRegionCode_ShouldReturnCode_WhenExists()
        {
            _httpContext.Items["RegionCode"] = "MYS";
            var result = _service.GetRegionCode();
            Assert.Equal("MYS", result);
        }

        [Fact]
        public void GetRegionCode_ShouldThrow_WhenKeyMissing()
        {
            Assert.Throws<ArgumentException>(() => _service.GetRegionCode());
        }

        [Fact]
        public void GetRegionCode_ShouldThrow_WhenValueIsNull()
        {
            _httpContext.Items["RegionCode"] = null;
            Assert.Throws<ArgumentException>(() => _service.GetRegionCode());
        }
    }
}
