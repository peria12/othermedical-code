﻿namespace Aurora.RBACService.Tests.CrossCutting
{
    public class HttpClientServiceTests
    {
        private readonly Mock<IHttpClientFactory> _mockFactory = new();
        private readonly Mock<IHttpContextAccessor> _mockContextAccessor = new();
        private readonly Mock<IConfiguration> _mockConfiguration = new();

        private static DefaultHttpContext CreateHttpContext(bool includeUsername = true, string regionCode = "US")
        {
            var context = new DefaultHttpContext();
            context.Request.Headers[CommonConstants.HeaderRegionCode] = new StringValues(regionCode);
            if (includeUsername)
            {
                var claims = new[] { new Claim(AppConstants.Preferred_Username, "testuser") };
                context.User = new ClaimsPrincipal(new ClaimsIdentity(claims));
            }
            return context;
        }

        [Fact]
        public async Task PutAsyncCall_ReturnsOkResponse()
        {
            // Arrange
            const int fakeTimeout = 30;

            // Setup configuration to return fake timeout
            var mockTimeoutSection = new Mock<IConfigurationSection>();
            mockTimeoutSection.Setup(s => s.Value).Returns(fakeTimeout.ToString());

            var mockConfiguration = new Mock<IConfiguration>();
            mockConfiguration.Setup(c => c.GetSection(AppConstants.HttpClientTimeout))
                             .Returns(mockTimeoutSection.Object);

            // Setup HttpContext
            var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
            var context = new DefaultHttpContext();
            context.Request.Headers[CommonConstants.HeaderRegionCode] = "US";
            var claims = new[] { new Claim(AppConstants.Preferred_Username, "testuser") };
            context.User = new ClaimsPrincipal(new ClaimsIdentity(claims));
            mockHttpContextAccessor.Setup(x => x.HttpContext).Returns(context);

            // Setup HttpClient
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("{\"updated\": true}")
            };
            var handler = new MockHttpMessageHandler(response);
            var httpClient = new HttpClient(handler);

            var mockFactory = new Mock<IHttpClientFactory>();
            mockFactory.Setup(f => f.CreateClient(It.IsAny<string>())).Returns(httpClient);

            // Setup logger & custom logger
            var mockLogger = new Mock<ILogger<HttpClientService>>();

            // Create service
            var service = new TestableHttpClientService(
                mockHttpContextAccessor.Object,
                mockConfiguration.Object,
                mockFactory.Object

            );

            // Act
            var result = await service.PutAsyncCall("https://example.com", new { Name = "Jane" }, "scope");

            // Assert
            Assert.Equal(HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public async Task GetAsyncCall_ReturnsOkResponse()
        {
            // Arrange
            const int fakeTimeout = 30;

            var mockTimeoutSection = new Mock<IConfigurationSection>();
            mockTimeoutSection.Setup(s => s.Value).Returns(fakeTimeout.ToString());

            var mockConfiguration = new Mock<IConfiguration>();
            mockConfiguration.Setup(c => c.GetSection(AppConstants.HttpClientTimeout))
                             .Returns(mockTimeoutSection.Object);

            var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
            var context = new DefaultHttpContext();
            context.Request.Headers[CommonConstants.HeaderRegionCode] = "US";
            var claims = new[] { new Claim(AppConstants.Preferred_Username, "testuser") };
            context.User = new ClaimsPrincipal(new ClaimsIdentity(claims));
            mockHttpContextAccessor.Setup(x => x.HttpContext).Returns(context);

            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("{\"data\": 123}")
            };
            var handler = new MockHttpMessageHandler(response);
            var httpClient = new HttpClient(handler);

            var mockFactory = new Mock<IHttpClientFactory>();
            mockFactory.Setup(f => f.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var mockLogger = new Mock<ILogger<HttpClientService>>();
            var service = new TestableHttpClientService(
                mockHttpContextAccessor.Object,
                mockConfiguration.Object,
                mockFactory.Object
            );

            // Act
            var result = await service.GetAsyncCall("https://example.com", "scope");

            // Assert
            Assert.Equal(HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public async Task DeleteAsyncCall_ReturnsOkResponse()
        {
            // Arrange
            const int fakeTimeout = 30;

            var mockTimeoutSection = new Mock<IConfigurationSection>();
            mockTimeoutSection.Setup(s => s.Value).Returns(fakeTimeout.ToString());

            var mockConfiguration = new Mock<IConfiguration>();
            mockConfiguration.Setup(c => c.GetSection(AppConstants.HttpClientTimeout))
                             .Returns(mockTimeoutSection.Object);

            var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
            var context = new DefaultHttpContext();
            context.Request.Headers[CommonConstants.HeaderRegionCode] = "US";
            var claims = new[] { new Claim(AppConstants.Preferred_Username, "testuser") };
            context.User = new ClaimsPrincipal(new ClaimsIdentity(claims));
            mockHttpContextAccessor.Setup(x => x.HttpContext).Returns(context);

            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("{\"message\": \"ok\"}")
            };
            var handler = new MockHttpMessageHandler(response);
            var httpClient = new HttpClient(handler);

            var mockFactory = new Mock<IHttpClientFactory>();
            mockFactory.Setup(f => f.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var mockLogger = new Mock<ILogger<HttpClientService>>();

            var service = new TestableHttpClientService(
                mockHttpContextAccessor.Object,
                mockConfiguration.Object,
                mockFactory.Object
            );

            // Act
            var result = await service.DeleteAsyncCall("https://example.com", "scope");

            // Assert
            Assert.Equal(HttpStatusCode.OK, result.StatusCode);
        }


        // Helpers

        [Fact]
        public void PostAsyncCall_ReturnsInternalServerError_OnException()
        {
            _mockFactory.Setup(f => f.CreateClient(It.IsAny<string>()))
                .Throws(new HttpRequestException("Server down"));

            var context = CreateHttpContext();
            _mockContextAccessor.Setup(c => c.HttpContext).Returns(context);

            var service = new HttpClientService(_mockContextAccessor.Object, _mockConfiguration.Object,
                _mockFactory.Object);

            Assert.Throws<AggregateException>(() => service.PostAsyncCall("https://example.com", new { }, "scope").Result);
        }

        [Fact]
        public async Task PostAsyncCall_ShouldUseTimeoutFromConfig()
        {
            // Arrange
            const int fakeTimeout = 30;
            var mockTimeoutSection = new Mock<IConfigurationSection>();
            mockTimeoutSection.Setup(x => x.Value).Returns(fakeTimeout.ToString());

            _mockConfiguration
                .Setup(x => x.GetSection(AppConstants.HttpClientTimeout))
                .Returns(mockTimeoutSection.Object);

            var context = new DefaultHttpContext();
            context.Request.Headers[CommonConstants.HeaderRegionCode] = "US";
            context.User = new ClaimsPrincipal();

            _mockContextAccessor.Setup(m => m.HttpContext).Returns(context);

            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("{\"message\": \"ok\"}")
            };
            var handler = new MockHttpMessageHandler(response);
            var client = new HttpClient(handler);

            _mockFactory.Setup(f => f.CreateClient(It.IsAny<string>())).Returns(client);

            var service = new TestableHttpClientService(
                _mockContextAccessor.Object,
                _mockConfiguration.Object,
                _mockFactory.Object
            );

            // Act
            var result = await service.PostAsyncCall("https://example.com", new { Name = "UnitTest" }, "scope");

            // Assert
            Assert.Equal(HttpStatusCode.OK, result.StatusCode);
        }
        [Fact]
        public async Task Aurora_PostAsyncCall_ShouldUseTimeoutFromConfig()
        {
            // Arrange
            const int fakeTimeout = 30;
            var mockTimeoutSection = new Mock<IConfigurationSection>();
            mockTimeoutSection.Setup(x => x.Value).Returns(fakeTimeout.ToString());

            _mockConfiguration
                .Setup(x => x.GetSection(AppConstants.HttpClientTimeout))
                .Returns(mockTimeoutSection.Object);

            var context = new DefaultHttpContext();
            context.Request.Headers[CommonConstants.HeaderRegionCode] = "US";
            context.User = new ClaimsPrincipal();

            _mockContextAccessor.Setup(m => m.HttpContext).Returns(context);

            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("{\"message\": \"ok\"}")
            };
            var handler = new MockHttpMessageHandler(response);
            var client = new HttpClient(handler);

            _mockFactory.Setup(f => f.CreateClient(It.IsAny<string>())).Returns(client);

            var service = new TestableHttpClientService(
                _mockContextAccessor.Object,
                _mockConfiguration.Object,
                _mockFactory.Object
            );

            // Act
            var result = await service.Aurora_PostAsyncCall("https://example.com", new { Name = "UnitTest" });

            // Assert
            Assert.Equal(HttpStatusCode.OK, result.StatusCode);
        }
    }

    // 🔧 Helper class to fake token fetching
    public class TestableHttpClientService : HttpClientService
    {
        public TestableHttpClientService(
            IHttpContextAccessor accessor
            , IConfiguration configuration
            , IHttpClientFactory httpClientFactory
            )
            : base(accessor, configuration, httpClientFactory) { }

    }

    // 🔧 Mock handler to intercept HTTP calls
    public class MockHttpMessageHandler : HttpMessageHandler
    {
        private readonly HttpResponseMessage _response;

        public MockHttpMessageHandler(HttpResponseMessage response)
        {
            _response = response;
        }

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            return Task.FromResult(_response);
        }

    }


}


