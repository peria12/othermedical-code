﻿namespace Aurora.RBACService.Tests.CrossCutting.Localization
{
    public class TestableLanguageWorkerService(IConfiguration configuration,
       IHttpClientService httpClientService,
       ILogger<LanguageWorkerService> logger
        ) : LanguageWorkerService(configuration, httpClientService, logger)
    {
        public bool WasExecuted { get; private set; } = false;

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            WasExecuted = true;
            await base.ExecuteAsync(stoppingToken);
        }
    }

    public class LanguageWorkerServiceTests
    {
        private Mock<IHttpClientService>? mockHttpClientService;
        private readonly Mock<ILogger<LanguageWorkerService>> _logger;
        private readonly IConfiguration _mockConfig;
        private readonly string _appGroupCode = "MCS";
        private readonly string _testContainer = "test-container";
        private readonly string _testFolder = "testjson";
        private readonly string _testLanguageCode = "ID";
        private readonly string _cdnUrl = "https://testcdn.com";
        private readonly string _cdnSASTokenValue = "343243fdddd";
        private readonly string _languageServiceApiUrl = "TestLanguageServiceAPIUrl";
        private readonly string _languageAbsoluteExpiryMinutes = "10";
        private readonly string _languageServiceAPIClientId = "3231dd";


        public LanguageWorkerServiceTests()
        {

            var inMemorySettings = new Dictionary<string, string?> {
                { CommonConstants.CDNJsonFolderName, _testFolder },
                { CommonConstants.CDNContainerName, _testContainer },
                { CommonConstants.CDNUrl, _cdnUrl },
                { CommonConstants.CDNSASToken, _cdnSASTokenValue },
                { CommonConstants.LanguageAbsoluteExpiryMinutes, _languageAbsoluteExpiryMinutes },
                { CommonConstants.MSGroupCode, _appGroupCode },
                { CommonConstants.LanguageServiceAPIURL, _languageServiceApiUrl },
                { CommonConstants.LanguageServiceAPIClientId, _languageServiceAPIClientId }
            };

            _mockConfig = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            _logger = new Mock<ILogger<LanguageWorkerService>>();
        }

        [Fact]
        public void Test_Start_WithValidLanguageCodes_AND_NoCDN_ShouldSetCache()
        {
            // Arrange
            List<LanguageCodeDto> languageCodes = [new LanguageCodeDto { LanguageCode = "ID" }];
            List<LanguageResourceDto> resources = [new LanguageResourceDto { Key = "RECORD_FOUND", Value = "Record Found" }];

            mockHttpClientService = new Mock<IHttpClientService>();

            mockHttpClientService.Setup(h => h.GetAsyncCall($"TestLanguageServiceAPIUrl/{CommonConstants.GetActiveLanguageCodes}"
                , It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageCodeDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                        Result = languageCodes,
                        IsSuccess = true
                    }))
                });

            string testResourceUrl = $"TestLanguageServiceAPIUrl/{CommonConstants.GetLanguageResources}?groupCode={_appGroupCode}&languageCode={_testLanguageCode}";
            mockHttpClientService.Setup(h => h.GetAsyncCall(testResourceUrl, It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageResourceDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                        Result = resources
                    }))
                });

            // Arrange
            using CancellationTokenSource stoppingTokenSource = new();
            TestableLanguageWorkerService service = new(_mockConfig,
                mockHttpClientService.Object, _logger.Object);

            // Act
            Task executionTask = service.StartAsync(stoppingTokenSource.Token);
            stoppingTokenSource.Cancel(); // Cancel the task

            // Assert
            Assert.True(service.WasExecuted);
            Assert.True(executionTask.IsCompleted);
            Assert.False(executionTask.IsCanceled);
        }

        [Fact]
        public void Test_Start_WithValidLanguageCodes_AND_GetCDNFile_ShouldSetCache()
        {
            // Arrange
            List<LanguageCodeDto> languageCodes = [new LanguageCodeDto { LanguageCode = "ID" }];
            List<LanguageResourceDto> resources = [new LanguageResourceDto { Key = "RECORD_FOUND", Value = "Record Found" }];

            mockHttpClientService = new Mock<IHttpClientService>();

            mockHttpClientService.Setup(h => h.GetAsyncCall($"TestLanguageServiceAPIUrl/{CommonConstants.GetActiveLanguageCodes}"
                , It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageCodeDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                        Result = languageCodes,
                        IsSuccess = true
                    }))
                });

            string jsonContent = JsonConvert.SerializeObject(resources);

            string fileName = $"{_testFolder}/{CommonConstants.CDNFilePrefix}_{_appGroupCode}_{_testLanguageCode}{CommonConstants.CDNFileExtension}".ToLower();
            mockHttpClientService.Setup(h => h.GetStringAsync($"{_cdnUrl}/{_testContainer}/{fileName}?{_cdnSASTokenValue}")).ReturnsAsync(jsonContent);

            // Arrange
            using CancellationTokenSource stoppingTokenSource = new();
            TestableLanguageWorkerService service = new(_mockConfig,
                mockHttpClientService.Object, _logger.Object);

            // Act
            Task executionTask = service.StartAsync(stoppingTokenSource.Token);
            stoppingTokenSource.Cancel(); // Cancel the task

            // Assert
            Assert.True(service.WasExecuted);
            Assert.True(executionTask.IsCompleted);
            Assert.False(executionTask.IsCanceled);
        }

        [Fact]
        public void Test_Start_WithValidLanguageCodes_ExceptionThrown_GetGroupLanguageResource()
        {
            // Arrange
            List<LanguageCodeDto> languageCodes = [new LanguageCodeDto { LanguageCode = "ID" }];

            mockHttpClientService = new Mock<IHttpClientService>();

            mockHttpClientService.Setup(h => h.GetAsyncCall($"TestLanguageServiceAPIUrl/{CommonConstants.GetActiveLanguageCodes}"
                , It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageCodeDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                        Result = languageCodes,
                        IsSuccess = true
                    }))
                });

            string testResourceUrl = $"TestLanguageServiceAPIUrl/{CommonConstants.GetLanguageResources}?groupCode={_appGroupCode}&languageCode={_testLanguageCode}";
            mockHttpClientService.Setup(h => h.GetAsyncCall(testResourceUrl, It.IsAny<string>()))
                .Throws(new Exception("Get resources error"));

            // Arrange
            using CancellationTokenSource stoppingTokenSource = new();
            TestableLanguageWorkerService service = new(_mockConfig,
                mockHttpClientService.Object, _logger.Object);

            // Act
            Task executionTask = service.StartAsync(stoppingTokenSource.Token);
            stoppingTokenSource.Cancel(); // Cancel the task

            // Assert
            Assert.True(service.WasExecuted);
            Assert.True(executionTask.IsCompleted);
            Assert.False(executionTask.IsCanceled);
        }

        [Fact]
        public void Test_Start_WithValidLanguageCodes_ExceptionThrown_GetActiveLanguageCodes()
        {
            // Arrange
            mockHttpClientService = new Mock<IHttpClientService>();
            mockHttpClientService.Setup(h => h.GetAsyncCall($"TestLanguageServiceAPIUrl/{CommonConstants.GetActiveLanguageCodes}"
               , It.IsAny<string>()))
              .Throws(new Exception("Get language code error"));

            using CancellationTokenSource stoppingTokenSource = new();
            TestableLanguageWorkerService service = new(_mockConfig,
                mockHttpClientService.Object, _logger.Object);

            // Act
            Task executionTask = service.StartAsync(stoppingTokenSource.Token);
            stoppingTokenSource.Cancel(); // Cancel the task

            // Assert
            Assert.True(service.WasExecuted);
            Assert.True(executionTask.IsCompleted);
            Assert.False(executionTask.IsCanceled);
        }

        [Fact]
        public void Test_GetActiveLanguageCodes_NoRecordFound()
        {
            // Arrange
            mockHttpClientService = new Mock<IHttpClientService>();
            mockHttpClientService.Setup(h => h.GetAsyncCall($"TestLanguageServiceAPIUrl/{CommonConstants.GetActiveLanguageCodes}"
               , It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.NotFound)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageCodeDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_NOTFOUND,
                        IsSuccess = false
                    }))
                });

            using CancellationTokenSource stoppingTokenSource = new();
            TestableLanguageWorkerService service = new(_mockConfig,
                mockHttpClientService.Object, _logger.Object);

            // Act
            Task executionTask = service.StartAsync(stoppingTokenSource.Token);
            stoppingTokenSource.Cancel(); // Cancel the task

            // Assert
            Assert.True(service.WasExecuted);
            Assert.True(executionTask.IsCompleted);
            Assert.False(executionTask.IsCanceled);
        }

        [Fact]
        public void Test_GetGroupLanguageResource_NoRecordFound()
        {
            // Arrange
            List<LanguageCodeDto> languageCodes = [new LanguageCodeDto { LanguageCode = "ID" }];

            mockHttpClientService = new Mock<IHttpClientService>();

            mockHttpClientService.Setup(h => h.GetAsyncCall($"TestLanguageServiceAPIUrl/{CommonConstants.GetActiveLanguageCodes}"
                , It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageCodeDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                        Result = languageCodes,
                        IsSuccess = true
                    }))
                });

            string testResourceUrl = $"TestLanguageServiceAPIUrl/{CommonConstants.GetLanguageResources}?groupCode={_appGroupCode}&languageCode={_testLanguageCode}";
            mockHttpClientService.Setup(h => h.GetAsyncCall(testResourceUrl, It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.NotFound)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageResourceDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_NOTFOUND,
                        IsSuccess = false
                    }))
                });

            using CancellationTokenSource stoppingTokenSource = new();
            TestableLanguageWorkerService service = new(_mockConfig,
                mockHttpClientService.Object, _logger.Object);

            // Act
            Task executionTask = service.StartAsync(stoppingTokenSource.Token);
            stoppingTokenSource.Cancel(); // Cancel the task

            // Assert
            Assert.True(service.WasExecuted);
            Assert.True(executionTask.IsCompleted);
            Assert.False(executionTask.IsCanceled);
        }

        [Fact]
        public void Test_Start_WithInValidLanguageCodes_Get_NoResources()
        {
            // Arrange
            List<LanguageCodeDto> languageCodes = [new LanguageCodeDto { LanguageCode = "VN" }];

            mockHttpClientService = new Mock<IHttpClientService>();

            mockHttpClientService.Setup(h => h.GetAsyncCall($"TestLanguageServiceAPIUrl/{CommonConstants.GetActiveLanguageCodes}"
                , It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageCodeDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                        Result = languageCodes,
                        IsSuccess = true
                    }))
                });

            string testResourceUrl = $"TestLanguageServiceAPIUrl/{CommonConstants.GetLanguageResources}?groupCode={_appGroupCode}&languageCode={_testLanguageCode}";
            mockHttpClientService.Setup(h => h.GetAsyncCall(testResourceUrl, It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageResourceDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_NOTFOUND,
                        IsSuccess = false
                    }))
                });

            // Arrange
            using CancellationTokenSource stoppingTokenSource = new();
            TestableLanguageWorkerService service = new(_mockConfig,
                mockHttpClientService.Object, _logger.Object);

            // Act
            Task executionTask = service.StartAsync(stoppingTokenSource.Token);
            stoppingTokenSource.Cancel(); // Cancel the task

            // Assert
            Assert.True(service.WasExecuted);
            Assert.True(executionTask.IsCompleted);
            Assert.False(executionTask.IsCanceled);
        }

        [Fact]
        public void Test_Start_WithGetActiveLanguageCodes_Get_NoRecords()
        {
            // Arrange
            mockHttpClientService = new Mock<IHttpClientService>();

            mockHttpClientService.Setup(h => h.GetAsyncCall($"TestLanguageServiceAPIUrl/{CommonConstants.GetActiveLanguageCodes}"
                , It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageCodeDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_NOTFOUND,
                        IsSuccess = false
                    }))
                });

            // Arrange
            using CancellationTokenSource stoppingTokenSource = new();
            TestableLanguageWorkerService service = new(_mockConfig,
                mockHttpClientService.Object, _logger.Object);

            // Act
            Task executionTask = service.StartAsync(stoppingTokenSource.Token);
            stoppingTokenSource.Cancel(); // Cancel the task

            // Assert
            Assert.True(service.WasExecuted);
            Assert.True(executionTask.IsCompleted);
            Assert.False(executionTask.IsCanceled);
        }

        [Fact]
        public void Test_Start_LanguageWorker_Service_Get_InvalidInterval()
        {
            // Arrange
            _mockConfig[CommonConstants.LanguageAbsoluteExpiryMinutes] = string.Empty;
            mockHttpClientService = new Mock<IHttpClientService>();
            mockHttpClientService.Setup(h => h.GetAsyncCall($"TestLanguageServiceAPIUrl/{CommonConstants.GetActiveLanguageCodes}"
                , It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageCodeDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_NOTFOUND,
                        IsSuccess = false
                    }))
                });

            using CancellationTokenSource stoppingTokenSource = new();
            TestableLanguageWorkerService service = new(_mockConfig,
                mockHttpClientService.Object, _logger.Object);

            // Act
            Task executionTask = service.StartAsync(stoppingTokenSource.Token);
            stoppingTokenSource.Cancel(); // Cancel the task

            // Assert
            Assert.True(service.WasExecuted);
            Assert.True(executionTask.IsCompleted);
            Assert.False(executionTask.IsCanceled);
        }

        [Fact]
        public void Test_Start_WithValidLanguageCodes_AND_GetCDNFile_ReturnNoData()
        {
            // Arrange
            List<LanguageCodeDto> languageCodes = [new LanguageCodeDto { LanguageCode = "ID" }];
            List<LanguageResourceDto> resources = [new LanguageResourceDto { Key = "RECORD_FOUND", Value = "Record Found" }];

            mockHttpClientService = new Mock<IHttpClientService>();

            mockHttpClientService.Setup(h => h.GetAsyncCall($"TestLanguageServiceAPIUrl/{CommonConstants.GetActiveLanguageCodes}"
                , It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageCodeDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                        Result = languageCodes,
                        IsSuccess = true
                    }))
                });

            string testResourceUrl = $"TestLanguageServiceAPIUrl/{CommonConstants.GetLanguageResources}?groupCode={_appGroupCode}&languageCode={_testLanguageCode}";
            mockHttpClientService.Setup(h => h.GetAsyncCall(testResourceUrl, It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageResourceDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                        Result = resources
                    }))
                });

            string fileName = $"{_testFolder}/{CommonConstants.CDNFilePrefix}_{_appGroupCode}_{_testLanguageCode}{CommonConstants.CDNFileExtension}".ToLower();
            mockHttpClientService.Setup(h => h.GetStringAsync($"{_cdnUrl}/{_testContainer}/{fileName}?{_cdnSASTokenValue}")).ReturnsAsync(string.Empty);

            // Arrange
            using CancellationTokenSource stoppingTokenSource = new();
            TestableLanguageWorkerService service = new(_mockConfig,
                mockHttpClientService.Object, _logger.Object);

            // Act
            Task executionTask = service.StartAsync(stoppingTokenSource.Token);
            stoppingTokenSource.Cancel(); // Cancel the task

            // Assert
            Assert.True(service.WasExecuted);
            Assert.True(executionTask.IsCompleted);
            Assert.False(executionTask.IsCanceled);
        }


        [Fact]
        public void Test_Start_WithValidLanguageCodes_AND_GetCDNFile_ThrowError()
        {
            // Arrange
            List<LanguageCodeDto> languageCodes = [new LanguageCodeDto { LanguageCode = "ID" }];
            List<LanguageResourceDto> resources = [new LanguageResourceDto { Key = "RECORD_FOUND", Value = "Record Found" }];

            mockHttpClientService = new Mock<IHttpClientService>();

            mockHttpClientService.Setup(h => h.GetAsyncCall($"TestLanguageServiceAPIUrl/{CommonConstants.GetActiveLanguageCodes}"
                , It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageCodeDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                        Result = languageCodes,
                        IsSuccess = true
                    }))
                });

            string testResourceUrl = $"TestLanguageServiceAPIUrl/{CommonConstants.GetLanguageResources}?groupCode={_appGroupCode}&languageCode={_testLanguageCode}";
            mockHttpClientService.Setup(h => h.GetAsyncCall(testResourceUrl, It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageResourceDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                        Result = resources
                    }))
                });


            mockHttpClientService.Setup(x => x.GetStringAsync(It.IsAny<string>())).Throws(new Exception("Get resources error"));

            // Arrange
            using CancellationTokenSource stoppingTokenSource = new();
            TestableLanguageWorkerService service = new(_mockConfig,
                mockHttpClientService.Object, _logger.Object);

            // Act
            Task executionTask = service.StartAsync(stoppingTokenSource.Token);
            stoppingTokenSource.Cancel(); // Cancel the task

            // Assert
            Assert.True(service.WasExecuted);
            Assert.True(executionTask.IsCompleted);
            Assert.False(executionTask.IsCanceled);
        }

        [Fact]
        public void Test_GetLanguageResource_API_Response_Return_Not_Found()
        {
            // Arrange
            List<LanguageCodeDto> languageCodes = [new LanguageCodeDto { LanguageCode = "ID" }];

            mockHttpClientService = new Mock<IHttpClientService>();
            mockHttpClientService.Setup(h => h.GetAsyncCall($"TestLanguageServiceAPIUrl/{CommonConstants.GetActiveLanguageCodes}"
               , It.IsAny<string>()))
               .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
               {
                   Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageCodeDto>
                   {
                       StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                       Result = languageCodes,
                       IsSuccess = true
                   }))
               });

            string testResourceUrl = $"TestLanguageServiceAPIUrl/{CommonConstants.GetLanguageResources}?groupCode={_appGroupCode}&languageCode={_testLanguageCode}";
            mockHttpClientService.Setup(h => h.GetAsyncCall(testResourceUrl, It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new GenericResponseList<LanguageResourceDto>
                    {
                        StatusCode = ResponseStatusCode.STATUS_NOTFOUND,
                        IsSuccess = false
                    }))
                });

            using CancellationTokenSource stoppingTokenSource = new();
            TestableLanguageWorkerService service = new(_mockConfig,
                mockHttpClientService.Object, _logger.Object);

            // Act
            Task executionTask = service.StartAsync(stoppingTokenSource.Token);
            stoppingTokenSource.Cancel(); // Cancel the task

            // Assert
            Assert.True(service.WasExecuted);
            Assert.True(executionTask.IsCompleted);
            Assert.False(executionTask.IsCanceled);
        }
    }
}

