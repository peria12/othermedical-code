﻿
namespace Aurora.RBACService.Tests.CrossCutting.Localization
{
    public class LanguageTranslatorTests
    {
        public LanguageTranslatorTests()
        {
            // Clear any existing default resources before each test
            typeof(LanguageTranslator)
                .GetField("defaultLanguageResources", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
                ?.SetValue(LanguageTranslator.Instance, new ConcurrentDictionary<string, string>());
        }

        [Fact]
        public void AddDefaultResource_ShouldStoreResource()
        {
            // Arrange
            LanguageTranslator.Instance.AddDefaultResource("Key1", "Default Value");

            // Act
            var result = LanguageTranslator.Instance.Translate("en", "Key1");

            // Assert
            Assert.Equal("Default Value", result);
        }

        [Fact]
        public void Translate_ShouldReturnFromCache_WhenResourceExists()
        {
            // Arrange           
            var languageResources = new List<LanguageResourceDto>
            {
                new() { Key = "Hello", Value = "Hola" }
            };
            LanguageLocalCache.Instance.SetCache("EN", languageResources);
            bool exist = LanguageLocalCache.Instance.TryGetCache("EN", out List<LanguageResourceDto>? languageResourcesoutput);

            // Act
            var result = LanguageTranslator.Instance.Translate("EN", "Hello");

            // Assert
            Assert.Equal("Hola", result);
            Assert.True(exist);
            Assert.NotNull(languageResourcesoutput);
        }


        [Fact]
        public void TranslateDynamic_ShouldFormatResource()
        {

            // Arrange           
            var languageResources = new List<LanguageResourceDto>
            {
                new() { Key = "Greeting", Value = "Hello, {0}!" }
            };
            LanguageLocalCache.Instance.SetCache("EN", languageResources);

            // Act
            var result = LanguageTranslator.Instance.TranslateDynamic("EN", "Greeting", "Alice");

            // Assert
            Assert.Equal("Hello, Alice!", result);
        }
    }

}
