﻿namespace Aurora.RBACService.Tests.CrossCutting.Caching
{
    public class RedisCacheEnterpriseServiceTests
    {
        private readonly Mock<IConnectionMultiplexer> _mockMultiplexer;
        private readonly Mock<IDatabase> _mockDb;
        private readonly Mock<ILogger<RedisCacheEnterpriseService>> _mockLogger;
        private readonly Mock<IConfiguration> _mockConfig;
        private readonly RedisCacheEnterpriseService _service;

        public RedisCacheEnterpriseServiceTests()
        {
            _mockMultiplexer = new Mock<IConnectionMultiplexer>();
            _mockDb = new Mock<IDatabase>();
            _mockLogger = new Mock<ILogger<RedisCacheEnterpriseService>>();
            _mockConfig = new Mock<IConfiguration>();

            _mockMultiplexer.Setup(m => m.GetDatabase(It.IsAny<int>(), It.IsAny<object>())).Returns(_mockDb.Object);

            _service = new RedisCacheEnterpriseService(
                _mockMultiplexer.Object,
                _mockConfig.Object,
                _mockLogger.Object);
        }

        public class Dummy
        {
            public required string Name { get; set; }
            public int Age { get; set; }
        }

        [Fact]
        public async Task SetSingleAsync_ShouldReturnTrue_WhenJsonSetReturnsOk()
        {
            var key = "test:key";
            var value = new Dummy { Name = "John", Age = 30 };
            var redisResult = RedisResult.Create("OK", ResultType.SimpleString);

            _mockDb.Setup(db => db.ExecuteAsync(It.Is<string>(cmd => cmd == "JSON.SET"), It.IsAny<object[]>()))
                .ReturnsAsync(redisResult);

            var result = await _service.SetSingleAsync(key, value);

            Assert.True(result);
        }

        [Fact]
        public async Task GetSingleAsync_ShouldReturnObject_WhenJsonIsValid()
        {
            var key = "test:key";
            var value = new Dummy { Name = "John", Age = 30 };
            var json = System.Text.Json.JsonSerializer.Serialize(value);
            var redisResult = RedisResult.Create(json, ResultType.SimpleString);

            _mockDb.Setup(db => db.ExecuteAsync("JSON.GET", key, "$")).ReturnsAsync(redisResult);

            var result = await _service.GetSingleAsync<Dummy>(key);

            Assert.NotNull(result);
            Assert.Equal(value.Name, result!.Name);
            Assert.Equal(value.Age, result.Age);
        }

        [Fact]
        public async Task SetSingleAsync_ReturnsFalse_OnException()
        {
            var key = "test:key";
            var ex = new Exception("Test Exception");
            var value = new Dummy { Name = "John", Age = 30 };

            _mockDb.Setup(db => db.ExecuteAsync(It.Is<string>(cmd => cmd == "JSON.SET"), It.IsAny<object[]>()))
                .ThrowsAsync(ex);

            var result = await _service.SetSingleAsync(key, value);

            Assert.False(result);
            _mockLogger.Verify(x => x.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString()!.Contains("SetSingleAsync")),
                ex,
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()), Times.Once);
        }

        [Fact]
        public async Task SetListAsync_ReturnsTrue_WhenSetIsOk()
        {
            var key = "test:key";
            var dummyList = new List<Dummy> { new Dummy { Name = "Alice", Age = 30 } };
            var redisResult = RedisResult.Create("OK", ResultType.SimpleString);

            _mockDb.Setup(db => db.ExecuteAsync(It.Is<string>(cmd => cmd == "JSON.SET"), It.IsAny<object[]>()))
                .ReturnsAsync(redisResult);

            var result = await _service.SetListAsync(key, dummyList);

            Assert.True(result);

        }

        [Fact]
        public async Task SetListAsync_ReturnsFalse_WhenSetFails()
        {
            var key = "test:key";
            var dummyList = new List<Dummy> { new Dummy { Name = "Alice", Age = 30 } };
            var redisResult = RedisResult.Create("NOT_OK", ResultType.SimpleString);

            _mockDb.Setup(db => db.ExecuteAsync(It.Is<string>(cmd => cmd == "JSON.SET"), It.IsAny<object[]>()))
                .ReturnsAsync(redisResult);

            var result = await _service.SetListAsync(key, dummyList);

            Assert.False(result);
        }

        [Fact]
        public async Task SetListAsync_ReturnsFalse_OnException()
        {
            var key = "test:key";
            var ex = new Exception("Test Exception");
            var dummyList = new List<Dummy> { new Dummy { Name = "Charlie", Age = 50 } };

            _mockDb.Setup(db => db.ExecuteAsync(It.Is<string>(cmd => cmd == "JSON.SET"), It.IsAny<object[]>()))
                .ThrowsAsync(ex);

            var result = await _service.SetListAsync(key, dummyList);

            Assert.False(result);
            _mockLogger.Verify(x => x.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString()!.Contains("SetListAsync")),
                ex,
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()), Times.Once);
        }

        [Fact]
        public async Task DeleteSingleAsync_ReturnsTrue_WhenKeyIsDeleted()
        {
            var key = "test:key";
            _mockDb.Setup(db => db.KeyDeleteAsync(key, CommandFlags.None)).ReturnsAsync(true);

            var result = await _service.DeleteSingleAsync(key);

            Assert.True(result);
        }

        [Fact]
        public async Task DeleteSingleAsync_ReturnsFalse_WhenKeyIsNotDeleted()
        {
            var key = "test:key";
            _mockDb.Setup(db => db.KeyDeleteAsync(key, CommandFlags.None)).ReturnsAsync(false);

            var result = await _service.DeleteSingleAsync(key);

            Assert.False(result);
        }

        [Fact]
        public async Task DeleteSingleAsync_ReturnsFalse_OnException()
        {

            var key = "test:key";
            var ex = new Exception("Delete failure");
            _mockDb.Setup(db => db.KeyDeleteAsync(key, CommandFlags.None)).ThrowsAsync(ex);

            var result = await _service.DeleteSingleAsync(key);

            Assert.False(result);
            _mockLogger.Verify(x => x.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString()!.Contains("DeleteSingleAsync")),
                ex,
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()), Times.Once);
        }


        [Fact]
        public async Task SetMultipleKeysAsync_CompletesSuccessfully()
        {
            var batchMock = new Mock<IBatch>();
            _mockDb.Setup(db => db.CreateBatch(null)).Returns(batchMock.Object);

            batchMock
                .Setup(b => b.ExecuteAsync(It.IsAny<string>(), It.IsAny<object[]>()))
                .ReturnsAsync(RedisResult.Create("OK", ResultType.SimpleString));

            batchMock
                .Setup(b => b.KeyExpireAsync(It.IsAny<RedisKey>(), It.IsAny<TimeSpan>(), It.IsAny<ExpireWhen>(), It.IsAny<CommandFlags>()))
                .ReturnsAsync(true);

            batchMock.Setup(b => b.Execute());

            var keyValuePairs = new Dictionary<string, Dummy>
            {
                { "key1", new Dummy { Name = "Alpha", Age = 10 } },
                { "key2", new Dummy { Name = "Beta", Age = 20 } }
            };

            await _service.SetMultipleKeysAsync(keyValuePairs, TimeSpan.FromMinutes(15));

            batchMock.Verify(b => b.ExecuteAsync("JSON.SET", It.IsAny<object[]>()), Times.Exactly(2));
            batchMock.Verify(b => b.KeyExpireAsync(It.IsAny<RedisKey>(), It.IsAny<TimeSpan>(), It.IsAny<ExpireWhen>(), It.IsAny<CommandFlags>()), Times.Exactly(2));
            batchMock.Verify(b => b.Execute(), Times.Once);
        }

        [Fact]
        public async Task SetMultipleKeysAsync_LogsError_OnException()
        {
            var batchMock = new Mock<IBatch>();

            _mockDb.Setup(db => db.CreateBatch(null)).Returns(batchMock.Object);

            var ex = new Exception("Simulated failure");

            batchMock
                .Setup(b => b.ExecuteAsync(It.IsAny<string>(), It.IsAny<object[]>()))
                .Throws(ex);

            batchMock.Setup(b => b.Execute());

            var keyValuePairs = new Dictionary<string, Dummy>
            {
                { "crashKey", new Dummy { Name = "Boom", Age = 999 } }
            };

            await _service.SetMultipleKeysAsync(keyValuePairs, TimeSpan.FromSeconds(5));

            _mockLogger.Verify(x => x.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) =>
                    v.ToString()!.Contains("SetMultipleKeysAsync")),
                ex,
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                Times.Once);
        }



    }
}
