﻿namespace Aurora.RBACService.Tests.CrossCutting.Extensions
{
    public class FilterColumnTests
    {
        [Fact]
        public void FilterColumn_ShouldSetAndGetPropertiesCorrectly()
        {
            // Arrange
            var condition = new FilterCondition(); // Assuming a valid FilterCondition instance
            var filterOperator = FilterOperator.Equals; // Assuming a valid FilterOperator enum
            string columnName = "PatientId";

            // Act
            var filterColumn = new FilterColumn
            {
                Condition = condition,
                Operator = filterOperator,
                Column = columnName
            };

            // Assert
            filterColumn.Condition.Should().Be(condition);
            filterColumn.Operator.Should().Be(filterOperator);
            filterColumn.Column.Should().Be(columnName);
        }

        [Fact]
        public async Task ApplyQueryParameters_ShouldFilterCollectionProperty_WithAnyCondition()
        {
            // Arrange
            var mockData = new List<TestEntity>
            {
                new TestEntity { Id = 1, Tags = new List<Tag> { new Tag { Value = "Important" }, new Tag { Value = "Urgent" } } },
                new TestEntity { Id = 2, Tags = new List<Tag> { new Tag { Value = "General" }, new Tag { Value = "Info" } } },
                new TestEntity { Id = 3, Tags = new List<Tag> { new Tag { Value = "Important" }, new Tag { Value = "Review" } } },
                new TestEntity { Id = 4, Tags = new List<Tag> { new Tag { Value = "Optional" }, new Tag { Value = "Reference" } } }
            }.AsQueryable();

            var filterParams = new PaginationQuery
            {
                Filters = new Dictionary<string, string>
                {
                    { "Tags.Value", "Important" }  // Filtering on the "Value" property inside "Tags"
                }
            };

            // Act
            var result = await mockData.ApplyQueryParameters(filterParams);

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(2); // Expecting records with Id = 1 and 3
            result.Select(e => e.Id).Should().BeEquivalentTo(new List<int> { 1, 3 });
        }

        private class Tag
        {
            public string Value { get; set; } = string.Empty;
        }

        private class TestEntity
        {
            public int Id { get; set; }
            public List<Tag> Tags { get; set; } = new();
        }
    }
}
