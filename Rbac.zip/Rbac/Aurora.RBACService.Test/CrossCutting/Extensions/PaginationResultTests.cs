﻿namespace Aurora.RBACService.Tests.CrossCutting.Extensions
{
    public class PaginationResultTests
    {
        public class SampleEntity
        {
            public int Id { get; set; }
            public string Name { get; set; } = string.Empty;
        }

        [Fact]
        public void Constructor_ShouldInitializeRecords_AsEmptyQueryable()
        {
            // Act
            var result = new PaginationResult<SampleEntity>();

            // Assert
            result.Records.Should().NotBeNull();
            result.Records.Should().BeEmpty();
            result.TotalCount.Should().Be(0);
        }

        [Fact]
        public void Properties_ShouldSetAndGetProperly()
        {
            // Arrange
            var data = new List<SampleEntity>
            {
                new SampleEntity { Id = 1, Name = "Test1" },
                new SampleEntity { Id = 2, Name = "Test2" }
            }.AsQueryable();

            var result = new PaginationResult<SampleEntity>
            {
                Records = data,
                TotalCount = data.Count()
            };

            // Assert
            result.Records.Should().BeEquivalentTo(data);
            result.TotalCount.Should().Be(2);
        }
    }
}
