﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ModelBinding.Metadata;

namespace Aurora.RBACService.CrossCutting.Extensions.Tests
{
    public class NestedModelFilterBinderTests
    {
        private readonly NestedModelFilterBinder _binder;

        public NestedModelFilterBinderTests()
        {
            _binder = new NestedModelFilterBinder();
        }

        [Fact]
        public async Task BindModelAsync_ShouldReturnFailed_WhenModelTypeIsNotDictionary()
        {
            // Arrange
            var modelMetadata = new Mock<ModelMetadata>(ModelMetadataIdentity.ForType(typeof(string)));
            var bindingContext = new DefaultModelBindingContext
            {
                ModelMetadata = modelMetadata.Object // ModelType is inferred from ModelMetadata
            };

            // Act
            await _binder.BindModelAsync(bindingContext);

            // Assert
            bindingContext.Result.IsModelSet.Should().BeFalse();
        }

        [Fact]
        public async Task BindModelAsync_ShouldReturnSuccess_WhenQueryContainsFilters()
        {
            // Arrange
            var queryCollection = new QueryCollection(new Dictionary<string, StringValues>
            {
                { "Filters.Name", "John" },
                { "Filters.Age", "30" },
                { "OtherKey", "OtherValue" } // This should be ignored
            });

            var httpContext = new DefaultHttpContext
            {
                Request =
                {
                    Query = queryCollection
                }
            };

            var modelMetadata = new Mock<ModelMetadata>(ModelMetadataIdentity.ForType(typeof(Dictionary<string, string>)));
            var bindingContext = new DefaultModelBindingContext
            {
                ModelMetadata = modelMetadata.Object, // ModelType is inferred from ModelMetadata
                ActionContext = new ActionContext
                {
                    HttpContext = httpContext
                }
            };

            // Act
            await _binder.BindModelAsync(bindingContext);

            // Assert
            bindingContext.Result.IsModelSet.Should().BeTrue();
            var result = bindingContext.Result.Model as Dictionary<string, string>;
            result.Should().NotBeNull();
            result.Should().HaveCount(2);
            result.Should().ContainKey("Name").WhoseValue.Should().Be("John");
            result.Should().ContainKey("Age").WhoseValue.Should().Be("30");
        }

        [Fact]
        public async Task BindModelAsync_ShouldReturnEmptyDictionary_WhenQueryDoesNotContainFilters()
        {
            // Arrange
            var queryCollection = new QueryCollection(new Dictionary<string, StringValues>
            {
                { "OtherKey", "OtherValue" } // No keys starting with "Filters."
            });

            var httpContext = new DefaultHttpContext
            {
                Request =
                {
                    Query = queryCollection
                }
            };

            var modelMetadata = new Mock<ModelMetadata>(ModelMetadataIdentity.ForType(typeof(Dictionary<string, string>)));
            var bindingContext = new DefaultModelBindingContext
            {
                ModelMetadata = modelMetadata.Object, // ModelType is inferred from ModelMetadata
                ActionContext = new ActionContext
                {
                    HttpContext = httpContext
                }
            };

            // Act
            await _binder.BindModelAsync(bindingContext);

            // Assert
            bindingContext.Result.IsModelSet.Should().BeTrue();
            var result = bindingContext.Result.Model as Dictionary<string, string>;
            result.Should().NotBeNull();
            result.Should().BeEmpty();
        }
    }
}