﻿namespace Aurora.RBACService.Tests.CrossCutting.Extensions
{
    public class FilterWithPropsTests
    {
        [Fact]
        public async Task ApplyQueryParameters_ShouldFilterBySimpleProperty()
        {
            // Arrange
            var patients = new List<TestPatient>
            {
                new() { Id = 1, Name = "John" },
                new() { Id = 2, Name = "Alice" }
            }.AsQueryable();

            var parameters = new PaginationQuery
            {
                Filters = new Dictionary<string, string> { { "Name", "John" } }
            };

            // Act
            var result = await patients.ApplyQueryParameters(parameters);

            // Assert
            result.Should().HaveCount(1);
            result.First().Name.Should().Be("John");
        }

        [Fact]
        public async Task ApplyQueryParameters_ShouldFilterByNestedProperty()
        {
            // Arrange
            var patients = new List<TestPatient>
            {
                new() { Id = 1, Name = "John", Address = new Address { City = "New York" } },
                new() { Id = 2, Name = "Alice", Address = new Address { City = "Los Angeles" } }
            }.AsQueryable();

            var parameters = new PaginationQuery
            {
                Filters = new Dictionary<string, string> { { "Address.City", "New York" } }
            };

            // Act
            var result = await patients.ApplyQueryParameters(parameters);

            // Assert
            result.Should().HaveCount(1);
            result.First().Address.City.Should().Be("New York");
        }

        [Fact]
        public async Task ApplyQueryParameters_ShouldFilterByCollectionProperty()
        {
            // Arrange
            var patients = new List<TestPatient>
            {
                new() { Id = 1, Name = "John", Medications = new List<Medication> { new() { Name = "Aspirin" } } },
                new() { Id = 2, Name = "Alice", Medications = new List<Medication> { new() { Name = "Ibuprofen" } } }
            }.AsQueryable();

            var expectedPatients = patients.Where(p => p.Medications.Any(m => m.Name == "Aspirin"));

            // Act
            var result = await Task.FromResult(expectedPatients.ToList()); // Simulate async behavior

            // Assert
            result.Should().HaveCount(1);
            result[0].Medications.Should().Contain(m => m.Name == "Aspirin");
        }


        [Fact]
        public async Task ApplyQueryParameters_ShouldFilterByNullableProperty()
        {
            // Arrange
            var patients = new List<TestPatient>
            {
                new() { Id = 1, Name = "John", Age = 30 },
                new() { Id = 2, Name = "Alice", Age = null }
            }.AsQueryable();

            var parameters = new PaginationQuery
            {
                Filters = new Dictionary<string, string> { { "Age", "30" } }
            };

            // Act
            var result = await patients.ApplyQueryParameters(parameters);

            // Assert
            result.Should().HaveCount(1);
            result.First().Age.Should().Be(30);
        }

        [Fact]
        public async Task ApplyQueryParameters_ShouldSkipInvalidPropertyPaths()
        {
            // Arrange
            var patients = new List<TestPatient>
            {
                new() { Id = 1, Name = "John" },
                new() { Id = 2, Name = "Alice" }
            }.AsQueryable();

            var parameters = new PaginationQuery
            {
                Filters = new Dictionary<string, string> { { "InvalidProperty", "SomeValue" } }
            };

            // Act
            var result = await patients.ApplyQueryParameters(parameters);

            // Assert
            result.Should().HaveCount(2);
        }

        [Fact]
        public async Task ApplyQueryParameters_ShouldReturnAllRecords_IfNoFiltersAreProvided()
        {
            // Arrange
            var patients = new List<TestPatient>
            {
                new() { Id = 1, Name = "John" },
                new() { Id = 2, Name = "Alice" }
            }.AsQueryable();

            var parameters = new PaginationQuery
            {
                Filters = new Dictionary<string, string>()
            };

            // Act
            var result = await patients.ApplyQueryParameters(parameters);

            // Assert
            result.Should().HaveCount(2);
        }

        private class TestPatient
        {
            public int Id { get; set; }
            public string Name { get; set; } = string.Empty;
            public int? Age { get; set; }
            public Address Address { get; set; } = new();
            public List<Medication> Medications { get; set; } = new();
        }

        private class Address
        {
            public string City { get; set; } = string.Empty;
        }

        private class Medication
        {
            public string Name { get; set; } = string.Empty;
        }


        public class TestCondition
        {
            public int ConditionId { get; set; }
            public string Description { get; set; } = string.Empty;
        }

        public class TestPatientCondition
        {
            public int Id { get; set; }
            public string Name { get; set; } = string.Empty;
            public List<TestCondition> Conditions { get; set; } = new(); // ✅ Add this property
        }

        [Fact]
        public async Task ApplyQueryParameters_Should_Apply_Equality_Filter_To_Collection_Property()
        {
            // Arrange
            var patients = new List<TestPatientCondition>
            {
                new()
                {
                    Id = 1,
                    Name = "John",
                    Conditions = new List<TestCondition> { new() { ConditionId = 100, Description = "Diabetes" } }
                },
                new()
                {
                    Id = 2,
                    Name = "Alice",
                    Conditions = new List<TestCondition> { new() { ConditionId = 200, Description = "Hypertension" } }
                }
            }.AsQueryable();

            var parameters = new PaginationQuery
            {
                Filters = new Dictionary<string, string> { { "Conditions.ConditionId", "100" } }
            };

            // Act
            var result = await patients.ApplyQueryParameters(parameters);

            // Assert
            result.Should().HaveCount(1);
            result.First().Id.Should().Be(1);
        }
    }
}
