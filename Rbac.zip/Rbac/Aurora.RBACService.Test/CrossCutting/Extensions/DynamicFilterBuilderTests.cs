﻿namespace Aurora.RBACService.Tests.CrossCutting.Extensions
{
    public class DynamicFilterBuilderTests
    {
        private class TestEntity
        {
            public int Id { get; set; }
            public string Name { get; set; } = string.Empty;
        }

        [Fact]
        public void Constructor_ShouldInitializeWithoutException()
        {
            // Act
            var builder = new DynamicFilterBuilder<TestEntity>();

            // Assert
            builder.Should().NotBeNull();
        }

        [Fact]
        public void And_ShouldCombineExpressionsUsingAndOperator()
        {
            // Arrange
            var builder = new DynamicFilterBuilder<TestEntity>();

            // Act
            builder.And("Id", FilterOperator.Equals, 1)
                   .And("Name", FilterOperator.Equals, "TestName");

            // Assert
            var expr = builder.Build();
            expr.Should().NotBeNull();
        }

        [Fact]
        public void Or_ShouldCombineExpressionsUsingOrOperator()
        {
            // Arrange
            var builder = new DynamicFilterBuilder<TestEntity>();

            // Act
            builder.Or("Id", FilterOperator.Equals, 1)
                   .Or("Name", FilterOperator.Equals, "TestName");

            // Assert
            var expr = builder.Build();
            expr.Should().NotBeNull();
        }

        [Fact]
        public void And_WithNestedBuilder_ShouldCombineUsingAndOperator()
        {
            // Arrange
            var builder = new DynamicFilterBuilder<TestEntity>();

            // Act
            builder.And(inner => inner.And("Id", FilterOperator.Equals, 1)
                                      .And("Name", FilterOperator.Equals, "TestName"));

            // Assert
            var expr = builder.Build();
            expr.Should().NotBeNull();
        }

        [Fact]
        public void Or_WithNestedBuilder_ShouldCombineUsingOrOperator()
        {
            // Arrange
            var builder = new DynamicFilterBuilder<TestEntity>();

            // Act
            builder.Or(inner => inner.Or("Id", FilterOperator.Equals, 1)
                                     .Or("Name", FilterOperator.Equals, "TestName"));

            // Assert
            var expr = builder.Build();
            expr.Should().NotBeNull();
        }

        [Fact]
        public void Build_ShouldReturnValidExpression()
        {
            // Arrange
            var builder = new DynamicFilterBuilder<TestEntity>()
                .And("Id", FilterOperator.Equals, 1)
                .And("Name", FilterOperator.Equals, "TestName");

            // Act
            var expr = builder.Build();

            // Assert
            expr.Should().NotBeNull();
            expr.Body.Should().NotBeNull();
        }

        [Fact]
        public void Compile_ShouldReturnValidFunction()
        {
            // Arrange
            var builder = new DynamicFilterBuilder<TestEntity>()
                .And("Id", FilterOperator.Equals, 1)
                .And("Name", FilterOperator.Equals, "TestName");

            // Act
            var func = builder.Compile();

            // Assert
            func.Should().NotBeNull();
        }

        [Fact]
        public void And_NestedBuilder_ThrowsExceptionWhenEmpty()
        {
            // Arrange
            var builder = new DynamicFilterBuilder<TestEntity>();

            // Act
            Action act = () => builder.And(inner => { });

            // Assert
            act.Should().Throw<Exception>().WithMessage("Empty builder");
        }

        [Fact]
        public void Or_NestedBuilder_ThrowsExceptionWhenEmpty()
        {
            // Arrange
            var builder = new DynamicFilterBuilder<TestEntity>();

            // Act
            Action act = () => builder.Or(inner => { });

            // Assert
            act.Should().Throw<Exception>().WithMessage("Empty builder");
        }

        [Fact]
        public void And_ShouldSupportStringProperties()
        {
            // Arrange
            var builder = new DynamicFilterBuilder<TestEntity>();

            // Act
            builder.And("Name", FilterOperator.Equals, "SampleName");

            // Assert
            var expr = builder.Build();
            expr.Should().NotBeNull();
        }

        [Fact]
        public void Or_ShouldSupportStringProperties()
        {
            // Arrange
            var builder = new DynamicFilterBuilder<TestEntity>();

            // Act
            builder.Or("Name", FilterOperator.Equals, "SampleName");

            // Assert
            var expr = builder.Build();
            expr.Should().NotBeNull();
        }

        [Fact]
        public void Compile_ShouldFilterEntitiesCorrectly()
        {
            // Arrange
            var builder = new DynamicFilterBuilder<TestEntity>().And("Id", FilterOperator.Equals, 1);
            var filterFunc = builder.Compile();

            var entities = new List<TestEntity>
            {
                new TestEntity { Id = 1, Name = "John" },
                new TestEntity { Id = 2, Name = "Alice" }
            };

            // Act
            var filteredEntities = entities.Where(filterFunc).ToList();

            // Assert
            filteredEntities.Should().HaveCount(1);
            filteredEntities[0].Id.Should().Be(1);
        }

        [Fact]
        public void Build_ShouldThrowExceptionForInvalidProperty()
        {
            // Arrange
            var builder = new DynamicFilterBuilder<TestEntity>();

            // Act
            Action act = () => builder.And("InvalidProperty", FilterOperator.Equals, "Test");

            // Assert
            act.Should().Throw<ArgumentException>()
               .WithMessage("*Instance property 'InvalidProperty' is not defined*");
        }

    }
}
