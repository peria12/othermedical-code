﻿namespace Aurora.RBACService.Tests.CrossCutting.ExceptionHandling
{
    /// <summary>
    /// Unit tests for <see cref="ExceptionHandlingMiddleware"/> class.
    /// </summary>
    /// <remarks>
    /// These tests cover possible usecases for exception handling middlerware.
    /// </remarks>
    public class ExceptionHandlingMiddlewareTests
    {
        private readonly Mock<RequestDelegate> _nextMock;
        private readonly ExceptionHandlingMiddleware _middleware;
        private readonly DefaultHttpContext _context;
        private readonly Mock<ITelemetryClientWrapper> _telemetryClientWrapperMock;

        public ExceptionHandlingMiddlewareTests()
        {
            _nextMock = new Mock<RequestDelegate>();
            //_middleware = new ExceptionHandlingMiddleware(_nextMock.Object);
            _context = new DefaultHttpContext();
            _telemetryClientWrapperMock = new Mock<ITelemetryClientWrapper>();
            _middleware = new ExceptionHandlingMiddleware(_nextMock.Object, _telemetryClientWrapperMock.Object);
        }

        [Fact]
        public async Task InvokeAsync_NoException_ShouldCallNext()
        {
            // Arrange
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).Returns(Task.CompletedTask);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _nextMock.Verify(x => x(It.IsAny<HttpContext>()), Times.Once);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_UnauthorizedException()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status401Unauthorized;
            var exception = new UnauthorizedAccessException(TestConstants.STATUSCODEUNAUTHORIZED);
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be(StatusCodes.Status401Unauthorized);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_InternalServerException()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status500InternalServerError;
            var exception = new Exception(TestConstants.STATUS500INTERNALSERVERERROR);
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_TimeoutException()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status408RequestTimeout;
            var exception = new TimeoutException(TestConstants.STATUS408REQUESTTIMEOUT);
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be(StatusCodes.Status408RequestTimeout);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_HttpRequestException_503()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status503ServiceUnavailable;
            var exception = new HttpRequestException(TestConstants.STATUS503SERVICEUNAVAILABLE);
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be(StatusCodes.Status503ServiceUnavailable);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_ArgumentException_400()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status504GatewayTimeout;
            var exception = new ArgumentException(TestConstants.STATUS400BADREQUEST);
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_KeyNotFoundException_404()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status404NotFound;
            var exception = new KeyNotFoundException(TestConstants.STATUS404NOTFOUND);
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be(StatusCodes.Status404NotFound);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_InvalidOperationException_409()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status409Conflict;
            var exception = new InvalidOperationException(TestConstants.STATUS409CONFLICT);
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be(StatusCodes.Status409Conflict);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_NotImplementedException_501()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status501NotImplemented;
            var exception = new NotImplementedException(TestConstants.STATUS501NOTIMPLEMENTED);
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be(StatusCodes.Status501NotImplemented);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_NotFound()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status404NotFound;

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be(StatusCodes.Status404NotFound);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_MethodNotAllowed()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status405MethodNotAllowed;
            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be(StatusCodes.Status405MethodNotAllowed);
        }
        [Fact]
        public async Task InvokeAsync_ShouldHandle_Conflict()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status409Conflict;

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be(StatusCodes.Status409Conflict);
        }


        [Fact]
        public async Task InvokeAsync_ShouldHandle_TooManyRequests()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status429TooManyRequests;

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be(StatusCodes.Status429TooManyRequests);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_Locked()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status423Locked;

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be(StatusCodes.Status423Locked);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_Forbidden()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status403Forbidden;

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be(StatusCodes.Status403Forbidden);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_Unauthorized()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status401Unauthorized;

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be(CommonConstants.CONTENTTYPEJSON);
            _context.Response.StatusCode.Should().Be(StatusCodes.Status401Unauthorized);
        }

        private static DefaultHttpContext CreateHttpContext(int statusCode = 200, bool hasStarted = false, string? facilityCode = null, string? languageCode = null, string? customErrorId = null)
        {
            var context = new DefaultHttpContext();
            var response = context.Response;
            response.Body = new MemoryStream();
            response.StatusCode = statusCode;

            if (hasStarted)
            {
                typeof(HttpResponse).GetProperty("HasStarted")!
                    .SetValue(response, true, null);
            }

            context.Request.Headers[CommonConstants.HeaderCorrelationId] = "corr-id";
            context.Request.Headers[CommonConstants.HeaderSessionId] = "sess-id";
            context.Request.Headers[CommonConstants.HeaderRegionCode] = "region-code";

            if (facilityCode != null)
                context.Request.Headers[CommonConstants.HeaderFacilityCode] = facilityCode;

            if (languageCode != null)
                context.Request.Headers[CommonConstants.HeaderLanguageCode] = languageCode;

            if (customErrorId != null)
                context.Items[CommonConstants.CustomErrorId] = customErrorId;

            return context;
        }


        [Fact]
        public async Task HandleExceptionAsync_WithCustomErrorId_ShouldRemoveFromItems()
        {
            // Arrange
            var context = CreateHttpContext();
            context.Items[CommonConstants.CustomErrorId] = "custom123";
            var ex = new TimeoutException("timeout");

            // Act
            await _middleware.HandleExceptionAsync(context, ex);

            // Assert
            Assert.False(context.Items.ContainsKey(CommonConstants.CustomErrorId));
        }
        private static async Task<string> GetResponseBodyAsync(HttpContext context)
        {
            context.Response.Body.Seek(0, SeekOrigin.Begin);
            return await new StreamReader(context.Response.Body).ReadToEndAsync();
        }

        [Fact]
        public async Task HandleExceptionAsync_TimeoutException_ReturnsRequestTimeout()
        {
            // Arrange
            var exception = new TimeoutException("Timeout occurred");
            var context = CreateHttpContext();

            // Act
            await _middleware.HandleExceptionAsync(context, exception);

            // Assert
            Assert.Equal("application/json", context.Response.ContentType);
            Assert.Equal((int)HttpStatusCode.RequestTimeout, context.Response.StatusCode);

            var responseBody = await GetResponseBodyAsync(context);
            var json = System.Text.Json.JsonDocument.Parse(responseBody).RootElement;

            string message = json.GetProperty("Message").GetString()!;

            Assert.Contains(CommonConstants.ErrorCodeValue, message);
            Assert.Contains(CommonConstants.ERROR, message);
        }
        [Fact]
        public async Task HandleExceptionAsync_UnauthorizedAccessException_ReturnsUnauthorized()
        {
            // Arrange
            var exception = new UnauthorizedAccessException("Access denied");
            var context = CreateHttpContext();

            // Act
            await _middleware.HandleExceptionAsync(context, exception);

            // Assert
            Assert.Equal((int)HttpStatusCode.Unauthorized, context.Response.StatusCode);

            var responseBody = await GetResponseBodyAsync(context);
            var json = System.Text.Json.JsonDocument.Parse(responseBody).RootElement;

            var message = json.GetProperty("Message").GetString();
            Assert.Contains(CommonConstants.ErrorCodeValue, message); // Check error code prefix
            Assert.Contains(CommonConstants.WARNING, message);            // Check error severity
        }
        [Fact]
        public async Task HandleExceptionAsync_ArgumentException_ReturnsBadRequest()
        {
            var exception = new ArgumentException("Invalid arg");
            var context = CreateHttpContext();

            await _middleware.HandleExceptionAsync(context, exception);

            Assert.Equal((int)HttpStatusCode.BadRequest, context.Response.StatusCode);
            var responseBody = await GetResponseBodyAsync(context);
            var json = System.Text.Json.JsonDocument.Parse(responseBody).RootElement;

            var message = json.GetProperty("Message").GetString();
            Assert.Contains(CommonConstants.ErrorCodeValue, message);
            Assert.Contains(CommonConstants.ERROR, message);
        }

        [Fact]
        public async Task HandleExceptionAsync_GenericException_ReturnsInternalServerError()
        {
            var exception = new Exception("Generic failure");
            var context = CreateHttpContext();

            await _middleware.HandleExceptionAsync(context, exception);

            Assert.Equal((int)HttpStatusCode.InternalServerError, context.Response.StatusCode);
            var responseBody = await GetResponseBodyAsync(context);
            var json = System.Text.Json.JsonDocument.Parse(responseBody).RootElement;

            var message = json.GetProperty("Message").GetString();
            Assert.Contains(CommonConstants.ErrorCodeValue, message);
            Assert.Contains(CommonConstants.ERROR, message);
        }

    }
}