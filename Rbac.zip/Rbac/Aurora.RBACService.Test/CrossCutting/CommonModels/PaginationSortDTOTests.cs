﻿namespace Aurora.RBACService.Tests.CrossCutting.CommonModels
{
    public class PaginationSortDTOTests
    {
        [Fact]
        public void PaginationSortDTO_DefaultConstructor_ShouldSetDefaultValues()
        {
            // Arrange
            var paginationSortDto = new PaginationSortDto();

            // Assert
            paginationSortDto.PageNumber.Should().Be(1);
            paginationSortDto.PageSize.Should().Be(10);
            paginationSortDto.SortBy.Should().Be("Id");
            paginationSortDto.SortDescending.Should().BeFalse();
            paginationSortDto.TotalCount.Should().Be(0);
        }

        [Fact]
        public void PaginationSortDTO_Constructor_ShouldSetValuesCorrectly()
        {
            // Arrange
            var paginationSortDto = new PaginationSortDto
            {
                PageNumber = 2,
                PageSize = 20,
                SortBy = "Name",
                SortDescending = true,
                TotalCount = 100,
                CurrentPage = 2
            };

            // Assert
            paginationSortDto.PageNumber.Should().Be(2);
            paginationSortDto.PageSize.Should().Be(20);
            paginationSortDto.SortBy.Should().Be("Name");
            paginationSortDto.SortDescending.Should().BeTrue();
            paginationSortDto.TotalCount.Should().Be(100);
            paginationSortDto.CurrentPage.Should().Be(2);
        }
    }
}
