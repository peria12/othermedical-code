﻿namespace Aurora.RBACService.Tests.CrossCutting.CommonModels
{
    public class ResponseMessageTests
    {
        [Fact]
        public void Constants_ShouldHaveExpectedValues()
        {
            ResponseMessage.STATUS_INVALID_ID_PARAM_REQUEST.Should().Be("The field must be greather than 0 ");
            ResponseMessage.STATUS_INVALID_REQUEST.Should().Be("Invalid Request Parameter");
            ResponseMessage.STATUS_SUCCESS.Should().Be("Success");
            ResponseMessage.STATUS_ALREADY_REGISTERED.Should().Be("Device Already Registered");
            ResponseMessage.STATUS_ALREADY_ACTIVATED.Should().Be("Device Already Activated");
            ResponseMessage.STATUS_INPROGRESS.Should().Be("In Progress");
            ResponseMessage.STATUS_NODEVICE_FOUND.Should().Be("No Device Found");
            ResponseMessage.STATUS_INVALIED_TOKEN.Should().Be("Invalid Token");
            ResponseMessage.STATUS_FAILED.Should().Be("Failed");
            ResponseMessage.STATUS_REGISTRATION_FAILED.Should().Be("Registration Failed");
            ResponseMessage.STATUS_SERVER_ERROR.Should().Be("Internal Server Error, Please Try Later");
            ResponseMessage.STATUS_MESSAGE_SENDING_ERROR.Should().Be("Message Sending Error");
            ResponseMessage.STATUS_HOSPITALS_NOT_FOUND.Should().Be("No Hospital Found");
            ResponseMessage.STATUS_NODATA.Should().Be("Record Not Found");
            ResponseMessage.STATUS_DATA_FOUND.Should().Be("Record Found");
            ResponseMessage.STATUS_DATA_ADDED.Should().Be("Record Added Successfully");
            ResponseMessage.STATUS_DATA_UPDATED.Should().Be("Record Updated Successfully");
            ResponseMessage.STATUS_DATA_DELETED.Should().Be("Record Deleted Successfully");
            ResponseMessage.STATUS_DATA_ADD_FAIL.Should().Be("Record Not Added");
            ResponseMessage.STATUS_RECORDS_LOADED.Should().Be("Records Loaded Successfully.");
        }

        //[Fact]
        //public void GetConcurrencyErrorMessage_ShouldReturnFormattedMessage()
        //{
        //    // Arrange
        //    string updatedBy = "User123";
        //    DateTime updatedDate = new DateTime(2025, 2, 26, 10, 0, 0);
        //    string expectedMessage = $"The record has been updated by another user '{updatedBy}' just now on {updatedDate:dd-MM-yyyy h:mm:ss tt}. Please refresh the screen and can try again if you want update the record";

        //    // Act
        //    string result = ResponseMessage.GetConcurrencyErrorMessage(updatedBy, updatedDate);

        //    // Assert
        //    result.Should().Be(expectedMessage);
        //}

        [Fact]
        public void GetConcurrencyErrorMessage_ShouldHandleNullDate()
        {
            // Arrange
            string updatedBy = "User123";
            DateTime? updatedDate = null;
            string expectedMessage = $"The record has been updated by another user '{updatedBy}' just now on . Please refresh the screen and can try again if you want update the record";

            // Act
            string result = ResponseMessage.GetConcurrencyErrorMessage(updatedBy, updatedDate);

            // Assert
            result.Should().Be(expectedMessage);
        }
    }
}
