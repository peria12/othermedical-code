﻿namespace Aurora.RBACService.Tests.CrossCutting.CommonModels
{
    public class CommonModelsTests
    {
        [Theory]
        [InlineData("", "")]
        [InlineData("   ", "")]
        [InlineData("  Hello  ", "Hello")]
        [InlineData("Test", "Test")]
        public void StringValidation_ShouldTrimOrReturnEmpty(string input, string expected)
        {
            // Act
            string result = ValidationMessage.StringValidation(input);

            // Assert
            result.Should().Be(expected);
        }

        [Theory]
        [InlineData("  TeSt  ", "test")]
        [InlineData("", "")]
        [InlineData(null, "")]
        public void StringIgnoreCase_ShouldReturnLowerCase(string? input, string expected)
        {
            // Act
            string result = ValidationMessage.StringIgnoreCase(input);

            // Assert
            result.Should().Be(expected);
        }

        [Theory]
        [InlineData(123, "123")]
        [InlineData(0, "0")]
        [InlineData(-456, "-456")]
        public void StringValidation_ShouldConvertIntToString(int input, string expected)
        {
            // Act
            string result = ValidationMessage.StringValidation(input);

            // Assert
            result.Should().Be(expected);
        }

        private class TestClass
        {
            public required string Name { get; set; }
            public required string Description { get; set; }
        }

        [Fact]
        public void TrimStringProperties_ShouldTrimAllStringProperties()
        {
            // Arrange
            var testObject = new TestClass { Name = "  John  ", Description = "  Developer  " };

            // Act
            var result = Aurora.RBACService.CrossCutting.Extensions.StringExtension.TrimStringProperties<TestClass>(testObject);

            // Assert
            result.Name.Should().Be("John");
            result.Description.Should().Be("Developer");
        }
    }
}
