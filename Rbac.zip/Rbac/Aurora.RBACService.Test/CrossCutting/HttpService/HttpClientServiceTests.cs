﻿namespace Aurora.RBACService.Tests.CrossCutting.HttpService
{
    public class HttpClientServiceTests
    {
        private readonly Mock<IHttpClientFactory> _httpClientFactoryMock;
        private readonly Mock<IHttpContextAccessor> _httpContextAccessorMock;
        private readonly Mock<IConfiguration> _configurationMock;
        private readonly HttpClientService _httpClientService;
        private readonly DefaultHttpContext _httpContext;

        public HttpClientServiceTests()
        {
            _httpClientFactoryMock = new Mock<IHttpClientFactory>();
            _httpContextAccessorMock = new Mock<IHttpContextAccessor>();
            _configurationMock = new Mock<IConfiguration>();

            //_httpContext = new DefaultHttpContext
            //{
            //    User = new ClaimsPrincipal(new ClaimsIdentity(
            //[
            //    new(AppConstants.Preferred_Username, "testuser")
            //]))
            //};
            _httpContext = new DefaultHttpContext();
            _httpContext.Request.Headers[CommonConstants.HeaderRegionCode] = "IN";
            _httpContext.Request.Headers.Authorization = "Bearer dummy";

            _httpContextAccessorMock.Setup(_ => _.HttpContext).Returns(_httpContext);

            _configurationMock.Setup(c => c[CommonConstants.AdminServiceAPIClientId]).Returns("clientId");
            _configurationMock.Setup(c => c[CommonConstants.AdminServiceAPIClientSecret]).Returns("clientSecret");
            _configurationMock.Setup(c => c[CommonConstants.TenantId]).Returns("tenantId");
            _configurationMock.Setup(c => c["TenantID"]).Returns("tenantId");
            _configurationMock.Setup(c => c["Care21UserName"]).Returns("user");
            _configurationMock.Setup(c => c["Care21Password"]).Returns("pass");

            // FIX: Setup mock for HttpClientTimeout using GetSection instead of GetValue<T>
            var timeoutSectionMock = new Mock<IConfigurationSection>();
            timeoutSectionMock.Setup(x => x.Value).Returns("30");
            _configurationMock.Setup(c => c.GetSection("HttpClientTimeout")).Returns(timeoutSectionMock.Object);

            _httpClientService = new HttpClientService(
                _httpContextAccessorMock.Object,
                _configurationMock.Object,
                _httpClientFactoryMock.Object);
        }

        private static HttpClient CreateMockHttpClient(string responseContent)
        {
            var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>("SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(responseContent)
                });

            return new HttpClient(handlerMock.Object);
        }

        [Fact]
        public async Task PostAsyncCall_ShouldReturnHttpResponseMessage()
        {
            var httpClient = CreateMockHttpClient("{\"result\":\"success\"}");
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var result = await _httpClientService.PostAsyncCall("http://test.com", new { id = 1 }, "api://scope");

            result.StatusCode.Should().Be(HttpStatusCode.OK);
            var content = await result.Content.ReadAsStringAsync();
            content.Should().Contain("success");
        }

        [Fact]
        public async Task PostAsyncCall_CapturesHttpRequestExceptionData()
        {
            // Arrange: Simulate an HttpRequestException with custom error data
            var exception = new HttpRequestException("Server down");

            // Prevent duplicate key error
            if (!exception.Data.Contains(CommonConstants.HttpServiceErrorKey))
            {
                exception.Data.Add(CommonConstants.HttpServiceErrorKey, "Error in PostAsyncCall");
            }

            _httpClientFactoryMock.Setup(f => f.CreateClient(It.IsAny<string>())).Throws(exception);

            // Act & Assert: Ensure HttpRequestException is thrown and contains expected error key
            var thrownException = await Assert.ThrowsAsync<HttpRequestException>(async () =>
                await _httpClientService.PostAsyncCall("https://example.com", new { }, "scope"));

            Assert.NotNull(thrownException);
            Assert.True(thrownException.Data.Contains(CommonConstants.HttpServiceErrorKey));
            Assert.Equal("Error in PostAsyncCall", thrownException.Data[CommonConstants.HttpServiceErrorKey]);
        }

        [Fact]
        public async Task PutAsyncCall_ShouldReturnHttpResponseMessage()
        {
            var httpClient = CreateMockHttpClient("{\"updated\":true}");
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var result = await _httpClientService.PutAsyncCall("http://test.com", new { name = "test" }, "api://scope");

            result.StatusCode.Should().Be(HttpStatusCode.OK);
            var content = await result.Content.ReadAsStringAsync();
            content.Should().Contain("updated");
        }

        [Fact]

        public async Task PutAsyncCall_CapturesHttpRequestExceptionData()
        {

            // Arrange: Simulate an HttpRequestException with custom error data
            var exception = new HttpRequestException("Server down");

            // Prevent duplicate key error
            if (!exception.Data.Contains(CommonConstants.HttpServiceErrorKey))
            {
                exception.Data.Add(CommonConstants.HttpServiceErrorKey, "Error in PutAsyncCall");
            }
            _httpClientFactoryMock.Setup(f => f.CreateClient(It.IsAny<string>())).Throws(exception);

            // Act & Assert: Ensure HttpRequestException is thrown and contains expected error key
            var thrownException = await Assert.ThrowsAsync<HttpRequestException>(async () =>
                await _httpClientService.PutAsyncCall("https://example.com", new { }, "scope"));

            Assert.NotNull(thrownException);
            Assert.True(thrownException.Data.Contains(CommonConstants.HttpServiceErrorKey));
            Assert.Equal("Error in PutAsyncCall", thrownException.Data[CommonConstants.HttpServiceErrorKey]);
        }

        [Fact]
        public async Task GetAsyncCall_ShouldReturnHttpResponseMessage()
        {
            var httpClient = CreateMockHttpClient("{\"data\":\"value\"}");
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var result = await _httpClientService.GetAsyncCall("http://test.com", "api://scope");

            result.StatusCode.Should().Be(HttpStatusCode.OK);
            var content = await result.Content.ReadAsStringAsync();
            content.Should().Contain("value");
        }

        [Fact]
        public async Task GetAsyncCall_CapturesHttpRequestExceptionData()
        {
            // Arrange: Simulate an HttpRequestException with custom error data
            var exception = new HttpRequestException("Server down");

            // Prevent duplicate key error
            if (!exception.Data.Contains(CommonConstants.HttpServiceErrorKey))
            {
                exception.Data.Add(CommonConstants.HttpServiceErrorKey, "Error in GetAsyncCall");
            }

            _httpClientFactoryMock.Setup(f => f.CreateClient(It.IsAny<string>())).Throws(exception);

            // Act & Assert: Ensure HttpRequestException is thrown and contains expected error key
            var thrownException = await Assert.ThrowsAsync<HttpRequestException>(async () =>
                await _httpClientService.GetAsyncCall("http://example.com", "api://scope"));

            Assert.NotNull(thrownException);
            Assert.True(thrownException.Data.Contains(CommonConstants.HttpServiceErrorKey));
            Assert.Equal("Error in GetAsyncCall", thrownException.Data[CommonConstants.HttpServiceErrorKey]);
        }

        [Fact]
        public async Task Aurora_PostAsyncCall_ShouldReturnHttpResponseMessage()
        {
            var httpClient = CreateMockHttpClient("{\"ok\":1}");
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var result = await _httpClientService.Aurora_PostAsyncCall("http://test.com", new { id = 123 });

            result.StatusCode.Should().Be(HttpStatusCode.OK);
            var content = await result.Content.ReadAsStringAsync();
            content.Should().Contain("ok");
        }

        [Fact]
        public async Task Aurora_PostAsyncCall_CapturesHttpRequestExceptionData()
        {
            // Arrange: Simulate an HttpRequestException with custom error data
            var exception = new HttpRequestException("Server down");

            // Prevent duplicate key error
            if (!exception.Data.Contains(CommonConstants.HttpServiceErrorKey))
            {
                exception.Data.Add(CommonConstants.HttpServiceErrorKey, "Error in Aurora_PostAsyncCall");
            }

            _httpClientFactoryMock.Setup(f => f.CreateClient(It.IsAny<string>())).Throws(exception);

            // Act & Assert: Ensure HttpRequestException is thrown and contains expected error key
            var thrownException = await Assert.ThrowsAsync<HttpRequestException>(async () =>
                await _httpClientService.Aurora_PostAsyncCall("http://example.com", "api://scope"));

            Assert.NotNull(thrownException);
            Assert.True(thrownException.Data.Contains(CommonConstants.HttpServiceErrorKey));
            Assert.Equal("Error in Aurora_PostAsyncCall", thrownException.Data[CommonConstants.HttpServiceErrorKey]);
        }



        [Fact]
        public async Task DeleteAsyncCall_ShouldReturnHttpResponseMessage()
        {
            var httpClient = CreateMockHttpClient("{\"deleted\":true}");
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var result = await _httpClientService.DeleteAsyncCall("http://test.com", "api://scope");

            result.StatusCode.Should().Be(HttpStatusCode.OK);
            var content = await result.Content.ReadAsStringAsync();
            content.Should().Contain("deleted");
        }

        [Fact]
        public async Task DeleteAsyncCall_ShouldReturnInternalServerError_OnHttpRequestException()
        {
            // Arrange: Simulate an HttpRequestException
            var exception = new HttpRequestException("Network failure");

            _httpClientFactoryMock.Setup(f => f.CreateClient(It.IsAny<string>())).Throws(exception);

            // Act
            var result = await _httpClientService.DeleteAsyncCall("https://example.com", "scope");

            // Assert: Ensure the response matches the expected failure scenario
            Assert.Equal(HttpStatusCode.InternalServerError, result.StatusCode);
            var content = await result.Content.ReadAsStringAsync();
            Assert.Equal("Network failure", content);
        }


        [Fact]
        public async Task GetAccessTokenByClientCredentials_ShouldReturnToken()
        {
            string tokenJson = "{\"access_token\":\"abc123\"}";
            var httpClient = CreateMockHttpClient(tokenJson);
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var tokenMethod = typeof(HttpClientService)
                .GetMethod("GetAccessTokenByClientCredentials", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);

            var task = (Task<string>)tokenMethod?.Invoke(_httpClientService, ["api://scope"])!;
            var result = await task;

            result.Should().Be("abc123");
        }

        [Fact]
        public async Task GetAccessTokenByOnBehalfOfUser_ShouldReturnToken()
        {
            string tokenJson = "{\"access_token\":\"userToken123\"}";
            var httpClient = CreateMockHttpClient(tokenJson);
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var method = typeof(HttpClientService)
                .GetMethod("GetAccessTokenByOnBehalfOfUser", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);

            var task = (Task<string>)method?.Invoke(_httpClientService, ["api://scope"])!;
            var result = await task;

            result.Should().Be("userToken123");
        }

        [Fact]
        public async Task PostAuditAsyncCall_ShouldThrowHttpRequestException_OnFailure()
        {
            // Arrange: Simulate an HttpRequestException
            var exception = new HttpRequestException("Network failure");

            _httpClientFactoryMock.Setup(f => f.CreateClient(It.IsAny<string>())).Throws(exception);

            // Act & Assert: Ensure `HttpRequestException` is thrown and contains expected error key
            var thrownException = await Assert.ThrowsAsync<HttpRequestException>(async () =>
                await _httpClientService.PostAuditAsyncCall("https://example.com", new { }, "scope"));

            Assert.NotNull(thrownException);
            Assert.True(thrownException.Data.Contains(CommonConstants.HttpServiceErrorKey));
            Assert.Equal("Error in PostAuditAsyncCall", thrownException.Data[CommonConstants.HttpServiceErrorKey]);
        }

        [Fact]
        public async Task PostAuditAsyncCall_ShouldReturnOkResponse()
        {
            // Arrange
            var responseContent = "{\"audit\":\"success\"}";  // Extracted JSON content
            var httpClient = CreateMockHttpClient(responseContent);

            _httpClientFactoryMock.Setup(f => f.CreateClient(It.IsAny<string>())).Returns(httpClient);

            // Act
            var result = await _httpClientService.PostAuditAsyncCall("https://example.com", new { Action = "LoginAttempt" }, "api://scope");

            // Assert
            Assert.Equal(HttpStatusCode.OK, result.StatusCode);
            var content = await result.Content.ReadAsStringAsync();
            content.Should().Contain("success");
        }

        [Fact]
        public async Task GetAuditAsyncCall_ShouldReturnOkResponse()
        {
            // Arrange
            var responseContent = "{\"audit\":\"retrieved\"}";
            var httpClient = CreateMockHttpClient(responseContent);

            _httpClientFactoryMock.Setup(f => f.CreateClient(It.IsAny<string>())).Returns(httpClient);

            // Act
            var result = await _httpClientService.GetAuditAsyncCall("https://example.com", "api://scope", "test-correlation-id");

            // Assert
            Assert.Equal(HttpStatusCode.OK, result.StatusCode);
            var content = await result.Content.ReadAsStringAsync();
            content.Should().Contain("retrieved");
        }

        [Fact]
        public async Task GetAuditAsyncCall_ShouldThrowHttpRequestException_OnFailure()
        {
            // Arrange: Simulate an HttpRequestException
            var exception = new HttpRequestException("Network failure");

            _httpClientFactoryMock.Setup(f => f.CreateClient(It.IsAny<string>())).Throws(exception);

            // Act & Assert: Ensure `HttpRequestException` is thrown and contains expected error key
            var thrownException = await Assert.ThrowsAsync<HttpRequestException>(async () =>
                await _httpClientService.GetAuditAsyncCall("https://example.com", "api://scope", "test-correlation-id"));

            Assert.NotNull(thrownException);
            Assert.True(thrownException.Data.Contains(CommonConstants.HttpServiceErrorKey));
            Assert.Equal("Error in GetAuditAsyncCall", thrownException.Data[CommonConstants.HttpServiceErrorKey]);
        }

        [Fact]
        public async Task GetStringAsync_ShouldReturnExpectedResponse()
        {
            // Arrange: Mock HttpClient response
            var responseContent = "Mock response data";
            var httpClient = CreateMockHttpClient(responseContent);

            _httpClientFactoryMock.Setup(f => f.CreateClient(It.IsAny<string>())).Returns(httpClient);

            // Act
            var result = await _httpClientService.GetStringAsync("https://example.com");

            // Assert
            Assert.Equal(responseContent, result);
        }
    }
}
