﻿namespace Aurora.RBACService.Tests.Infrastructure
{
    public class ReadWriteDbContextTests
    {
        private readonly Mock<IConfiguration> _mockConfiguration;

        public ReadWriteDbContextTests()
        {
            _mockConfiguration = new Mock<IConfiguration>();
            _mockConfiguration.Setup(config => config["ConnectionStrings:ReadWriteDb"])
                .Returns("Server=localhost;Database=TestDb;User Id=sa;Password={testDbPassword};");
        }

        [Fact]
        public void Constructor_WithConfiguration_ShouldInitialize()
        {
            // Act
            var dbContext = new ReadWriteDbContext(_mockConfiguration.Object);

            // Assert
            Assert.NotNull(dbContext);
        }

        [Fact]
        public void Constructor_WithConfigurationAndOptions_ShouldInitialize()
        {
            // Arrange
            var options = new DbContextOptions<ReadWriteDbContext>();

            // Act
            var dbContext = new ReadWriteDbContext(_mockConfiguration.Object, options);

            // Assert
            Assert.NotNull(dbContext);
        }

        [Fact]
        public void Constructor_WithOnlyOptions_ShouldInitialize()
        {
            // Arrange
            var options = new DbContextOptions<ReadWriteDbContext>();

            // Act
            var dbContext = new ReadWriteDbContext(options);

            // Assert
            Assert.NotNull(dbContext);
        }

        [Fact]
        public void DbContext_ShouldHaveSqlServerConfigured()
        {
            // Arrange
            var optionsBuilder = new DbContextOptionsBuilder<ReadWriteDbContext>();

            // Act
            var dbContext = new ReadWriteDbContext(_mockConfiguration.Object, optionsBuilder.Options);

            // Assert
            var isSqlServer = dbContext.Database.ProviderName == "Microsoft.EntityFrameworkCore.SqlServer";
            Assert.True(isSqlServer, "Database provider should be SQL Server.");
        }
    }
}
