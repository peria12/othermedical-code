﻿namespace Aurora.RBACService.Tests.Infrastructure
{
    public class ReadOnlyDbContextTests
    {
        private readonly Mock<IConfiguration> _mockConfiguration;

        public ReadOnlyDbContextTests()
        {
            // Ensure correct interface usage
            _mockConfiguration = new Mock<IConfiguration>();

            // Fix: Use GetSection().Value to correctly mock configuration values
            var mockSection = new Mock<IConfigurationSection>();
            mockSection.Setup(x => x.Value)
                .Returns("Server=localhost;Database=TestDb;User Id=sa;Password={testDbPassword};");

            _mockConfiguration.Setup(x => x.GetSection("ConnectionStrings:ReadOnlyDb"))
                .Returns(mockSection.Object);
        }

        [Fact]
        public void Constructor_WithConfiguration_ShouldInitialize()
        {
            // Act
            var dbContext = new ReadOnlyDbContext(_mockConfiguration.Object);

            // Assert
            Assert.NotNull(dbContext);
        }

        [Fact]
        public void Constructor_WithConfigurationAndOptions_ShouldInitialize()
        {
            // Arrange
            var options = new DbContextOptions<ReadOnlyDbContext>();

            // Act
            var dbContext = new ReadOnlyDbContext(_mockConfiguration.Object, options);

            // Assert
            Assert.NotNull(dbContext);
        }

        [Fact]
        public void Constructor_WithOnlyOptions_ShouldInitialize()
        {
            // Arrange
            var options = new DbContextOptions<ReadOnlyDbContext>();

            // Act
            var dbContext = new ReadOnlyDbContext(options);

            // Assert
            Assert.NotNull(dbContext);
        }

        [Fact]
        public void GetPatientOverviewByIdAsync_ShouldThrowNotImplementedException()
        {
            // Arrange
            var patientId = "12345";

            // Act & Assert
            Assert.Throws<NotImplementedException>(() => ReadOnlyDbContext.GetPatientOverviewByIdAsync(patientId));
        }

        [Fact]
        public void OnConfiguring_ShouldConfigureSqlServer_WhenNotConfigured()
        {
            // Arrange
            var optionsBuilder = new DbContextOptionsBuilder<ReadOnlyDbContext>();
            var context = new ReadOnlyDbContext(_mockConfiguration.Object, optionsBuilder.Options);

            // Act
            var connectionString = context.Database.GetDbConnection().ConnectionString;

            // Assert
            connectionString.Should().BeNullOrEmpty();
        }

        [Fact]
        public void OnConfiguring_ShouldNotOverrideExistingConfiguration()
        {
            // Arrange
            var optionsBuilder = new DbContextOptionsBuilder<ReadOnlyDbContext>();
            optionsBuilder.UseInMemoryDatabase("TestDatabase");

            var context = new ReadOnlyDbContext(optionsBuilder.Options);

            // Act
            var databaseProvider = context.Database.ProviderName;

            // Assert
            databaseProvider.Should().Be("Microsoft.EntityFrameworkCore.InMemory");
        }
    }
}
