﻿namespace Aurora.RBACService.Tests.Infrastructure
{
    public class BaseDbContextTests
    {
        private readonly Mock<IHttpContextAccessor> _mockHttpContextAccessor;

        public BaseDbContextTests()
        {
            _mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        }

        [Fact]
        public void PrepareConnectionString_ShouldReturnNull_WhenHttpContextIsNull()
        {
            // Arrange
            _mockHttpContextAccessor.Setup(x => x.HttpContext).Returns((HttpContext)null!);

            // Act
            var result = TestDbContext.PrepareConnectionString(isReadOnlyIntent: false);

            // Assert
            result.Should().BeNull();
        }

        [Fact]
        public void PrepareConnectionString_ShouldReturnNull_WhenHeaderRegionCodeIsMissing()
        {
            // Arrange
            var context = new DefaultHttpContext();
            _mockHttpContextAccessor.Setup(x => x.HttpContext).Returns(context);

            // Act
            var result = TestDbContext.PrepareConnectionString(isReadOnlyIntent: false);

            // Assert
            result.Should().BeNull();
        }

        [Fact]
        public void PrepareConnectionString_Should_RemoveApplicationIntent_And_SplitCorrectly()
        {
            // Arrange
            string connectionString = "Server=myServer;Database=myDB;ApplicationIntent=readwrite;User Id=myUser;Password=myPass;";

            // Act
            var connectionParts = connectionString
                .Split(';', StringSplitOptions.RemoveEmptyEntries)
                .Where(x => !x.StartsWith("ApplicationIntent", StringComparison.OrdinalIgnoreCase))
                .ToList();

            // Assert
            connectionParts.Should().Contain("Server=myServer");
            connectionParts.Should().Contain("Database=myDB");
            connectionParts.Should().Contain("User Id=myUser");
            connectionParts.Should().Contain("Password=myPass");
            connectionParts.Should().NotContain(x => x.StartsWith("ApplicationIntent", StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public void PrepareConnectionString_Should_Handle_EmptyString()
        {
            // Arrange
            string connectionString = "ApplicationIntent=readwrite;";

            // Act
            var connectionParts = connectionString
                    .Split(';', StringSplitOptions.RemoveEmptyEntries)
                    .Where(x => !x.StartsWith("ApplicationIntent", StringComparison.OrdinalIgnoreCase))
                    .ToList();

            // Assert
            connectionParts.Should().BeEmpty();
        }

        [Fact]
        public void PrepareConnectionString_Should_Handle_CaseInsensitive_ApplicationIntent()
        {
            // Arrange
            string connectionString = "Server=myServer;Database=myDB;APPLICATIONINTENT=readonly;User Id=myUser;Password=myPass;";

            // Act
            var connectionParts = connectionString
                .Split(';', StringSplitOptions.RemoveEmptyEntries)
                .Where(x => !x.StartsWith("ApplicationIntent", StringComparison.OrdinalIgnoreCase))
                .ToList();

            // Assert
            connectionParts.Should().Contain("Server=myServer");
            connectionParts.Should().Contain("Database=myDB");
            connectionParts.Should().Contain("User Id=myUser");
            connectionParts.Should().Contain("Password=myPass");
            connectionParts.Should().NotContain(x => x.StartsWith("ApplicationIntent", StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public void Should_Remove_ApplicationIntent_From_List()
        {
            // Arrange
            var connectionParts = new List<string>
        {
            "Server=myServer",
            "Database=myDB",
            "ApplicationIntent",
            "User Id=myUser",
            "Password=myPass"
        };

            // Act
            var filteredParts = connectionParts
                .Where(x => !x.Equals("ApplicationIntent", StringComparison.OrdinalIgnoreCase))
                .ToList();

            // Assert
            filteredParts.Should().Contain("Server=myServer");
            filteredParts.Should().Contain("Database=myDB");
            filteredParts.Should().Contain("User Id=myUser");
            filteredParts.Should().Contain("Password=myPass");
            filteredParts.Should().NotContain("ApplicationIntent");
        }

        [Fact]
        public void Should_Remove_ApplicationIntent_CaseInsensitive()
        {
            // Arrange
            var connectionParts = new List<string>
        {
            "Server=myServer",
            "Database=myDB",
            "APPLICATIONINTENT",
            "User Id=myUser",
            "Password=myPass"
        };

            // Act
            var filteredParts = connectionParts
                .Where(x => !x.Equals("ApplicationIntent", StringComparison.OrdinalIgnoreCase))
                .ToList();

            // Assert
            filteredParts.Should().Contain("Server=myServer");
            filteredParts.Should().Contain("Database=myDB");
            filteredParts.Should().Contain("User Id=myUser");
            filteredParts.Should().Contain("Password=myPass");
            filteredParts.Should().NotContain("APPLICATIONINTENT");
        }

        [Fact]
        public void Should_Not_Alter_List_If_ApplicationIntent_Not_Present()
        {
            // Arrange
            var connectionParts = new List<string>
        {
            "Server=myServer",
            "Database=myDB",
            "User Id=myUser",
            "Password=myPass"
        };

            // Act
            var filteredParts = connectionParts
                .Where(x => !x.Equals("ApplicationIntent", StringComparison.OrdinalIgnoreCase))
                .ToList();

            // Assert
            filteredParts.Should().BeEquivalentTo(connectionParts);
        }

        public static class TestDbContext
        {
            public static string? PrepareConnectionString(bool isReadOnlyIntent)
            {
                return null;
            }
        }
    }
}
