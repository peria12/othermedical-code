﻿
namespace Aurora.RBACService.Tests
{
    public class DependencyRegisterTests
    {
        private readonly IConfiguration _configuration;
        private readonly Mock<IHttpClientFactory> _httpClientFactoryMock;
        private readonly Mock<ILogger<LanguageWorkerService>> _loggerMock;

        public DependencyRegisterTests()
        {
            // Shared in-memory configuration
            var inMemorySettings = new List<KeyValuePair<string, string?>>
            {
                new(CommonConstants.MSGroupCode,"TestGroupCode"),
                new("LanguageCacheExpiryMinutes","60")
            };

            _configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            _httpClientFactoryMock = new Mock<IHttpClientFactory>();
            _loggerMock = new Mock<ILogger<LanguageWorkerService>>();
        }

        private static void AssertServiceRegisteredTransient<TService, TImplementation>(IServiceCollection services)
        {
            var descriptor = services.FirstOrDefault(d =>
                d.ServiceType == typeof(TService) &&
                d.ImplementationType == typeof(TImplementation) &&
                d.Lifetime == ServiceLifetime.Transient);

            Assert.NotNull(descriptor);
        }

        [Fact]
        public void AddCrossCuttingConcerns_ShouldRegisterTransientServices()
        {
            // Arrange
            var services = new ServiceCollection();

            services.AddSingleton(_configuration);
            services.AddSingleton(_httpClientFactoryMock.Object);
            services.AddSingleton(typeof(ILogger<LanguageWorkerService>), _loggerMock.Object);

            // Act
            var result = services.AddCrossCuttingConcerns(_configuration);

            // Assert
            Assert.NotNull(result);
            AssertServiceRegisteredTransient<ITelemetryClientWrapper, TelemetryClientWrapper>(services);
            AssertServiceRegisteredTransient<IHttpClientService, HttpClientService>(services);

            var hostedServiceDescriptor = services.FirstOrDefault(
                d => d.ServiceType == typeof(IHostedService) &&
                     d.ImplementationFactory != null);

            Assert.NotNull(hostedServiceDescriptor);
        }

        [Fact]
        public void AddLanguageWorkerService_ShouldRegisterLanguageWorkerAsHostedService()
        {
            // Arrange
            var services = new ServiceCollection();

            services.AddSingleton(_configuration);
            services.AddSingleton(_httpClientFactoryMock.Object);
            services.AddSingleton(typeof(ILogger<LanguageWorkerService>), _loggerMock.Object);
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            // Act
            DependencyRegister.AddLanguageWorkerService(services);

            // Assert
            var provider = services.BuildServiceProvider();
            var hostedServices = provider.GetServices<IHostedService>();

            Assert.Contains(hostedServices, hs => hs.GetType() == typeof(LanguageWorkerService));
        }
    }
}
