﻿namespace Aurora.RBACService.Tests
{
    public static class TestConstants
    {
        public const string STATUSCODEUNAUTHORIZED = "401:Unauthorized";
        public const string STATUS500INTERNALSERVERERROR = "500:Internal Server Error";
        public const string STATUS408REQUESTTIMEOUT = "408:Request Timeout";
        public const string STATUS503SERVICEUNAVAILABLE = "503:Service Unavailable";
        public const string STATUS400BADREQUEST = "400:BadRequest";
        public const string STATUS404NOTFOUND = "404:NotFound";
        public const string STATUS409CONFLICT = "409:Conflict";
        public const string STATUS501NOTIMPLEMENTED = "501:NotImplemented";
    }
}
