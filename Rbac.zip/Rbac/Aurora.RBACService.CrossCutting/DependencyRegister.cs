﻿namespace Aurora.RBACService.CrossCutting
{
    public static class DependencyRegister
    {
        public static IServiceCollection AddCrossCuttingConcerns(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddTransient<ITelemetryClientWrapper, TelemetryClientWrapper>();
            services.AddTransient<IHttpClientService, HttpClientService>();
            AddLanguageWorkerService(services);
            return services;
        }

        public static void AddLanguageWorkerService(IServiceCollection services)
        {
            ServiceProvider sp = services.BuildServiceProvider();

            DefaultHttpContext context = new()
            {
                User = new ClaimsPrincipal(new ClaimsIdentity())
            };
            HttpContextAccessor HttpContextAccessor = new() { HttpContext = context };

            HttpClientService httpClientService = new(
               HttpContextAccessor,
               sp.GetRequiredService<IConfiguration>(),
               sp.GetRequiredService<IHttpClientFactory>()
           );

            services.AddHostedService(sp => new LanguageWorkerService(
                sp.GetRequiredService<IConfiguration>(),
                httpClientService,
                sp.GetRequiredService<ILogger<LanguageWorkerService>>()));
        }
    }
}
