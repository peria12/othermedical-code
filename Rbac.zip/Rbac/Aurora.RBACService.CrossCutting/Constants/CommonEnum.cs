﻿namespace Aurora.RBACService.CrossCutting.Constants
{
    public enum ResponseStatusCodes
    {
        Success = 200,
        Errored = 600,
        RecordNotFound = 405,
        Success_Create = 201,
        BadRequest = 400,
        Unauthorized = 401,
        Forbidden = 403,
        NotFound = 404,
        RequestTimeout = 408,
        Conflict = 409,
        InternalServerError = 500,
        ServiceUnavailable = 503,
    }

    public enum DocumentReferencetype
    {
        Physician,
        Nurse
    }

    public enum VitalsCodes
    {
        Temperature,
        BloodPressure,
        PulseRate,
        GRBS,
        RespirationRate,
        SpO2
    }

    public enum WhatshappeningCategoryList
    {
        All = 0,
        Packages = 1,
        Events = 2,
        Articles = 3,
        News = 4
    }
    public enum Source
    {
        Aurora,
        Care21,
        MCare21,
        Minerva
    }

    public enum WeekNumber
    {
        First = 1,
        Second = 2,
        Third = 3,
        Fourth = 4,
        Fifth = 5,
        Sixth = 6
    }
    public enum ScheduleViewType
    {
        Day,
        Week,
        Month
    }

}
