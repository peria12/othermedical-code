﻿namespace Aurora.RBACService.CrossCutting.Constants
{
    [ExcludeFromCodeCoverage]
    public static class CommonConstants
    {
        #region Headers
        public const string HEADERREGIONCODE = "RegionCode";
        public const string HEADERREGIONCODEDESCRIPTION = "Region code header";
        public const string HEADERCORRELATIONID = "X-Correlation-ID";
        public const string HEADERTYPE = "string";
        public const string AURORAREGIONCODE = "AuroraRegionCode";
        #endregion

        #region Header Constants
        public const string HeaderIdempotencyKey = "IdempotencyKey";
        public const string HeaderLanguageCode = "LanguageCode";
        public const string HeaderRegionCode = "RegionCode";
        public const string HeaderFacilityCode = "FacilityCode";
        public const string HeaderSessionId = "SessionId";
        public const string HeaderCorrelationId = "CorrelationId";
        public const string HeaderPostManToken = "PostMan-Token";
        public const string HeaderForceRegionCall = "ForceRegionCall";
        public const string HeaderTimeZoneOffSet = "X-Client-Timezone";
        public const string DefaultUtcOffset = "UTC+08:00";
        public const string DefaultTimeZoneId = "Singapore Standard Time";
        public const string HeaderResponseTimeZoneOffset = "X-Server-Timezone";
        public const string ApplicationTypeJson = "application/json";
        public const string Bearer = "Bearer";
        public const string HeaderLastHttpStatusCode = "LastHttpStatusCode";
        public static readonly string[] IdempotentMethods = { "PUT", "DELETE" };
        public static readonly string[] NonIdempotentStatusCodes = { "408", "500", "503", "504" };

        #endregion

        #region Azure Ad constants
        public const string GRANTTYPE = "grant_type";
        public const string GRANTTYPEPASSWORD = "password";
        public const string CLIENTID = "client_id";
        public const string CLIENTSECRET = "client_secret";
        public const string SCOPE = "scope";
        public const string SCOPEOPENID = "openid offline_access User.Read";
        public const string USERNAME = "username";
        public const string PASSWORD = "password";
        public const string ACCESSTOKEN = "access_token";
        public const string NAME = "name";
        public const string UPN = "upn";
        public const string AUTH = "Authorization";
        public const string BEARER = "Bearer ";
        public const string AZUREADBEARER = "AzureAdBearer";
        public const string MYSADMCONNECTIONSTRING = "Aurora-MYSADMConnectionString";
        public const string AZUREKEYVAULTURI = "VaultUri";
        public const string AZUREIDENTITYCLIENTID = "IdentityClientId";
        public const string ISKEYVAULTCONFIGURED = "isKeyVaultConfigured";
        #endregion

        #region Pagination constants
        public const string PAGINATION_ASCENDING = "asc";
        public const string PAGINATION_DESCENDING = "desc";
        public const string DEFAULT_SORT = "id";
        public const string INVALID_PAGE_NUMBER = "INVALID_PAGE_NUMBER";
        public const string INVALID_PAGE_SIZE = "INVALID_PAGE_SIZE";
        #endregion

        #region CDN detail
        public const string CDNFilePrefix = "mcare21";
        public const string CDNConnectioinString = "CDNConnectionString";
        public const string CDNContainerName = "CDNContainerName";
        public const string CDNJsonFolderName = "CDNJSONFolderName";
        public const string CDNFileExtension = ".json";
        public const string LanguageAbsoluteExpiryMinutes = "LanguageAbsoluteExpiryMinutes";
        public const string CDNSASToken = "MultilingualCDNSASToken";
        public const string CDNUrl = "MultilingualCDNUrl";
        #endregion

        #region ExceptionHandlingConst
        public const string ERROR_CODE = "ErrorCode";
        public const string ERROR_CODE_VALUE = "ERR-ADMINISTRATION-MS";
        public const string ERRORID = "ErrorId";
        public const string ERROR = "ERROR";
        public const string WARNING = "WARNING";
        public const string ERROR_UNAUTHORIZED = "ERROR_UNAUTHORIZED";
        public const string ERROR_ACCESS_DENIED = "ERROR_ACCESS_DENIED";
        public const string ERROR_NOT_FOUND = "ERROR_NOT_FOUND";
        public const string ERROR_BADREQUEST = "ERROR_BADREQUEST";
        public const string ERROR_METHOD_NOT_ALLOWED = "ERROR_METHOD_NOT_ALLOWED";
        public const string ERROR_METHOD_TIMEOUT = "ERROR_METHOD_TIMEOUT";
        public const string ERROR_TO_MANY_REQUEST = "ERROR_TO_MANY_REQUEST";
        public const string ERROR_CONFLICT = "ERROR_CONFLICT";
        public const string ERROR_LOCKED = "ERROR_LOCKED";
        public const string ERROR_TIMEOUT_EXCEPTION = "ERROR_TIMEOUT_EXCEPTION";
        public const string ERROR_HTTP_REQUEST_EXCEPTION = "ERROR_HTTP_REQUEST_EXCEPTION";
        public const string ERROR_INTERNAL_SERVER_ERROR = "ERROR_INTERNAL_SERVER_ERROR";
        public const string ERROR_ARGUMENT_EXCEPTION = "ERROR_ARGUMENT_EXCEPTION";
        public const string ERROR_KEY_NOT_FOUND_EXCEPTION = "ERROR_KEY_NOT_FOUND_EXCEPTION";
        public const string ERROR_INVALID_OPERATION_EXCEPTION = "ERROR_INVALID_OPERATION_EXCEPTION";
        public const string ERROR_NULL_EXCEPTION = "ERROR_NULL_EXCEPTION";
        public const string ERROR_HEADER_MISSING = "ERROR_HEADER_MISSING";
        public const string ERROR_HEADER_REGION_CODE_MISSING = "ERROR_HEADER_REGION_CODE_MISSING";
        public const string SUCCESS_VALUE = "SUCCESS";
        public const string NAME_VALUE = "Doctor Name";
        #endregion

        #region Other Constant Of Error handling 
        public const string VALIDATION = "VALIDATION";
        #endregion

        #region String Format
        public const string DAFULTDATEFORMAT = "dddd, dd MMM yyyy";
        public const string DAFULTTIMEFORMAT = "HH:mm";
        #endregion

        #region Telemetry Constants
        public const string INFO = "INFO";
        public const string SUCCESS = "SUCCESS";
        public const string TRUE = "TRUE";
        public const string FALSE = "FALSE";
        public const string ErrorCodeValue = "MS_REGISTRATION";
        public const string ErrorCode = "ErrorCode";
        public const string ErrorId = "ErrorId"; // GUID
        public const string MethodName = "METHOD_NAME";
        public const string ErrorDetail = "ErrorDetail";
        #endregion

        #region Other Constants
        public const string JWTKEY = "Jwt:Key";
        public const string CONTENTTYPEJSON = "application/json";
        public const string USERIDADMIN = "Admin";
        public const string APPLICATIONINTENT = "ApplicationIntent";
        public const string DATABASECONNECTIONERROR = "Error occured while preparing database connection";
        public static readonly string[] ALLOWEDPLATFORMS = { "Patient App", "Doctor App", "Patient Portal", "Other Portal" };
        public const string DOCUMENTREFERENCE_SUFFIX = "DOC_";
        public const int VERSION1 = 1;
        #endregion

        #region Other PatientInformationConstants
        public const string USERID = "UserId";
        public const string PATIENTNAME = "Nguyen Van A";
        public const string PREFERREDNAME = "Van A";
        public const string DOB = "1988-03-30";
        public const string GENDER = "M";
        public const string MALE = "Male";
        public const string FEMALE = "Female";
        public const string PROFILEIMAGE = "profile5.jpg";
        public const string MRN = "MRN005";
        public const string ORGANIZATION = "Hospital E";
        public const string FACILITYNAME = "City Hospital";
        public const string VNO = "A0000000001";
        #endregion

        #region Microservice API Constants
        public const string APPINSIGHTSINSTRUMENTATIONKEY = "AppInsightsInstrumentationKey";
        public const string APPHTTPCLIENT = "Aurora";
        public const string REDISCONNECTIONSTRING = "RedisConnectionString";
        public const string TENANTID = "TenantID";
        public const string ALLOWEDCORS = "AllowedCors";
        public const string RBAC_API = "RBACAPI";
        public const string VALIDATEUSERANDGETRESOURCES = "RBAC/ValidateUserandGetResources";
        public const string AURORAPATIENTLIFECYCLESERVICEAPIURL = "GetPersonalInformationAPI";
        public const string MSGroupCode = "MSGroupCode";
        public const string MY = "MY";
        public const string HttpServiceErrorKey = "HttsService";
        public const string CustomErrorId = "CUSTOM_ERROR_ID";
        public const string APIPrefix = "RBACService";
        public const string IsApplyMigration = "ApplyMigration";
        public const string _languageCode = "en";

        public const string RBACServiceAPIClientId = "ClientID:Aurora-RBACService";
        public const string RBACServiceAPIClientSecret = "ClientSecret-Aurora-RBACService";
        public const string AuroraAppointmentServiceAPIURL = "ClientID:Aurora-AppointmentService";
        public const string AurorAppointmentServiceBaseURL = "Aurora-AppointmentServiceURL";
        public const string AurorAppointmentServiceAPIURL = "/api/Holiday/";
        public const string AurorAppointmentServiceCreateAPIURL = "/api/Holiday/Create";
        public const string AurorAppointmentServiceSearchAPIURL = "/api/Holiday/Search";



        public const string AppointmentServiceAPIClientId = "ClientID:Aurora-AppointmentService";
        public const string AppointmentServiceAPIClientSecret = "ClientSecret-Aurora-AppointmentService";

        public const string AdminServiceAPIClientId = "ClientID:Aurora-AdministrationService";
        public const string AdminServiceAPIClientSecret = "ClientSecret-Aurora-AdministrationService";
        public const string TenantId = "TenantId";

        public const string PatientServiceURL = "ClientID:Aurora-PatientLifeCycleService";
        public const string AuroraPatientServiceBaseURL = "Aurora-PatientLifeCycleServiceURL";
        public const string AuroraAppointmentGetHolidayAPIURL = "/api/Holiday/GetForLocation";
        public const string AuroraAppointmentGetExceptionsAPIURL = "/api/ScheduleException/Exceptions";
        public const string AuroraAppointmentGetAppointmentTimesAPIURL = "/api/Appointment/GetAppointmentTimes";
        public const string AuroraPatientNamesAndMrnAPIURL = "/api/Patient/NamesAndMRNs";

        public const string LanguageServiceAPIClientId = "ClientID:CA-MCare21-LanguageService";
        public const string LanguageServiceAPIClientSecret = "ClientSecret-CA-MCare21-LanguageService";
        public const string LanguageServiceAPIURL = "MCare21LanguageServiceAPI"; //dev url
        public const string BillingServiceAPIURL = "MCare21BillingServiceAPIURL";
        public const string MedicalRecordServiceAPIURL = "MCare21APIURLMedicalRecordService";
        public const string GetLanguageResources = "api/LanguageResource/GetLanguageResources";
        public const string GetActiveLanguageCodes = "api/LanguageResource/GetActiveLanguageCodes";

        #endregion

        #region Cache Constants
        public const string RedisClusterConnectionString = "ConnectionString-Aurora-Redis-EP";
        public const string CacheIdentifierKeyAsterik = "*";
        public const string CacheIdentifierKeyDollar = "$";

        public const string JsonCommandGet = "JSON.GET";
        public const string JsonCommandSet = "JSON.SET";
        public const string JsonCommandDel = "JSON.DEL";
        #endregion
    }

    [ExcludeFromCodeCoverage]
    public static class ResponseStatusCode
    {
        public const string STATUS_SUCCESS = "200";
        public const string STATUS_SUCCESS_UPDATED = "202";
        public const string STATUS_BADREQUEST = "400";
        public const string STATUS_UNAUTHORIZED = "401";
        public const string STATUS_FORBIDDEN = "403";
        public const string STATUS_NOTFOUND = "404";
        public const string STATUS_REQUESTTIMEOUT = "408";
        public const string STATUS_CONFLICT = "409";
        public const string STATUS_INTERNAL_SERVER_ERROR = "500";
        public const string STATUS_SERVICE_UNAVAILABLE = "503";
    }
}
