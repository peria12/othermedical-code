﻿namespace Aurora.RBACService.CrossCutting.Constants
{
    [ExcludeFromCodeCoverage]
    public static class AppConstants
    {
        public const string MICROSERVICECODE = "RBAC";
        public const string CONNECTIONSTRINGPREFIX = "Aurora-";
        public const string RECORDVERSION = "RecordVersion";
        public const string HttpClientTimeout = "HttpClientTimeout";
        public const string TokenType = "Bearer";
        public const string Preferred_Username = "preferred_username";

        #region Validate Maximum Characters       
        public const string MAXIMUM9CHARACTER = "Maximum 9 characters";
        public const string MAXIMUM50CHARACTER = "Maximum 50 characters";
        public const string MAXIMUM30CHARACTER = "Maximum 30 characters";
        public const string MAXIMUM20CHARACTER = "Maximum 20 characters";
        public const string MAXIMUM40CHARACTER = "Maximum 40 characters";
        public const string MAXIMUM160CHARACTER = "Maximum 160 characters";
        public const string MAXIMUM100CHARACTER = "Maximum 100 characters";
        public const string MAXIMUM150CHARACTER = "Maximum 150 characters";
        public const string MAXIMUM255CHARACTER = "Maximum 255 characters";
        public const string MAXIMUM500CHARACTER = "Maximum 500 characters";
        public const string MAXIMUM1000CHARACTER = "Maximum 1000 characters";
        public const string MAXIMUM10000CHARACTER = "Maximum 10000 characters";
        #endregion

        #region Pattern Validations        
        public const string CODEVALIDATIONPATTERN = @"^[a-zA-Z0-9]+([.-]?[a-zA-Z0-9]*)*[.-]?$";
        public const string EWSDECIMALVALIDATIONPATTERN = @"^\d+(\.\d{1})?$";
        public const string NUMBERVALIDATIONPATTERN = @"[0-9]";
        public const string REGEXHEXCOLORCODE = @"^#(?:[0-9a-fA-F]{3}){1,2}([0-9a-fA-F]{2})?$";
        public const string SPECIALCHARACTERNOTALLOW = @"^[^\W_][\w\W]*$";
        #endregion

        #region Concurrency Response Message
        public static readonly string CONCURRENCYERRORSTART = "The record has been updated by another user";
        public static readonly string CONCURRENCYERROREND = "Please refresh the screen and can try again if you want update the record";
        public static readonly string CONCURRENCYERROR = "just now";
        #endregion

        #region Validation Message
        public const string STATUS_DATA_FOUND = "Record found";
        public const string STATUS_NODATA = "Record not found";
        public const string RECORD_ADDED_SUCESSFULLY = "Record Added Successfully";
        public const string RECORD_UPDATED_SUCESSFULLY = "Record Updated Successfully";
        public const string RECORD_FETCHED_SUCCESSFULLY = "Record fetched Successfully";
        public const string STATUS_INTERNAL_SERVER_ERROR = "Internal server error";
        #endregion
    }
}
