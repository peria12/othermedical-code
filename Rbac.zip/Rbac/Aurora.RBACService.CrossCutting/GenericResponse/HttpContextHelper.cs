﻿namespace Aurora.RBACService.CrossCutting.GenericResponse
{
    [ExcludeFromCodeCoverage]
    public static class HttpContextHelper
    {
        public static string GetLanguageCode(IHttpContextAccessor httpContextAccessor)
        {
            if (httpContextAccessor?.HttpContext?.Request?.Headers != null &&
                httpContextAccessor.HttpContext.Request.Headers.TryGetValue(CommonConstants.HeaderLanguageCode, out var headerLanguageCode))
            {
                return headerLanguageCode.ToString();
            }

            return string.Empty;
        }
    }

}
