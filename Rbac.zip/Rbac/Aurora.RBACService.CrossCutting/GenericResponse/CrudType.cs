﻿namespace Aurora.RBACService.CrossCutting.GenericResponse
{
    public enum CrudType
    {
        Create = 1,
        Edit = 2,
        Delete = 3,
        Get = 4,
        GetList = 5,
        Others = 6
    }
}
