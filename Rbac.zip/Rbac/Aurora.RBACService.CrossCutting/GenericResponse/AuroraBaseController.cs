﻿namespace Aurora.RBACService.CrossCutting.GenericResponse
{
    [ExcludeFromCodeCoverage]
    public class AuroraBaseController : ControllerBase
    {
        private readonly string _languageCode;
        public AuroraBaseController(IHttpContextAccessor httpContextAccessor)
        {
            _languageCode = HttpContextHelper.GetLanguageCode(httpContextAccessor);

        }

        public static GenericResponse2<T> ReturnResponse<T>(T? result, string message) where T : struct
        {
            return new GenericResponse2<T>
            {
                IsSuccess = true,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                MessageType = CommonConstants.SUCCESS,
                Message = message,
                Result = result
            };
        }
        public GenericResponse<T> ReturnGetResponse<T>(T? result) where T : class
        {
            var languageKey = result != null ? LanguageResourceGeneralKeys.STATUS_DATA_FOUND : LanguageResourceGeneralKeys.STATUS_NODATA;
            var message = LanguageTranslator.Instance.Translate(_languageCode, languageKey);

            return new GenericResponse<T>
            {
                IsSuccess = true,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                MessageType = CommonConstants.SUCCESS,
                Message = message,
                Result = result
            };
        }
        public GenericResponseList<T> ReturnGetListResponse<T>(IEnumerable<T>? result) where T : class
        {
            var languageKey = (result != null && result.Any()) ? LanguageResourceGeneralKeys.STATUS_DATA_FOUND : LanguageResourceGeneralKeys.STATUS_NODATA;
            var message = LanguageTranslator.Instance.Translate(_languageCode, languageKey);

            return new GenericResponseList<T>
            {
                IsSuccess = true,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                MessageType = CommonConstants.SUCCESS,
                Message = message,
                Result = result
            };
        }
        public GenericResponsePagedList<PaginationResult<T>> ReturnGetPagedListResponse<T>(PaginationResult<T>? result, PaginationQuery query) where T : class
        {
            var languageKey = result?.TotalCount > 0 ? LanguageResourceGeneralKeys.STATUS_DATA_FOUND : LanguageResourceGeneralKeys.STATUS_NODATA;
            var message = LanguageTranslator.Instance.Translate(_languageCode, languageKey);

            return new GenericResponsePagedList<PaginationResult<T>>
            {
                IsSuccess = true,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                MessageType = CommonConstants.SUCCESS,
                Message = message,
                Result = result?.Records.Select(r => new PaginationResult<T>()).ToList(),
                Count = result?.TotalCount ?? 0,
                PaginationQuery = query
            };
        }

        public GenericResponse2<T> ReturnChangeResponse<T>(CrudType endpontType, T? result,
            bool validationFailed = false, string? message = null) where T : struct
        {
            string responseCode = validationFailed
                ? ResponseStatusCode.STATUS_BADREQUEST
                : ResponseStatusCode.STATUS_SUCCESS;

            string messageType;
            bool hasError = false;

            switch (endpontType)
            {
                case CrudType.Create:
                case CrudType.Edit:
                    messageType = validationFailed ? CommonConstants.VALIDATION : CommonConstants.SUCCESS;
                    hasError = validationFailed;
                    break;

                case CrudType.Delete:
                    messageType = validationFailed ? CommonConstants.WARNING : CommonConstants.SUCCESS;
                    break;

                default:
                    messageType = validationFailed ? CommonConstants.WARNING : CommonConstants.SUCCESS;
                    break;
            }

            string finalMessage = GetFinalMessage(endpontType, validationFailed, message);

            return new GenericResponse2<T>
            {
                IsSuccess = true,
                HasError = hasError,
                StatusCode = responseCode,
                MessageType = messageType,
                Message = finalMessage,
                Result = result
            };
        }

        public GenericResponse<T> ReturnChangeResponse<T>(T? result, bool validationFailed = false,
           string? message = null) where T : class
        {
            return new GenericResponse<T>
            {
                IsSuccess = true,
                StatusCode = validationFailed ? ResponseStatusCode.STATUS_BADREQUEST : ResponseStatusCode.STATUS_SUCCESS,
                MessageType = validationFailed ? CommonConstants.WARNING : CommonConstants.SUCCESS,
                Message = message ?? LanguageTranslator.Instance.Translate(_languageCode, LanguageResourceGeneralKeys.STATUS_DATA_UPDATED),
                Result = result
            };
        }

        private string GetFinalMessage(CrudType endpontType, bool validationFailed, string? inputMessage)
        {
            if (validationFailed && !string.IsNullOrWhiteSpace(inputMessage))
                return inputMessage;

            return endpontType switch
            {
                CrudType.Create => LanguageTranslator.Instance.Translate(_languageCode, LanguageResourceGeneralKeys.STATUS_DATA_ADDED),
                CrudType.Edit => LanguageTranslator.Instance.Translate(_languageCode, LanguageResourceGeneralKeys.STATUS_DATA_UPDATED),
                CrudType.Delete => LanguageTranslator.Instance.Translate(_languageCode, LanguageResourceGeneralKeys.STATUS_DATA_DELETED),
                _ => LanguageTranslator.Instance.Translate(_languageCode, LanguageResourceGeneralKeys.STATUS_DATA_UPDATED)
            } ?? string.Empty; // Fallback in case Translate returns null
        }
    }
}
