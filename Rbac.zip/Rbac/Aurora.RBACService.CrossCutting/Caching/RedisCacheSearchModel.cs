﻿namespace Aurora.RBACService.CrossCutting.Caching
{
    [ExcludeFromCodeCoverage]
    public class RedisCacheSearchModel
    {
        public Query? Query { get; set; }
        public required string IndexName { get; set; }
        public PaginationQuery PaginationQuery { get; set; } = new();
    }
}
