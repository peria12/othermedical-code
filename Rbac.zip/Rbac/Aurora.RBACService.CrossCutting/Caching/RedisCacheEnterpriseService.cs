﻿namespace Aurora.RBACService.CrossCutting.Caching
{
    [ExcludeFromCodeCoverage]
    public class RedisCacheEnterpriseService : IRedisCacheEnterpriseService
    {
        private readonly IConnectionMultiplexer _cache;
        private readonly IDatabase _db;
        private readonly ILogger<RedisCacheEnterpriseService> _logger;
        private readonly JsonSerializerOptions _jsonSerializerOptions;

        public IConfiguration _configuration { get; }

        public RedisCacheEnterpriseService(IConnectionMultiplexer cache,
            IConfiguration configuration,
            ILogger<RedisCacheEnterpriseService> logger)
        {
            _cache = cache;
            _db = _cache.GetDatabase();
            _configuration = configuration;
            _logger = logger;

            _jsonSerializerOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        }

        public async Task<bool> SetSingleAsync<T>(string key, T value, TimeSpan? expiry = null) where T : class
        {
            try
            {
                var json = System.Text.Json.JsonSerializer.Serialize(value);
                var setResult = await _db.ExecuteAsync(CommonConstants.JsonCommandSet, key, "$", json);

                if (setResult.ToString()?.ToLower() != "ok")
                    return false;

                if (expiry.HasValue)
                {
                    var expireResult = await _db.KeyExpireAsync(key, expiry.Value);
                    return expireResult;
                }

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in SetSingleAsync : {ErrorMessage}", ex.Message);
                return false;
            }
        }

        public async Task<bool> SetListAsync<T>(string key, List<T> values, TimeSpan? expiry = null) where T : class
        {
            try
            {
                var json = System.Text.Json.JsonSerializer.Serialize(values);
                var setResult = await _db.ExecuteAsync(CommonConstants.JsonCommandSet, key, "$", json);

                if (setResult.ToString()?.ToLower() != "ok")
                    return false;

                if (expiry.HasValue)
                {
                    var expireResult = await _db.KeyExpireAsync(key, expiry.Value);
                    return expireResult;
                }

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in SetListAsync : {ErrorMessage}", ex.Message);
                return false;
            }
        }

        public async Task SetMultipleKeysAsync<T>(Dictionary<string, T> keyValuePairs, TimeSpan? expiry = null) where T : class
        {
            try
            {
                var batch = _db.CreateBatch();
                var tasks = new List<Task>();

                foreach (var kvp in keyValuePairs)
                {
                    var key = kvp.Key;
                    var json = System.Text.Json.JsonSerializer.Serialize(kvp.Value);

                    tasks.Add(batch.ExecuteAsync(CommonConstants.JsonCommandSet, key, CommonConstants.CacheIdentifierKeyDollar, json));

                    if (expiry.HasValue)
                    {
                        tasks.Add(batch.KeyExpireAsync(key, expiry.Value));
                    }
                }

                batch.Execute();
                await Task.WhenAll(tasks);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in SetMultipleKeysAsync : {ErrorMessage}", ex.Message);
            }
        }

        public async Task<T?> GetSingleAsync<T>(string key, string jsonPath = "$") where T : class
        {
            try
            {
                var result = await _db.ExecuteAsync(CommonConstants.JsonCommandGet, key, jsonPath);
                if (result.IsNull) return default;

                var json = result.ToString();

                // If it's wrapped in [ ], unwrap it
                if (json.StartsWith('[') && json.EndsWith(']'))
                {
                    json = json[1..^1];
                }

                return System.Text.Json.JsonSerializer.Deserialize<T>(json);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in GetSingleAsync : {ErrorMessage}", ex.Message);
                return default;
            }
        }

        public async Task<List<T>?> GetListAsync<T>(string key, string jsonPath = "$") where T : class
        {
            try
            {
                var result = await _db.ExecuteAsync(CommonConstants.JsonCommandGet, key, jsonPath);
                if (result.IsNull) return null;

                var json = result.ToString();
                return System.Text.Json.JsonSerializer.Deserialize<List<T>>(json);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in GetListAsync : {ErrorMessage}", ex.Message);
                return null;
            }
        }

        public async Task<List<T>?> GetListByPatternAsync<T>(string pattern, string jsonPath = "$") where T : class
        {
            try
            {
                var connection = await CreateRedisConnectionAsync();
                var server = connection.GetServer(connection.GetEndPoints()[0]);
                var db = connection.GetDatabase();

                var keys = server.Keys(pattern: pattern).ToArray();
                var resultList = new List<T>();

                foreach (var key in keys)
                {
                    var item = await GetDeserializedItemAsync<T>(db, key.ToString(), jsonPath);
                    if (item != null && item.Count > 0)
                        resultList.AddRange(item);
                }

                return resultList;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetListByPatternAsync for pattern: {Pattern}", pattern);
                return null;
            }
        }

        private async Task<ConnectionMultiplexer> CreateRedisConnectionAsync()
        {
            var connectionString = _configuration[CommonConstants.RedisClusterConnectionString];
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new ArgumentException("Redis connection string cannot be null or empty.");

            return await ConnectionMultiplexer.ConnectAsync(connectionString);
        }

        private static async Task<List<T>> GetDeserializedItemAsync<T>(IDatabase db, string key, string jsonPath) where T : class
        {
            var resultList = new List<T>();
            var redisResult = await db.ExecuteAsync(CommonConstants.JsonCommandGet, key, jsonPath);

            if (redisResult.IsNull) return resultList;

            var json = redisResult.ToString();
            if (string.IsNullOrWhiteSpace(json)) return resultList;

            if (json.StartsWith('[') && json.EndsWith(']'))
            {
                var list = System.Text.Json.JsonSerializer.Deserialize<List<T>>(json);
                if (list != null) resultList.AddRange(list);
            }
            else
            {
                var obj = System.Text.Json.JsonSerializer.Deserialize<T>(json);
                if (!EqualityComparer<T>.Default.Equals(obj, default!))
                    resultList.Add(obj);
            }
            return resultList;
        }

        public async Task<bool> DeleteSingleAsync(string key)
        {
            try
            {
                return await _db.KeyDeleteAsync(key);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in DeleteSingleAsync : {ErrorMessage}", ex.Message);
                return false;
            }
        }

        public async Task<long> DeleteKeysAsync(IEnumerable<string> keys)
        {
            try
            {
                var redisKeys = keys.Select(k => (RedisKey)k).ToArray();
                if (redisKeys.Length == 0) return 0;

                long deletedCount = await _db.KeyDeleteAsync(redisKeys);
                return deletedCount;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in DeleteKeysAsync : {ErrorMessage}", ex.Message);
                return 0;
            }
        }

        public async Task<bool> DeleteByJsonPathAsync(string key, string jsonPath)
        {
            try
            {
                var result = await _db.ExecuteAsync(CommonConstants.JsonCommandDel, key, jsonPath);

                return (int?)result > 0;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in DeleteByJsonPathAsync : {ErrorMessage}", ex.Message);
                return false;
            }
        }

        public async Task DeleteByPatternAsync(string pattern, int pageSize = 500, int batchSize = 1000, int database = -1)
        {
            try
            {
                var connectionStringValue = _configuration[CommonConstants.RedisClusterConnectionString];
                var endpoints = connectionStringValue!.Split(',', StringSplitOptions.RemoveEmptyEntries);

                if (endpoints.Length == 0 || _cache == null || _db == null)
                {
                    _logger.LogWarning("Redis connection string or cache instance is not configured properly.");
                    return;
                }

                // Attempt to find a valid, connected, non-replica server
                IServer? server = null;
                foreach (var ep in _cache.GetEndPoints())
                {
                    var s = _cache.GetServer(ep);
                    if (s.IsConnected && !s.IsReplica)
                    {
                        server = s;
                        break;
                    }
                }

                if (server == null)
                {
                    _logger.LogError("No connected, non-replica Redis server found.");
                    return;
                }

                var keysToDelete = new List<RedisKey>(batchSize);
                pattern = pattern.Contains(CommonConstants.CacheIdentifierKeyAsterik)
                    ? pattern
                    : $"{pattern}{CommonConstants.CacheIdentifierKeyAsterik}";

                foreach (var key in server.Keys(database: database, pattern: pattern, pageSize: pageSize))
                {
                    keysToDelete.Add(key);

                    if (keysToDelete.Count >= batchSize)
                    {
                        await _db.KeyDeleteAsync(keysToDelete.ToArray());
                        keysToDelete.Clear();
                    }
                }

                // Final batch
                if (keysToDelete.Count > 0)
                {
                    await _db.KeyDeleteAsync(keysToDelete.ToArray());
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in DeleteByPatternAsync : {ErrorMessage}", ex.Message);
            }
        }

        public async Task<bool> UpdateSingleAsync<T>(string key, T updatedValue) where T : class
        {
            try
            {
                var json = System.Text.Json.JsonSerializer.Serialize(updatedValue);
                var result = await _db.ExecuteAsync(CommonConstants.JsonCommandSet, key, "$", json);
                return result.ToString()?.ToLower() == "ok";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in UpdateSingleAsync : {ErrorMessage}", ex.Message);
                return false;
            }
        }

        public async Task<bool> UpdateByJsonPathAsync<T>(string key, string jsonPath, T updatedItem) where T : class
        {
            try
            {
                var json = System.Text.Json.JsonSerializer.Serialize(updatedItem);
                var result = await _db.ExecuteAsync(CommonConstants.JsonCommandSet, key, jsonPath, json);

                return result.ToString()?.ToLower() == "ok";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in UpdateByJsonPathAsync : {ErrorMessage}", ex.Message);
                return false;
            }
        }

        public async Task<bool> IsCacheKeyExistsAsync(string key)
        {
            try
            {
                return await _db.KeyExistsAsync(key);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in IsCacheKeyExists : {ErrorMessage}", ex.Message);
                return false;
            }
        }

        public async Task<bool> IsRedisActiveAsync()
        {
            try
            {
                await _db.PingAsync();
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in IsRedisAvailableAsync : {ErrorMessage}", ex.Message);
                return false;
            }
        }

        public async Task CreateIndexAsync(Schema schema, string indexName, string indexKey)
        {
            try
            {
                await DropIndexAsync(indexName);
                await _db.FT().CreateAsync(indexName, new FTCreateParams().On(IndexDataType.JSON).Prefix(indexKey), schema);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in CreateIndex : {ErrorMessage}", ex.Message);
            }
        }

        public async Task<bool> DropIndexAsync(string indexName)
        {
            try
            {
                await _db.FT().DropIndexAsync(indexName);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in DropIndex : {ErrorMessage}", ex.Message);
                return false;
            }
        }

        public async Task<IEnumerable<T>> GlobalSearchAsync<T>(RedisCacheSearchModel searchModel) where T : class
        {
            try
            {
                if (searchModel == null)
                    throw new ArgumentNullException(nameof(searchModel), "Search model cannot be null.");

                if (string.IsNullOrWhiteSpace(searchModel.IndexName))
                    throw new ArgumentException("IndexName cannot be null or empty.");

                if (searchModel.Query == null)
                    throw new ArgumentException("Query cannot be null.");

                var pagination = searchModel.PaginationQuery ?? new PaginationQuery();
                int offset = (pagination.PageNumber - 1) * pagination.PageSize;

                var query = searchModel.Query
                    .Limit(offset, pagination.PageSize)
                    .SetSortBy(pagination.SortString ?? string.Empty,
                        GetSortOrder(pagination.SortOrder ?? string.Empty))
                    .Dialect(2);

                var searchResult = await _db.FT().SearchAsync(searchModel.IndexName, query);
                var jsonDoc = searchResult.ToJson();

                return jsonDoc.Select(JsonConvert.DeserializeObject<T>).Where(x => x != null).ToList()!;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in GlobalSearchAsync: {ErrorMessage}", ex.Message);
                return Enumerable.Empty<T>();
            }
        }

        private static bool GetSortOrder(string sortOrder)
        {
            return !sortOrder.Equals(CommonConstants.PAGINATION_DESCENDING, StringComparison.OrdinalIgnoreCase);
        }

        public async Task<long> GetTotalRecordCount(RedisCacheSearchModel searchModel)
        {
            try
            {
                if (searchModel == null)
                    throw new ArgumentNullException(nameof(searchModel), "Search model cannot be null.");

                if (string.IsNullOrWhiteSpace(searchModel.IndexName))
                    throw new ArgumentException("IndexName cannot be null or empty.");

                if (searchModel.Query == null)
                    throw new ArgumentException("Query cannot be null.");

                SearchResult searchResult = await _db.FT().SearchAsync(searchModel.IndexName, searchModel.Query);

                return searchResult.TotalResults;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in GetTotalRecordCount : {ErrorMessage}", ex.Message);
                return 0;
            }
        }

        public async Task<bool> AddToJsonListAsync<T>(string key, T newItem)
        {
            try
            {
                var redisValue = System.Text.Json.JsonSerializer.Serialize(newItem);
                // Append to root JSON array (path is $ for root)
                var result = await _db.ExecuteAsync("JSON.ARRAPPEND", key, "$", redisValue);
                return result.Resp2Type == ResultType.Integer && (int)result > 0;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in AddToJsonListAsync : {ErrorMessage}", ex.Message);
                return false;
            }
        }

        public async Task<bool> UpdateJsonListByIdAsync<T>(string key, int id, T updatedItem)
        {
            try
            {
                // Get the array to find index
                var arrayJson = await _db.ExecuteAsync(CommonConstants.JsonCommandGet, key, "$");
                var json = arrayJson.ToString();

                if (string.IsNullOrEmpty(json)) return false;

                var items = System.Text.Json.JsonSerializer.Deserialize<List<T>>(json, _jsonSerializerOptions);

                var index = items?.FindIndex(item =>
                {
                    var prop = typeof(T).GetProperty("id", BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);
                    return (int?)prop?.GetValue(item) == id;
                });

                if (index is null or < 0) return false;

                var updatedJson = System.Text.Json.JsonSerializer.Serialize(updatedItem);
                var path = $"$[{index}]";

                var result = await _db.ExecuteAsync(CommonConstants.JsonCommandSet, key, path, updatedJson);
                return result.ToString()?.ToLower() == "ok";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in UpdateJsonListByIdAsync : {ErrorMessage}", ex.Message);
                return false;
            }
        }

        public async Task<bool> DeleteFromJsonListByIdAsync<T>(string key, int id)
        {
            try
            {
                var arrayJson = await _db.ExecuteAsync(CommonConstants.JsonCommandGet, key, "$");
                var json = arrayJson.ToString();

                if (string.IsNullOrEmpty(json)) return false;

                var items = System.Text.Json.JsonSerializer.Deserialize<List<T>>(json, _jsonSerializerOptions);

                var index = items?.FindIndex(item =>
                {
                    var prop = typeof(T).GetProperty("id", BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);
                    return (int?)prop?.GetValue(item) == id;
                });

                if (index is null or < 0) return false;

                var result = await _db.ExecuteAsync(CommonConstants.JsonCommandDel, key, $"$[{index}]");
                return (int?)result > 0;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RedisCacheEnterpriseService: Error in DeleteFromJsonListByIdAsync : {ErrorMessage}", ex.Message);
                return false;
            }
        }
    }
}
