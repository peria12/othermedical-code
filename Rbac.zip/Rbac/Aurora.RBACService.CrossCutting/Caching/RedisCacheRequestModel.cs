﻿namespace Aurora.RBACService.CrossCutting.Caching
{
    [ExcludeFromCodeCoverage]
    public class RedisCacheRequestModel
    {
        public required string CacheKey { get; set; }
        public required dynamic Record { get; set; }
    }
}
