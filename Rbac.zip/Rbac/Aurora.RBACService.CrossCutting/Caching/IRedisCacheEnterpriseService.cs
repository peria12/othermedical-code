﻿namespace Aurora.RBACService.CrossCutting.Caching
{
    public interface IRedisCacheEnterpriseService
    {
        Task<bool> SetSingleAsync<T>(string key, T value, TimeSpan? expiry = null) where T : class;
        Task<bool> SetListAsync<T>(string key, List<T> values, TimeSpan? expiry = null) where T : class;
        Task SetMultipleKeysAsync<T>(Dictionary<string, T> keyValuePairs, TimeSpan? expiry = null) where T : class;
        Task<T?> GetSingleAsync<T>(string key, string jsonPath = "$") where T : class;
        Task<List<T>?> GetListAsync<T>(string key, string jsonPath = "$") where T : class;
        Task<List<T>?> GetListByPatternAsync<T>(string pattern, string jsonPath = "$") where T : class;
        Task<bool> DeleteSingleAsync(string key);
        Task<long> DeleteKeysAsync(IEnumerable<string> keys);
        Task<bool> DeleteByJsonPathAsync(string key, string jsonPath);
        Task DeleteByPatternAsync(string pattern, int pageSize = 500, int batchSize = 1000, int database = -1);
        Task<bool> UpdateSingleAsync<T>(string key, T updatedValue) where T : class;
        Task<bool> UpdateByJsonPathAsync<T>(string key, string jsonPath, T updatedItem) where T : class;
        Task<bool> IsCacheKeyExistsAsync(string key);
        Task<bool> IsRedisActiveAsync();
        Task CreateIndexAsync(Schema schema, string indexName, string indexKey);
        Task<IEnumerable<T>> GlobalSearchAsync<T>(RedisCacheSearchModel searchModel) where T : class;
        Task<long> GetTotalRecordCount(RedisCacheSearchModel searchModel);
        Task<bool> AddToJsonListAsync<T>(string key, T newItem);
        Task<bool> UpdateJsonListByIdAsync<T>(string key, int id, T updatedItem);
        Task<bool> DeleteFromJsonListByIdAsync<T>(string key, int id);
    }
}