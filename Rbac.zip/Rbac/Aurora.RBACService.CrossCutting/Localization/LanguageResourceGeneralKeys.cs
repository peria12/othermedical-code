﻿namespace Aurora.RBACService.CrossCutting.Localization
{
    [ExcludeFromCodeCoverage]
    public static class LanguageResourceGeneralKeys
    {
        public const string BAD_REQUEST = "BAD_REQUEST";
        public const string CONCURRENCY_ERROR = "CONCURRENCY_ERROR";
        public const string DUPLICATE_RECORD = "DUPLICATE_RECORD";
        public const string ERROR_ACCESS_DENIED = "ERROR_ACCESS_DENIED";
        public const string ERROR_HTTP_REQUEST_EXCEPTION = "ERROR_HTTP_REQUEST_EXCEPTION";
        public const string ERROR_HEADER_MISSING_LANGUAGECODE = "ERROR_HEADER_MISSING_LANGUAGECODE";
        public const string ERROR_HEADER_MISSING = "ERROR_HEADER_MISSING";
        public const string ERROR_INTERNAL_SERVER_ERROR = "ERROR_INTERNAL_SERVER_ERROR";
        public const string ERROR_TIMEOUT_EXCEPTION = "ERROR_TIMEOUT_EXCEPTION";
        public const string ERROR_UNAUTHORIZED = "STATUS_UNAUTHORIZED_ACCESS";
        public const string INVALID_REQUEST_PARAMETER = "INVALID_REQUEST_PARAMETER";
        public const string STATUS_DATA_FOUND = "STATUS_DATA_FOUND";
        public const string STATUS_DATA_ADDED = "RECORD_ADDED_SUCCESSFULLY";
        public const string STATUS_DATA_UPDATED = "RECORD_UPDATED_SUCCESSFULLY";
        public const string STATUS_DATA_DELETED = "RECORD_DELETED_SUCCESSFULLY";
        public const string STATUS_INVALID_FACILITY_CODE = "STATUS_INVALID_FACILITY_CODE";
        public const string STATUS_INVALID_REGION_CODE = "STATUS_INVALID_REGION_CODE";
        public const string STATUS_INVALID_SESSION_ID = "STATUS_INVALID_SESSION_ID";
        public const string STATUS_INVALID_LANGUAGE_CODE = "STATUS_INVALID_LANGUAGE_CODE";
        public const string STATUS_NODATA = "STATUS_NODATA";
        public const string STATUS_INTERNAL_SERVER_ERROR = "STATUS_INTERNAL_SERVER_ERROR";
        public const string STATUS_INVALID_IDEMPOTENCYKEY = "STATUS_INVALID_IDEMPOTENCYKEY";
        public const string STATUS_REDIS_UNAVAILABLE = "STATUS_REDIS_UNAVAILABLE";
        public const string STATUS_DATA_NOT_CLEARED = "RECORD_NOT_CLEARED";
        public const string STATUS_DATA_CLEARED = "STATUS_DATA_CLEARED";
        public const string STATUS_DATA_SEEDED = "STATUS_DATA_SEEDED";
        public const string STATUS_DATA_NOT_SEEDED = "STATUS_DATA_NOT_SEEDED";


        static LanguageResourceGeneralKeys()
        {
            LanguageTranslator.Instance.AddDefaultResource(BAD_REQUEST, "Bad request");
            LanguageTranslator.Instance.AddDefaultResource(CONCURRENCY_ERROR, "Record updated by another user. Changes Discarded. Please try again after auto-refresh");
            LanguageTranslator.Instance.AddDefaultResource(DUPLICATE_RECORD, "Duplicate record cannot be added");
            LanguageTranslator.Instance.AddDefaultResource(ERROR_ACCESS_DENIED, "Access denied");
            LanguageTranslator.Instance.AddDefaultResource(ERROR_HTTP_REQUEST_EXCEPTION, "Request error");
            LanguageTranslator.Instance.AddDefaultResource(ERROR_HEADER_MISSING_LANGUAGECODE, "{\"LanguageCode: 400 LanguageCode header is missing\"}");
            LanguageTranslator.Instance.AddDefaultResource(ERROR_HEADER_MISSING, "{0} header is missing");
            LanguageTranslator.Instance.AddDefaultResource(ERROR_INTERNAL_SERVER_ERROR, "Internal server error");
            LanguageTranslator.Instance.AddDefaultResource(ERROR_TIMEOUT_EXCEPTION, "Timeout error");
            LanguageTranslator.Instance.AddDefaultResource(ERROR_UNAUTHORIZED, "Unauthorized request");
            LanguageTranslator.Instance.AddDefaultResource(INVALID_REQUEST_PARAMETER, "Invalid Request Parameter");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_DATA_FOUND, "Record found");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_DATA_ADDED, "Record added successfully");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_DATA_UPDATED, "Record updated successfully");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_DATA_DELETED, "Record deleted successfully");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_INVALID_FACILITY_CODE, "Invalid facility code");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_INVALID_REGION_CODE, "Invalid region code");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_INVALID_SESSION_ID, "Invalid session id");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_INVALID_LANGUAGE_CODE, "Invalid language code");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_NODATA, "Record not found");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_INTERNAL_SERVER_ERROR, "Internal server error");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_INVALID_IDEMPOTENCYKEY, "IdempotencyKey header is missing");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_REDIS_UNAVAILABLE, "Redis cache is unavailable");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_DATA_CLEARED, "Record cleared successfully");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_DATA_SEEDED, "Record seeded successfully");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_DATA_NOT_CLEARED, "Record not cleared successfully");
            LanguageTranslator.Instance.AddDefaultResource(STATUS_DATA_NOT_SEEDED, "Record not seeded successfully");

        }
    }
}
