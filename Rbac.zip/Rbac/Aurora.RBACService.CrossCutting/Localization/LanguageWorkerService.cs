﻿namespace Aurora.RBACService.CrossCutting.Localization
{
    public class LanguageWorkerService : BackgroundService
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpClientService _httpClientService;
        private readonly ILogger<LanguageWorkerService> _logger;
        private readonly string _appGroupCode;

        public LanguageWorkerService(
            IConfiguration configuration,
            IHttpClientService httpClientService,
            ILogger<LanguageWorkerService> logger)
        {
            _configuration = configuration;
            _httpClientService = httpClientService;
            _logger = logger;


            _appGroupCode = configuration.GetValue<string>(CommonConstants.MSGroupCode) ?? string.Empty;
            LanguageLocalCache.Instance.AbsoluteExpiryMinutes = GetAbsoluteExpiryMinutesFromConfiguration();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                LanguageLocalCache.Instance.ClearCache();
                await StartAsync();
                await Task.Delay(TimeSpan.FromMinutes(LanguageLocalCache.Instance.AbsoluteExpiryMinutes), stoppingToken);
            }
        }

        private async Task<bool> StartAsync()
        {
            try
            {
                List<LanguageCodeDto> languageCodes = await GetActiveLanguageCodes();

                foreach (LanguageCodeDto language in languageCodes)
                {
                    string langCode = language.LanguageCode!;

                    List<LanguageResourceDto>? resources = await FindCDNResources(_appGroupCode, langCode);

                    if (resources == null || resources.Count == 0)
                    {
                        resources = await GetLanguageGroupResources(langCode, _appGroupCode);
                    }

                    if (resources != null && resources.Count > 0)
                    {
                        LanguageLocalCache.Instance.SetCache(langCode, resources);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred: {Message}", ex.Message);
            }
            return true;
        }

        /// <summary>
        /// Implementation for finding CDN resources
        /// </summary>
        /// <param name="groupCode"></param>
        /// <param name="languageCode"></param>
        /// <returns></returns>
        private async Task<List<LanguageResourceDto>?> FindCDNResources(string groupCode, string languageCode)
        {
            try
            {
                string? cdnFolder = _configuration.GetValue<string>(CommonConstants.CDNJsonFolderName);
                string fileName = $"{cdnFolder}/{CommonConstants.CDNFilePrefix}_{groupCode}_{languageCode}{CommonConstants.CDNFileExtension}".ToLower();
                var cdnUrl = $"{_configuration.GetValue<string>(CommonConstants.CDNUrl)}/{_configuration.GetValue<string>(CommonConstants.CDNContainerName)}/{fileName}?{_configuration.GetValue<string>(CommonConstants.CDNSASToken)}";

                var blobContents = await _httpClientService.GetStringAsync(cdnUrl);

                if (!string.IsNullOrWhiteSpace(blobContents))
                {
                    List<LanguageResourceDto>? data = JsonConvert.DeserializeObject<List<LanguageResourceDto>>(blobContents);
                    return data;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "LanguageWorkerService: CDN connection error.");
            }
            return null;
        }

        /// <summary>
        /// Implementation for getting language group resources
        /// </summary>
        /// <param name="languageCode"></param>
        /// <param name="groupCode"></param>
        /// <returns></returns>
        private async Task<List<LanguageResourceDto>> GetLanguageGroupResources(string languageCode, string groupCode)
        {
            try
            {
                string apiScope = $"{_configuration[CommonConstants.LanguageServiceAPIClientId]}/.default";
                string languageResourceApiUrl = $"{_configuration.GetValue<string>(CommonConstants.LanguageServiceAPIURL)}/{CommonConstants.GetLanguageResources}?groupCode={groupCode}&languageCode={languageCode}";

                HttpResponseMessage apiResponse = await _httpClientService.GetAsyncCall(languageResourceApiUrl, apiScope);

                if (apiResponse.IsSuccessStatusCode)
                {
                    string responseContent = await apiResponse.Content.ReadAsStringAsync();
                    GenericResponseList<LanguageResourceDto>? dataResponse = JsonConvert.DeserializeObject<GenericResponseList<LanguageResourceDto>>(responseContent);

                    if (dataResponse?.StatusCode == ResponseStatusCode.STATUS_SUCCESS && dataResponse.Result != null)
                    {
                        return dataResponse.Result.ToList();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "LanguageWorkerService: GetLanguageGroupResources api call failed.");
            }
            return [];
        }

        /// <summary>
        /// Implementation for getting active language codes
        /// </summary>
        /// <returns></returns>
        private async Task<List<LanguageCodeDto>> GetActiveLanguageCodes()
        {
            try
            {
                string apiScope = $"{_configuration[CommonConstants.LanguageServiceAPIClientId]}/.default";
                string apiUrl = $"{_configuration.GetValue<string>(CommonConstants.LanguageServiceAPIURL)}/{CommonConstants.GetActiveLanguageCodes}";

                HttpResponseMessage apiResponse = await _httpClientService.GetAsyncCall(apiUrl, apiScope);

                if (apiResponse.IsSuccessStatusCode)
                {
                    string responseContent = await apiResponse.Content.ReadAsStringAsync();
                    GenericResponseList<LanguageCodeDto>? dataResponse = JsonConvert.DeserializeObject<GenericResponseList<LanguageCodeDto>>(responseContent);

                    if (dataResponse?.StatusCode == ResponseStatusCode.STATUS_SUCCESS && dataResponse.Result != null)
                    {
                        return dataResponse.Result.ToList();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"LanguageWorkerService: GetActiveLanguageCodes api call failed.");
            }
            return [];
        }

        private int GetAbsoluteExpiryMinutesFromConfiguration()
        {
            string? interval = _configuration.GetValue<string>(CommonConstants.LanguageAbsoluteExpiryMinutes);

            if (int.TryParse(interval, out int expiryInterval) && expiryInterval > 0)
            {
                return expiryInterval;
            }

            return 1440; // default value
        }
    }
}

