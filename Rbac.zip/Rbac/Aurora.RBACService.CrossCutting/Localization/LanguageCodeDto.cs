﻿namespace Aurora.RBACService.CrossCutting.Localization
{
    public class LanguageCodeDto
    {
        public string? LanguageCode { get; set; }
    }
}