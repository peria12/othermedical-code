﻿namespace Aurora.RBACService.CrossCutting.Localization
{
    public class LanguageResourceDto
    {
        public string? Key { get; set; }
        public string? Value { get; set; }
    }
}