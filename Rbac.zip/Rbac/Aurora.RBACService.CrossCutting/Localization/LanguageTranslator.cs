﻿namespace Aurora.RBACService.CrossCutting.Localization
{
    public class LanguageTranslator
    {
        public static LanguageTranslator Instance { get; set; }
        private readonly ConcurrentDictionary<string, string> defaultLanguageResources = new();

        static LanguageTranslator()
        {
            Instance = new LanguageTranslator();
        }

        public void AddDefaultResource(string resourceKey, string defaultValue)
        {
            defaultLanguageResources.TryAdd(resourceKey, defaultValue);
        }

        public string? Translate(string langCode, string resourceKey)
        {
            LanguageLocalCache.Instance.TryGetCache(langCode, out List<LanguageResourceDto>? resources);

            if (resources != null && resources.Count > 0)
            {
                LanguageResourceDto? resource = resources.Find(f => f.Key == resourceKey);
                if (resource != null)
                {
                    return resource.Value;
                }
            }

            defaultLanguageResources.TryGetValue(resourceKey, out string? resourceValue);
            return resourceValue;
        }

        public string? Translate(string langCode, string resourceKey, string defaultValue)
        {
            return Translate(langCode, resourceKey) ?? defaultValue;
        }

        public string? TranslateDynamic(string langCode, string resourceKey, params object[] dynamicValues)
        {
            string? resourceValue = Translate(langCode, resourceKey);
            if (!string.IsNullOrWhiteSpace(resourceValue))
            {
                resourceValue = string.Format(resourceValue, dynamicValues);
            }
            return resourceValue;
        }
    }
}