﻿namespace Aurora.RBACService.CrossCutting.Localization
{
    public class LanguageLocalCache
    {
        public static LanguageLocalCache Instance { get; set; } = new LanguageLocalCache();
        public int AbsoluteExpiryMinutes { get; set; }
        private readonly ConcurrentDictionary<string, DateTime> cacheTimeStamps = new();
        private readonly ConcurrentDictionary<string, List<LanguageResourceDto>> languageCache = new();

        public void SetCache(string languageCode, List<LanguageResourceDto> value)
        {
            languageCode = languageCode.ToUpper();
            RemoveCache(languageCode);
            cacheTimeStamps[languageCode] = DateTime.UtcNow;
            languageCache[languageCode] = value;
        }

        public bool TryGetCache(string languageCode, out List<LanguageResourceDto>? value)
        {
            return languageCache.TryGetValue(languageCode, out value);
        }

        public void ClearCache()
        {
            DateTime expiryTime = DateTime.UtcNow.AddMinutes(-AbsoluteExpiryMinutes);
            IEnumerable<string> keysToRemove = cacheTimeStamps
                .Where(x => x.Value < expiryTime)
                .Select(x => x.Key);

            foreach (string key in keysToRemove)
            {
                RemoveCache(key);
            }
        }

        public void RemoveCache(string key)
        {
            languageCache.TryRemove(key, out _);
            cacheTimeStamps.TryRemove(key, out _);
        }
    }
}