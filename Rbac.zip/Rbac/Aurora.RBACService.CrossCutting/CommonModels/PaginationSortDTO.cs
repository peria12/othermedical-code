﻿namespace Aurora.RBACService.CrossCutting.CommonModels
{
    public class PaginationSortDto
    {
        public int PageNumber { get; set; } = 1; // Default to the first page
        public int PageSize { get; set; } = 10;  // Default to 10 items per page
        public string SortBy { get; set; } = "Id"; // Default sorting field
        public bool SortDescending { get; set; } = false;
        public int TotalCount { get; set; }
        public int CurrentPage { get; set; }     // Current page number
    }
}
