﻿namespace Aurora.RBACService.CrossCutting.CommonModels
{
    public static class ResponseMessage
    {
        public const string STATUS_INVALID_ID_PARAM_REQUEST = "The field must be greather than 0 ";
        public const string STATUS_INVALID_REQUEST = "Invalid Request Parameter";
        public const string STATUS_SUCCESS = "Success";
        public const string STATUS_ALREADY_REGISTERED = "Device Already Registered";
        public const string STATUS_ALREADY_ACTIVATED = "Device Already Activated";
        public const string STATUS_INPROGRESS = "In Progress";
        public const string STATUS_NODEVICE_FOUND = "No Device Found";
        public const string STATUS_INVALIED_TOKEN = "Invalid Token";
        public const string STATUS_FAILED = "Failed";
        public const string STATUS_REGISTRATION_FAILED = "Registration Failed";
        public const string STATUS_SERVER_ERROR = "Internal Server Error, Please Try Later";
        public const string STATUS_MESSAGE_SENDING_ERROR = "Message Sending Error";
        public const string STATUS_HOSPITALS_NOT_FOUND = "No Hospital Found";
        public const string STATUS_NODATA = "Record Not Found";
        public const string STATUS_DATA_FOUND = "Record Found";
        public const string STATUS_DATA_ADDED = "Record Added Successfully";
        public const string STATUS_DATA_UPDATED = "Record Updated Successfully";
        public const string STATUS_DATA_DELETED = "Record Deleted Successfully";
        public const string STATUS_DATA_ADD_FAIL = "Record Not Added";
        public const string STATUS_RECORDS_LOADED = "Records Loaded Successfully.";
        public const string STATUS_PROFILE_NOT_FOUND = "Profile Not Found";
        public const string STATUS_PROFILE_UPDATED = "Record Updated Successfully";
        public const string STATUS_PROFILE_UPDATE_FAIL = "Profile Update Failed";
        public const string STATUS_DATA_UPDATE_FAIL = "Record Not Updated";
        public const string STATUS_DATA_DELETE_FAIL = "Record Not Deleted";
        public const string STATUS_CODE_EXIST = "Code already exist";
        public const string STATUS_DESCRIPTION_EXIST = "Description already exist";
        public const string STATUS_SMRPCODE_EXIST = "SMRP Code already exist";
        public const string STATUS_REDISCACHE_UPDATED = "Redis Cache Updated Successfully";
        public const string STATUS_UNAUTHORIZED_USER = "User doesn't have access or permission";
        public const string STATUS_UNAUTHORIZED_ACCESS = "Unauthorized Access";
        public const string STATUS_PROVIDE_VALID_TOKEN = "Please provide valid token";
        public const string STATUS_INVALID_TOKEN = "Invalid Token";
        public const string STATUS_REGIONCODE_REQUIRED = "Region code is required";
        public const string STATUS_ISOBSOLETE_TRUE = "Record not saved as IsObsolete is true";
        public const string STATUS_REFERENCE_DATA = "Error: ";
        public const string STATUS_CODE_NOT_EXIST = "Code doesn't exist";
        public const string STATUS_INVALID_ROOM_ID = "Invalid Room Id";
        public const string STATUS_SMRPCODE_REQUIRED = "SMRP Code is required";
        public const string STATUS_SMRPDESCRIPTION_REQUIRED = "SMRP Description is required";
        public const string STATUS_SMRPFACILITYCODE_REQUIRED = "SMRP Facility Code is required";
        public const string STATUS_COMPANYNAMEVN_REQUIRED = "Company Name(VN) is required";
        public const string STATUS_DEPARTMENTOFHEALTH_REQUIRED = "Department Of Health is required";
        public const string STATUS_DEPARTMENTOFHEALTHVN_REQUIRED = "Department Of Health(VN) is required";
        public const string STATUS_ISDELETED_TRUE = "Record not saved as IsDeleted is true";
        public const string STATUS_DESCRIPTIONVN_REQUIRED = "DescriptionVN is required";
        public const string STATUS_INVALID_REGIONCODE = "Invalid Region Code";
        public const string STATUS_BusinessRegNo_Required = "Business Reg No. is required";
        public const string STATUS_PostCode_Required = "Post Code is required";
        public const string STATUS_TaxGroupCode_Required = "Tax Group Code is required";
        public const string STATUS_CODE_Field_Required = "Code field is required";
        public const string STATUS_DUPLICATE_RECORD = "Duplicate record cannot be added";
        public const string STATUS_REQUIRED_VIETNAMES_REPORT = "Vietnamese Report is required";
        public const string STATUS_REQUIRED_VIETNAMES_REPORTIMPRESSIONCONCLUSION = "Vietnamese Report Impression Conclusion is required";
        public const string STATUS_INVALID_FACILITY_CODE = "Invalid Facility code";
        public const string STATUS_TEST_FORMAT_NOT_FOUND = "Test format not found";
        public const string LAB_DEPARTMENT_DOESNOT_EXIST = "Department Id is required";
        public const string INVALID_LAB_DEPARTMENT = "Invalid Department Id";
        public const string MAX_SCORE_REQUIRED = "MaxScore is required";
        public const string STATUS_AUTHORIZATION_TOKEN_INVALID = "Authorization token is invalid.";
        public const string STATUS_APPOINTMENT_ADDED = "Appointment Added Successfully";
        public const string USER_IS_NOT_EXIST = "No user found! We could not find the mobile number you selected in our system.Click Register to create an account with Columbia Asia or Go Back to try again.";
        public const string USER_IS_EXIST = "We got you! Since you have already registered with Columbia Asia, click Continue to set up your account.";
        public const string INCORRECT_PASSWORD = "Incorrect Password";
        public const string LOGIN_SUCCESS = "Login Successful!";
        public const string INVALID_CREDENTIAL = "Oops! We couldn't find an account associated with the credentials provided.Please ensure you have entered the correct ID/Password and try again.";
        public const string PATIENT_USER_ISNOTEXIST = "Existing Patient ID not found.";
        public const string DEPENDENT_ALREADY_EXIST = "IC Number already exists.";
        public const string DEPENDENT_DATA_ADDED = "Dependent Added Successfully";
        public const string USER_LOGGED_OUT = "User Logged Out Successfully.";
        public const string USER_NOT_ACTIVE = "User Is Not Active.";
        public const string STATUS_CONCURRENCY_ERROR = "The record has been updated by another user '{0}' just now on {1}. Please refresh the screen and can try again if you want update the record";

        public static string GetConcurrencyErrorMessage(string updatedBy, DateTime? updatedDate)
        {
            return string.Format(STATUS_CONCURRENCY_ERROR, updatedBy, updatedDate);
        }

        public const string TEST_METHOD_VALIDATION = "Test method should not be modified";
        public const string RENAME_INVALID_TEMPLATE = "Cannot Rename Template Created by Others ";
        public const string RENAME_INVALID_FOLDER = "Cannot Rename Folder Created by Others ";
        public const string STATUS_RENAME_UPDATED = "Record Renamed Successfully";
        public const string FLUIDBAL_CALCULATION_FROM_TO_RANGE = "Shift From Time should not be greater than Shift To Time";
        public const string OTP_SENT = "OTP Sent Successfully on ";
        public const string OTP_NOT_SENT = "OTP Not Sent, Please try again.";
        public const string OTP_NOT_FOUND = "OTP Not found.";
        public const string ALREADY_EXISTS = "A record with similar data already exists.";
        public const string INVALID_DATA = "Invalid data provided.";
    }

    public static class ResponseStatus
    {
        public const string STATUS_SUCCESS = "200";
        public const string STATUS_SUCCESS_Create = "201";
        public const string STATUS_BADREQUEST = "400";
        public const string STATUS_UNAUTHORIZED = "401";
        public const string STATUS_FORBIDDEN = "403";
        public const string STATUS_NOTFOUND = "404";
        public const string STATUS_REQUESTTIMEOUT = "408";
        public const string STATUS_CONFLICT = "409";
        public const string STATUS_INTERNALSERVERERROR = "500", STATUS_Problem = "500";
        public const string STATUS_SERVICEUNAVAILABLE = "503";
    }

    [ExcludeFromCodeCoverage]
    public static class ValidationMessage
    {
        public const string DUPLICATE_RECORD = "Duplicate record cannot be added";
        public const string RECORD_ADDED_SUCESSFULLY = "Record Added Successfully";
        public const string RECORD_UPDATED_SUCESSFULLY = "Record Updated Successfully";
        public const string RECORD_DELETED_SUCESSFULLY = "Record Deleted Successfully";
        public const string RECORD_NOT_FOUND = "Record not found";
        public const string RECORD_ALREADY_EXIST = "Record already exist";
        public const string DESCRIPTION_MANDATORY = "Description should not be empty";
        public const string DEFAULT_MULTILINGUAL_LANGUAGE_CODE = "en";
        public const string CODE_MANDATORY = "Code should not be empty";
        public const string NO_DATA_FOUND = "No Data Found";
        public const string DATA_FOUND = "Data Found";
        public const string UPDATE = "Update";
        public const string NOTUPDATE = "Not Updated";
        public const string OBSOLETE = "obsolete";
        public const string ACTIVE = "active";
        public const string TRUE = "true";
        public const string FALSE = "false";
        public const string DESCRIPTION = "description";
        public const string DISPLAY = "display";
        public const string COLORCODE_MANDATORY = "ColorCode should not be empty";
        public const string ISDELETED = "IsDeleted";
        public const string PAGE_NUMBER_CANNOT_BE_NEGATIVE = "Page Number Cannot be negative";
        public const string PAGE_SIZE_CANNOT_BE_NEGATIVE = "Page Size Cannot be negative";
        public const string PAGINATION_ASCENDING = "asc";
        public const string PAGINATION_DESCENDING = "desc";
        public const string HIGH_SCORE_VALIDATION = "Range should be (0-12)";
        public const string MEDIUM_SCORE_VALIDATION = "Range should be (13-14)";
        public const string LOW_SCORE_VALIDATION = "Range should be (15-16)";
        public const string MAX_SCORE = "MAX";
        public const string MIN_SCORE = "MIN";
        public const string MEDIUM_RANGE = "Medium";
        public const string LOW_RANGE = "Low";
        public const string HIGH_RANGE = "High";
        public const string DEFAULT_SORT = "id";
        public const string NOT_FOUND = "Not Found";
        public const string INVALID_PARAMS = "Invalid params";
        public const string RECORD_CREATION_FAILED = "Record Creation Failed";
        public const string RECORD_DELETION_FAILED = "Record Deletion Failed";
        public const string Obsolete = "Obsolete";
        public const string Active = "Active";
        public const string MINSCORE_CANNOT_GREATER_MAXSCORE = "Min Cannot be greater than Max";
        public const string MAX_SCORE_CANNOT_SMALL_MIN_SCORE = "Max should be greater than Min";
        public const string MIN_SCORE_LESS_THAN_MAX = "Min should be less than Max";
        public const string MAX_CANNOT_BE_SMALLER_THAN_MIN = "Max should be greater than Min";
        public const string NO_OF_BABIES_MISMATCH = "Invalid No of Babies";
        public const string INVALIDE_CHARGEMASTER_CODE = "Invalid ChargeMasterID";
        public const string INVALIDE_OTHERSERVICE_ID = "Invalid ServiceID";
        public const string INVALIDE_MEDICAL_TEMPLATE_ID = "Invalid Medical TemplateID";
        public const string IGNORE_MATCH_PATTERN = "NOT_HANDLED";
        public const string FROM_AGE_SHOULD_LESS_TO_AGE = "Age From should be less than Age To";
        public const string RANGE_MIN_SHOULD_LESS_RANGE_MAX = "Range Min should be less than Range Max";
        public const string CRITICAL_MIN_SHOULD_LESS_CRITICAL_MAX = "Critical Min should be less than Critical Max";
        public const string CRITICAL_MIN_SHOULD_LESS_RANGE_MIN = "Critical Min Range should be less than Range Min";
        public const string CRITICAL_MAX_SHOULD_GREATER_RANGE_MAX = "Critical Max Range should be greater than Range Max";
        public const string Combination_Exists = "Selected combinations already exists";
        public const string DURATION_NAME = "Duration";
        public const string MIMS_TYPE = "MimsType";
        public const string MIMS_CODE_GENERICITEM = "MIMSCODE-GENERICITEM";
        public const string MIMS_CODE_GGPI = "MIMSCODE-GGPI";
        public const string MIMS_CODE_PRODUCT = "MIMSCODE-PRODUCT";
        public const int DURATION_MIN_VALUE = 0;
        public const int DURATION_MAX_VALUE = 31;
        public const string ageGreaterThan = "Age From should be Lesser than Age To";
        public const string ageSmallerThan = "Age To should be greater than Age From";
        public const string ewsMinGreaterThanMax = "Min should be lesser than Max";
        public const string ewsMaxSmallerThanMin = "Max should be greater than Min";
        public const string INVALID_MYS_REGION_CODE = "Invalid or missing region code. Only 'MYS' is allowed for this service.";
        public const string INVALID_REGION_CODE = "Invalid region code. 'MYS' is not allowed for this service.";
        public const string INVALID_DEPENDENT_DATA = "Invalid dependent data.";
        public const string INVALID_SELECTED_PLATFORM = "Invalid selectedPlatforms.";

        public static string StringValidation(string? userValue)
        {
            return !string.IsNullOrWhiteSpace(userValue) ? userValue.Trim() : "";
        }

        public static string StringValidation(int userValue)
        {
            return userValue.ToString().Trim();
        }

        public static string StringIgnoreCase(string? userValue)
        {
            return StringValidation(userValue).ToLower();
        }

        public static T TrimStringProperties<T>(this object obj)
        {
            IEnumerable<PropertyInfo> stringProperties = obj.GetType().GetProperties().Where(p => p.PropertyType == typeof(string));
            foreach (PropertyInfo propertyInfo in stringProperties)
            {
                if (propertyInfo.GetValue(obj, null) is string value)
                    propertyInfo.SetValue(obj, value.Trim(), null);

            }

            return (T)obj;
        }


    }

    public static class LanguageCode
    {
        public const string MALAYSIA_LANG_CODE = "EN";
        public const string VIETNAM_LANG_CODE = "VT";
        public const string INDONESIA_LANG_CODE = "ID";
    }

    public static class RegionCode
    {
        public const string MALAYSIA_REGION_CODE = "MYS";
        public const string VIETNAM_REGION_CODE = "VNM";
        public const string INDONESIA_REGION_CODE = "IDN";

        public static ImmutableArray<string> AllowedRegionCodes => ImmutableArray.Create(
            MALAYSIA_REGION_CODE,
            VIETNAM_REGION_CODE,
            INDONESIA_REGION_CODE
        );
    }

    public static class Modules
    {
        public const string LABORATORY = "Laboratory";
        public const string REHABILITATION = "Other Services";
        public const string IMAGING = "Radiology";
    }

    public static class TestFormat
    {
        public const string PANELTEST = "Test Definition";
        public const string PROFILETEST = "Profile Test Definition";
        public const string PACKAGETEST = "Package Test Definition";
    }

    public static class HardcodeValueScreen
    {
        public const string StockMaster = "StockMaster";
        public const string TestDefinition = "TestDefinition";
    }

    public static class TestDefinitionConfig
    {
        public const string AgeUnit = "AgeUnit";
        public const string ParameterFormat = "ParameterFormat";
        public const string TestCarrier = "TestCarrier";
        public const string TestPerformed = "TestPerformed";
    }

    public static class TestCarrier
    {
        public const string DEVICE = "DEVICE";
        public const string MANUAL = "MANUAL";
    }

    public static class TestPerformed
    {
        public const string OUTSOURCED = "OUTSOURCED";
        public const string INHOUSE = "INHOUSE";
    }

    public static class ParameterFormat
    {
        public const string TEXT = "TEXT";
        public const string FREETEXT = "FREETEXT";
        public const string NUMERIC = "NUMERIC";
        public const string TABULAR = "TABULAR";
    }

    public enum DurationType
    {
        Days = 0,
        Weeks = 1,
        Months = 2
    }
}
