﻿namespace Aurora.RBACService.CrossCutting
{
    public interface ITelemetryClientWrapper
    {
        void TrackException(Exception exception, IDictionary<string, string> properties);
    }
}
