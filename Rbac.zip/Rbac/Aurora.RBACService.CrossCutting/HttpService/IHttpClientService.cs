﻿namespace Aurora.RBACService.CrossCutting.HttpService
{
    public interface IHttpClientService
    {
        Task<HttpResponseMessage> PostAsyncCall(string url, dynamic data, string scope, string region = "");
        Task<HttpResponseMessage> GetAsyncCall(string url, string scope);
        Task<HttpResponseMessage> PutAsyncCall(string url, dynamic data, string scope);
        Task<HttpResponseMessage> Aurora_PostAsyncCall(string url, dynamic data);
        Task<HttpResponseMessage> PostAuditAsyncCall(string url, dynamic data, string scope);
        Task<HttpResponseMessage> GetAuditAsyncCall(string url, string scope, string correlationId);
        Task<HttpResponseMessage> DeleteAsyncCall(string url, string scope);
        Task<string> GetStringAsync(string url);
    }
}
