﻿namespace Aurora.RBACService.CrossCutting.HttpService
{
    public class HttpClientService : IHttpClientService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string? regionCode;
        private readonly string? facilityCode;
        private readonly string? languageCode;
        private readonly string? sessionId;
        private string? correlationId;
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _httpClientFactory;

        public HttpClientService(IHttpContextAccessor accessor,
            IConfiguration configuration,
            IHttpClientFactory httpClientFactory
            )
        {
            _httpContextAccessor = accessor;
            regionCode = _httpContextAccessor.HttpContext.Request.Headers
                .TryGetValue(CommonConstants.HeaderRegionCode, out StringValues headerRegionCode)
                ? headerRegionCode : "";
            facilityCode = _httpContextAccessor.HttpContext.Request.Headers
               .TryGetValue(CommonConstants.HeaderFacilityCode, out StringValues headerFacilityCode)
               ? headerFacilityCode : "";
            sessionId = _httpContextAccessor.HttpContext.Request.Headers
            .TryGetValue(CommonConstants.HeaderSessionId, out StringValues headerSessionId)
            ? headerSessionId : "";
            languageCode = _httpContextAccessor.HttpContext.Request.Headers
                .TryGetValue(CommonConstants.HeaderLanguageCode, out StringValues headerLanguageCode)
                ? headerLanguageCode : "";
            correlationId = _httpContextAccessor.HttpContext.Request.Headers
               .TryGetValue(CommonConstants.HeaderCorrelationId, out StringValues headerCorrelationId)
               ? headerCorrelationId : "";
            _configuration = configuration;
            _httpClientFactory = httpClientFactory;
        }
        public async Task<HttpResponseMessage> PostAsyncCall(string url, dynamic data, string scope, string region = "")
        {
            string json = JsonConvert.SerializeObject(data, Formatting.Indented);
            using var content = new StringContent(json, Encoding.UTF8, CommonConstants.ApplicationTypeJson);
            region = string.IsNullOrEmpty(region) ? regionCode! : region;

            try
            {
                Uri uriPost = new(url);
                string BearerTokenPost = string.Empty;
                HttpClient clientPost = _httpClientFactory.CreateClient(Source.Aurora.ToString());
                clientPost.Timeout = TimeSpan.FromSeconds(_configuration.GetValue<int>(AppConstants.HttpClientTimeout));
                string? preferred_username_post = _httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == AppConstants.Preferred_Username)?.Value;

                BearerTokenPost = !string.IsNullOrEmpty(preferred_username_post)
                    ? await GetAccessTokenByOnBehalfOfUser(scope)
                    : await GetAccessTokenByClientCredentials(scope);

                clientPost.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(CommonConstants.Bearer, BearerTokenPost);
                clientPost.DefaultRequestHeaders.Add(CommonConstants.HeaderRegionCode, region);
                clientPost.DefaultRequestHeaders.Add(CommonConstants.HeaderFacilityCode, facilityCode);
                clientPost.DefaultRequestHeaders.Add(CommonConstants.HeaderSessionId, sessionId);
                clientPost.DefaultRequestHeaders.Add(CommonConstants.HeaderLanguageCode, languageCode);
                clientPost.DefaultRequestHeaders.Add(CommonConstants.HeaderTimeZoneOffSet, CommonConstants.DefaultUtcOffset);
                clientPost.DefaultRequestHeaders.Add(CommonConstants.HeaderCorrelationId, correlationId);
                HttpResponseMessage response = await clientPost.PostAsync(uriPost, content);
                string responseBody = await response.Content.ReadAsStringAsync();
                return new HttpResponseMessage()
                {
                    Content = new StringContent(responseBody),
                    StatusCode = response.StatusCode
                };
            }
            catch (HttpRequestException ex)
            {
                if (!ex.Data.Contains(CommonConstants.HttpServiceErrorKey))
                {
                    ex.Data.Add(CommonConstants.HttpServiceErrorKey, "Error in PostAsyncCall");
                }
                throw;
            }
        }

        public async Task<HttpResponseMessage> PutAsyncCall(string url, dynamic data, string scope)
        {
            string json = JsonConvert.SerializeObject(data, Formatting.Indented);
            using StringContent stringContent = new(json, Encoding.UTF8, "application/json");

            try
            {
                Uri uri = new(url);
                string BearerToken = string.Empty;
                HttpClient client = _httpClientFactory.CreateClient(Source.Aurora.ToString());
                client.Timeout = TimeSpan.FromSeconds(_configuration.GetValue<int>(AppConstants.HttpClientTimeout));
                string? preferred_username = _httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == AppConstants.Preferred_Username)?.Value;

                BearerToken = !string.IsNullOrEmpty(preferred_username)
                    ? await GetAccessTokenByOnBehalfOfUser(scope)
                    : await GetAccessTokenByClientCredentials(scope);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(CommonConstants.Bearer, BearerToken);
                client.DefaultRequestHeaders.Add(CommonConstants.HeaderRegionCode, regionCode);
                client.DefaultRequestHeaders.Add(CommonConstants.HeaderFacilityCode, facilityCode);
                client.DefaultRequestHeaders.Add(CommonConstants.HeaderLanguageCode, languageCode);
                client.DefaultRequestHeaders.Add(CommonConstants.HeaderCorrelationId, correlationId);
                HttpResponseMessage response = await client.PutAsync(uri, stringContent);
                string responseBody = await response.Content.ReadAsStringAsync();
                return new HttpResponseMessage()
                {
                    Content = new StringContent(responseBody),
                    StatusCode = response.StatusCode
                };
            }
            catch (HttpRequestException ex)
            {
                if (!ex.Data.Contains(CommonConstants.HttpServiceErrorKey))
                {
                    ex.Data.Add(CommonConstants.HttpServiceErrorKey, "Error in PutAsyncCall");
                }
                throw;
            }
        }

        public async Task<HttpResponseMessage> GetAsyncCall(string url, string scope)
        {
            try
            {
                Uri uri = new(url);
                string BearerToken = string.Empty;
                HttpClient _httpClient = _httpClientFactory.CreateClient(Source.Aurora.ToString());
                _httpClient.Timeout = TimeSpan.FromSeconds(_configuration.GetValue<int>(AppConstants.HttpClientTimeout));

                string? preferred_username = _httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == AppConstants.Preferred_Username)?.Value;

                BearerToken = !string.IsNullOrEmpty(preferred_username)
                    ? await GetAccessTokenByOnBehalfOfUser(scope)
                    : await GetAccessTokenByClientCredentials(scope);
                correlationId = _httpContextAccessor.HttpContext.Request.Headers
          .TryGetValue(CommonConstants.HeaderCorrelationId, out StringValues headerCorrelationId)
          ? headerCorrelationId : "";
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(CommonConstants.Bearer, BearerToken);
                _httpClient.DefaultRequestHeaders.Add(CommonConstants.HeaderRegionCode, regionCode);
                _httpClient.DefaultRequestHeaders.Add(CommonConstants.HeaderFacilityCode, facilityCode);
                _httpClient.DefaultRequestHeaders.Add(CommonConstants.HeaderLanguageCode, languageCode);
                _httpClient.DefaultRequestHeaders.Add(CommonConstants.HeaderSessionId, sessionId);
                _httpClient.DefaultRequestHeaders.Add(CommonConstants.HeaderCorrelationId, correlationId);
                HttpResponseMessage response = await _httpClient.GetAsync(uri).ConfigureAwait(true);
                string responseBody = await response.Content.ReadAsStringAsync();
                return new HttpResponseMessage()
                {
                    Content = new StringContent(responseBody),
                    StatusCode = response.StatusCode
                };
            }
            catch (HttpRequestException ex)
            {
                if (!ex.Data.Contains(CommonConstants.HttpServiceErrorKey))
                {
                    ex.Data.Add(CommonConstants.HttpServiceErrorKey, "Error in GetAsyncCall");
                }
                throw;
            }
        }

        public async Task<HttpResponseMessage> Aurora_PostAsyncCall(string url, dynamic data)
        {
            string json = JsonConvert.SerializeObject(data, Formatting.Indented);
            using StringContent stringContent = new(json, Encoding.UTF8, "application/json");
            try
            {
                Uri uri = new(url);
                HttpClient client = _httpClientFactory.CreateClient(Source.Aurora.ToString());
                client.Timeout = TimeSpan.FromSeconds(_configuration.GetValue<int>(AppConstants.HttpClientTimeout));
                byte[] byteArray = System.Text.Encoding.ASCII.GetBytes(_configuration["Care21UserName"] + ":" + _configuration["Care21Password"]);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = await client.PostAsync(uri, stringContent);
                string responseBody = await response.Content.ReadAsStringAsync();
                return new HttpResponseMessage()
                {
                    Content = new StringContent(responseBody),
                    StatusCode = response.StatusCode
                };
            }
            catch (HttpRequestException ex)
            {
                if (!ex.Data.Contains(CommonConstants.HttpServiceErrorKey))
                {
                    ex.Data.Add(CommonConstants.HttpServiceErrorKey, "Error in Care21_PostAsyncCall");
                }
                throw;
            }
        }
        public async Task<HttpResponseMessage> DeleteAsyncCall(string url, string scope)
        {
            try
            {
                Uri uri = new(url);
                string BearerToken = string.Empty;
                HttpClient client = _httpClientFactory.CreateClient(Source.Aurora.ToString());
                client.Timeout = TimeSpan.FromSeconds(_configuration.GetValue<int>(AppConstants.HttpClientTimeout));

                string? preferred_username = _httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == AppConstants.Preferred_Username)?.Value;

                BearerToken = !string.IsNullOrEmpty(preferred_username)
                    ? await GetAccessTokenByOnBehalfOfUser(scope)
                    : await GetAccessTokenByClientCredentials(scope);

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(AppConstants.TokenType, BearerToken);
                client.DefaultRequestHeaders.Add(CommonConstants.HeaderRegionCode, regionCode);

                HttpResponseMessage response = await client.DeleteAsync(uri);
                string responseBody = await response.Content.ReadAsStringAsync();

                return new HttpResponseMessage()
                {
                    Content = new StringContent(responseBody),
                    StatusCode = response.StatusCode
                };
            }
            catch (HttpRequestException e)
            {
                return new HttpResponseMessage()
                {
                    Content = new StringContent(e.Message),
                    StatusCode = HttpStatusCode.InternalServerError
                };
            }
        }

        private async Task<string> GetAccessTokenByClientCredentials(string scope)
        {
            string token = string.Empty;
            HttpClient client = _httpClientFactory.CreateClient(Source.Aurora.ToString());
            client.Timeout = TimeSpan.FromSeconds(_configuration.GetValue<int>(AppConstants.HttpClientTimeout));

            string tenantId = _configuration["TenantID"] ?? string.Empty;
            string baseAddress = $"https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token";

            Dictionary<string, string> form = new()
    {
        { "grant_type", "client_credentials" },
        { "client_id", _configuration[CommonConstants.RBACServiceAPIClientId] ?? string.Empty },
        { "client_secret", _configuration[CommonConstants.RBACServiceAPIClientSecret] ?? string.Empty },
        { "scope", scope ?? string.Empty }
    };
            HttpResponseMessage tokenResponse = await client.PostAsync(baseAddress, new FormUrlEncodedContent(form));
            string jsonString = await tokenResponse.Content.ReadAsStringAsync();
            object? responseData = JsonConvert.DeserializeObject(jsonString);
            if (responseData != null)
                token = ((dynamic)responseData).access_token;
            return token;
        }
        private async Task<string> GetAccessTokenByOnBehalfOfUser(string scope)
        {
            string token = string.Empty;
            HttpClient client = _httpClientFactory.CreateClient(Source.Aurora.ToString());
            client.Timeout = TimeSpan.FromSeconds(_configuration.GetValue<int>(AppConstants.HttpClientTimeout));
            string? TenantID = _configuration["TenantID"];
            string baseAddress = @"https://login.microsoftonline.com/" + TenantID + "/oauth2/v2.0/token";
            string? accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"].ToString()?.Replace("Bearer ", "");
            // Exchange the access token for an on-behalf-of token
            Dictionary<string, string> requestBody = new()
             {
                { "client_id",  _configuration[CommonConstants.RBACServiceAPIClientId] ?? string.Empty},
                { "client_secret",  _configuration[CommonConstants.RBACServiceAPIClientSecret] ?? string.Empty},
                { "grant_type", "urn:ietf:params:oauth:grant-type:jwt-bearer" },
                { "assertion", accessToken ?? string.Empty },
                { "requested_token_use", "on_behalf_of" },
                { "scope", scope}
             };
            HttpResponseMessage tokenResponse = await client.PostAsync(baseAddress, new FormUrlEncodedContent(requestBody));

            string jsonString = await tokenResponse.Content.ReadAsStringAsync();
            object? responseData = JsonConvert.DeserializeObject(jsonString);
            if (responseData != null)
                token = ((dynamic)responseData).access_token;
            return token;
        }
        public async Task<HttpResponseMessage> PostAuditAsyncCall(string url, dynamic data, string scope)
        {
            string json = JsonConvert.SerializeObject(data, Formatting.Indented);
            using var content = new StringContent(json, Encoding.UTF8, CommonConstants.ApplicationTypeJson);

            try
            {
                Uri uriPost = new(url);
                string BearerTokenPost = string.Empty;
                HttpClient clientPost = _httpClientFactory.CreateClient(Source.Aurora.ToString());
                clientPost.Timeout = TimeSpan.FromSeconds(_configuration.GetValue<int>(AppConstants.HttpClientTimeout));

                BearerTokenPost = await GetAccessTokenByClientCredentials(scope);

                clientPost.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(CommonConstants.Bearer, BearerTokenPost);
                clientPost.DefaultRequestHeaders.Add(CommonConstants.HeaderRegionCode, regionCode);
                clientPost.DefaultRequestHeaders.Add(CommonConstants.HeaderFacilityCode, facilityCode);
                clientPost.DefaultRequestHeaders.Add(CommonConstants.HeaderSessionId, sessionId);
                clientPost.DefaultRequestHeaders.Add(CommonConstants.HeaderLanguageCode, languageCode);
                clientPost.DefaultRequestHeaders.Add(CommonConstants.HeaderTimeZoneOffSet, CommonConstants.DefaultUtcOffset);
                HttpResponseMessage response = await clientPost.PostAsync(uriPost, content);
                string responseBody = await response.Content.ReadAsStringAsync();
                return new HttpResponseMessage()
                {
                    Content = new StringContent(responseBody),
                    StatusCode = response.StatusCode
                };
            }
            catch (HttpRequestException ex)
            {
                if (!ex.Data.Contains(CommonConstants.HttpServiceErrorKey))
                {
                    ex.Data.Add(CommonConstants.HttpServiceErrorKey, "Error in PostAuditAsyncCall");
                }
                throw;
            }
        }

        public async Task<HttpResponseMessage> GetAuditAsyncCall(string url, string scope, string correlationId)
        {
            try
            {
                Uri uri = new(url);
                string BearerToken = string.Empty;
                HttpClient _httpClient = _httpClientFactory.CreateClient(Source.Aurora.ToString());
                _httpClient.Timeout = TimeSpan.FromSeconds(_configuration.GetValue<int>(AppConstants.HttpClientTimeout));

                BearerToken = await GetAccessTokenByClientCredentials(scope);

                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(CommonConstants.Bearer, BearerToken);
                _httpClient.DefaultRequestHeaders.Add(CommonConstants.HeaderRegionCode, regionCode);
                _httpClient.DefaultRequestHeaders.Add(CommonConstants.HeaderFacilityCode, facilityCode);
                _httpClient.DefaultRequestHeaders.Add(CommonConstants.HeaderLanguageCode, languageCode);
                _httpClient.DefaultRequestHeaders.Add(CommonConstants.HeaderSessionId, sessionId);
                _httpClient.DefaultRequestHeaders.Add(CommonConstants.HeaderCorrelationId, correlationId);
                _httpClient.DefaultRequestHeaders.Add(CommonConstants.HeaderTimeZoneOffSet, CommonConstants.DefaultUtcOffset);
                HttpResponseMessage response = await _httpClient.GetAsync(uri).ConfigureAwait(true);
                string responseBody = await response.Content.ReadAsStringAsync();

                return new HttpResponseMessage()
                {
                    Content = new StringContent(responseBody),
                    StatusCode = response.StatusCode
                };
            }
            catch (HttpRequestException ex)
            {
                if (!ex.Data.Contains(CommonConstants.HttpServiceErrorKey))
                {
                    ex.Data.Add(CommonConstants.HttpServiceErrorKey, "Error in GetAuditAsyncCall");
                }
                throw;
            }
        }
        public async Task<string> GetStringAsync(string url)
        {
            var client = _httpClientFactory.CreateClient(Source.Aurora.ToString());
            client.Timeout = TimeSpan.FromSeconds(_configuration.GetValue<int>(AppConstants.HttpClientTimeout));
            return await client.GetStringAsync(url);
        }
    }
}

