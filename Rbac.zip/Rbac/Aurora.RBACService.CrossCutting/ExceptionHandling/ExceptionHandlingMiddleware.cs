﻿namespace Aurora.RBACService.CrossCutting.ExceptionHandling
{
    public class ExceptionHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ITelemetryClientWrapper _telemetryClient;
        /// <summary>
        /// initialize next middleware
        /// </summary>
        /// <param name="next"></param>
        public ExceptionHandlingMiddleware(RequestDelegate next,
            ITelemetryClientWrapper telemetryClient)
        {
            _next = next;
            _telemetryClient = telemetryClient;
        }

        /// <summary>
        /// Middleware method that handles incoming HTTP requests, processes them, and handles specific response status codes.
        /// </summary>
        /// <param name="context">The current HTTP context.</param>
        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
                string correlationId = GetCorrelationId(context);
                if (context.Response.StatusCode == (int)HttpStatusCode.Unauthorized && !context.Response.HasStarted)
                {
                    await WriteErrorResponse(context, CommonConstants.ERROR_UNAUTHORIZED, correlationId, null, CommonConstants.WARNING);
                }
                else if (context.Response.StatusCode == (int)HttpStatusCode.Forbidden && !context.Response.HasStarted)
                {
                    await WriteErrorResponse(context, CommonConstants.ERROR_ACCESS_DENIED, correlationId, null, CommonConstants.WARNING);
                }
                else if (context.Response.StatusCode == (int)HttpStatusCode.NotFound && !context.Response.HasStarted)
                {
                    await WriteErrorResponse(context, CommonConstants.ERROR_NOT_FOUND, correlationId, null, CommonConstants.WARNING);
                }
                else if (context.Response.StatusCode == (int)HttpStatusCode.MethodNotAllowed && !context.Response.HasStarted)
                {
                    await WriteErrorResponse(context, CommonConstants.ERROR_METHOD_NOT_ALLOWED, correlationId, null, CommonConstants.WARNING);
                }
                else if (context.Response.StatusCode == (int)HttpStatusCode.Conflict && !context.Response.HasStarted)
                {
                    await WriteErrorResponse(context, CommonConstants.ERROR_CONFLICT, correlationId, null, CommonConstants.WARNING);
                }
                else if (context.Response.StatusCode == (int)HttpStatusCode.Locked && !context.Response.HasStarted)
                {
                    await WriteErrorResponse(context, CommonConstants.ERROR_LOCKED, correlationId, null, CommonConstants.WARNING);
                }
                else if (context.Response.StatusCode == (int)HttpStatusCode.TooManyRequests && !context.Response.HasStarted)
                {
                    await WriteErrorResponse(context, CommonConstants.ERROR_TO_MANY_REQUEST, correlationId, null, CommonConstants.WARNING);
                }

            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        /// <summary>
        /// Handles exceptions that occur during request processing and sends an appropriate HTTP response.
        /// </summary>
        /// <param name="context">The current HTTP context.</param>
        /// <param name="exception">The exception that was thrown.</param>
        public async Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            context.Response.ContentType = "application/json";
            string correlationId = GetCorrelationId(context);
            string? errorId;
            if (context.Items.TryGetValue(CommonConstants.CustomErrorId, out object? value))
            {
                errorId = Convert.ToString(value);
                context.Items.Remove(CommonConstants.CustomErrorId);
            }
            else
            {
                errorId = Guid.NewGuid().ToString().Split('-')[^1];
            }
            switch (exception)
            {
                case TimeoutException timeoutException:
                    context.Response.StatusCode = Convert.ToInt32(HttpStatusCode.RequestTimeout); // Request Timeout
                    await WriteErrorResponse(context, CommonConstants.ERROR_TIMEOUT_EXCEPTION, correlationId, timeoutException.Message, CommonConstants.ERROR, timeoutException.Source);
                    break;
                case UnauthorizedAccessException unauthorizedAccessException:
                    context.Response.StatusCode = Convert.ToInt32(HttpStatusCode.Unauthorized); // Unauthorized
                    await WriteErrorResponse(context, CommonConstants.ERROR_UNAUTHORIZED, correlationId, unauthorizedAccessException.Message, CommonConstants.WARNING, unauthorizedAccessException.Source);
                    break;
                case HttpRequestException httpRequestException:
                    context.Response.StatusCode = Convert.ToInt32(HttpStatusCode.ServiceUnavailable); // Service Unavailable
                    await WriteErrorResponse(context, CommonConstants.ERROR_HTTP_REQUEST_EXCEPTION, correlationId, httpRequestException.Message, CommonConstants.ERROR, httpRequestException.Source);
                    break;
                case ArgumentException argumentException:
                    context.Response.StatusCode = Convert.ToInt32(HttpStatusCode.BadRequest); // Bad Request
                    await WriteErrorResponse(context, CommonConstants.ERROR_ARGUMENT_EXCEPTION, correlationId, argumentException.Message, CommonConstants.ERROR, argumentException.Source);
                    break;
                case KeyNotFoundException keyNotFoundException:
                    context.Response.StatusCode = Convert.ToInt32(HttpStatusCode.NotFound); // Not Found
                    await WriteErrorResponse(context, CommonConstants.ERROR_KEY_NOT_FOUND_EXCEPTION, correlationId, keyNotFoundException.Message, CommonConstants.ERROR, keyNotFoundException.Source);
                    break;
                case InvalidOperationException invalidOperationException:
                    context.Response.StatusCode = Convert.ToInt32(HttpStatusCode.Conflict); // Conflict
                    await WriteErrorResponse(context, CommonConstants.ERROR_INVALID_OPERATION_EXCEPTION, correlationId, invalidOperationException.Message, CommonConstants.ERROR, invalidOperationException.Source);
                    break;
                case NotImplementedException notImplementedException:
                    context.Response.StatusCode = Convert.ToInt32(HttpStatusCode.NotImplemented); // Not Implemented
                    await WriteErrorResponse(context, CommonConstants.ERROR_INVALID_OPERATION_EXCEPTION, correlationId, notImplementedException.Message, CommonConstants.ERROR, notImplementedException.Source);
                    break;
                default:
                    context.Response.StatusCode = Convert.ToInt32(HttpStatusCode.InternalServerError); // Internal Server Error
                    await WriteErrorResponse(context, CommonConstants.ERROR_INTERNAL_SERVER_ERROR, correlationId, exception.Message, CommonConstants.ERROR, exception.Source);
                    break;
            }
            LogExceptionTelemetry(exception, context, errorId);
        }

        private void LogExceptionTelemetry(Exception exception, HttpContext context, string? errorId)
        {
            HttpRequest request = context.Request;
            StringValues sessionId = request.Headers[CommonConstants.HeaderSessionId];
            StringValues correlationId = request.Headers[CommonConstants.HeaderCorrelationId];
            StringValues regionCode = request.Headers[CommonConstants.HeaderRegionCode];
            string? facilityCode = null;

            if (request.Headers.TryGetValue(CommonConstants.HeaderFacilityCode, out StringValues value))
            {
                facilityCode = value;
            }

            StackTrace trace = new(exception, true);

            var frame = trace.GetFrame(0);
            var method = frame?.GetMethod();

            var methodFullName = method != null
                ? $"{method.DeclaringType?.FullName}.{method.Name}"
                : "Unknown Method";
            ExceptionTelemetry exceptionTelemetry = new(exception);
            Dictionary<string, string> extraProperties = new()
            {
                { CommonConstants.HeaderSessionId, sessionId! },
                { CommonConstants.HeaderCorrelationId, correlationId! },
                { CommonConstants.HeaderRegionCode, regionCode! }
            };
            if (!string.IsNullOrEmpty(facilityCode))
            {
                extraProperties.Add(CommonConstants.HeaderFacilityCode, facilityCode);
            }
            extraProperties.Add(CommonConstants.MethodName, methodFullName);
            extraProperties.Add(CommonConstants.ErrorCode, CommonConstants.ErrorCodeValue);
            extraProperties.Add(CommonConstants.ErrorId, errorId!);
            extraProperties.Add(CommonConstants.ErrorDetail, exception.Message + "InnerException: " + exception.InnerException?.Message + "Trace: " + exception.StackTrace);

            _telemetryClient.TrackException(exceptionTelemetry.Exception, extraProperties);
        }


        /// <summary>
        /// Writes an error response to the HTTP context, formatted as a JSON object.
        /// </summary>
        /// <param name="httpContext">The current HTTP context that represents the HTTP request and response.</param>
        /// <param name="languageKey">A key representing the language</param>
        /// <param name="correlationId">A unique identifier for tracing and logging the error.</param>
        /// <param name="errorMessage">An optional message providing details about the error.</param>
        /// <param name="errorMessageType">An optional string specifying the type of the error message (e.g., "ERROR", "WARNING").</param>
        private static async Task WriteErrorResponse(HttpContext httpContext, string languageKey, string errorId, string? correlationId, string? errorMessage = null, string? errorMessageType = null, string? errorDetails = null)
        {
            string statusCode = httpContext.Response.StatusCode.ToString();
            string? translatedMessage = GetTranslatedMessage(languageKey, httpContext, errorMessage, statusCode);
            httpContext.Response.ContentType = "application/json";
            string message = errorMessageType == CommonConstants.ERROR
                ? $"[{CommonConstants.ErrorCode}: {CommonConstants.ErrorCodeValue}, {CommonConstants.ErrorId}: {errorId}, {CommonConstants.HeaderCorrelationId}: {correlationId}] {translatedMessage}"
                : $"[{CommonConstants.ErrorCodeValue}], {translatedMessage}";
            GenericResponse<string> responseData = new()
            {
                HasError = true,
                IsSuccess = false,
                Message = message,
                StatusCode = httpContext.Response.StatusCode.ToString(),
                MessageType = errorMessageType,
                ErrorDetails = errorDetails != null ? $"Source : {errorDetails}" : errorDetails,
            };
            await httpContext.Response.WriteAsync(JsonConvert.SerializeObject(responseData));
        }

        private static string GetCorrelationId(HttpContext context)
        {
            string? correlationId = context.Request.Headers[CommonConstants.HeaderCorrelationId];
            correlationId ??= Guid.NewGuid().ToString();
            return correlationId;
        }
        private static string? GetTranslatedMessage(string languageKey, HttpContext httpContext, string? errorMessage, string statusCode)
        {
            string? translatedMessage;
            string? languageCode = Convert.ToString(httpContext.Request.Headers[CommonConstants.HeaderLanguageCode]) ?? CommonConstants.MY;
            if (languageKey == LanguageResourceGeneralKeys.ERROR_HTTP_REQUEST_EXCEPTION)
            {
                translatedMessage = LanguageTranslator.Instance.TranslateDynamic(languageCode, languageKey, statusCode);
            }
            else
            {
                if (errorMessage == null)
                {
                    translatedMessage = LanguageTranslator.Instance.Translate(languageCode, languageKey);
                }
                else
                {
                    translatedMessage = LanguageTranslator.Instance.Translate(languageCode, languageKey, errorMessage);
                }
            }

            return translatedMessage;
        }
    }
}
