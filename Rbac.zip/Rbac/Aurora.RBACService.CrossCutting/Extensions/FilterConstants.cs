﻿namespace Aurora.RBACService.CrossCutting.Extensions
{
    [ExcludeFromCodeCoverage]
    public static class FilterColumnType
    {
        public const string STRING = "String";
        public const string INT32 = "Int32";
        public const string INT16 = "Int16";
        public const string LONG = "Int64";
        public const string DECIMAL = "Decimal";
        public const string DOUBLE = "Double";
        public const string FLOAT = "Single";
        public const string BOOLEAN = "Boolean";
        public const string Byte = "Byte";
        public const string DateTime = "DateTime";
    }
}
