﻿namespace Aurora.RBACService.CrossCutting.Extensions
{
    [ExcludeFromCodeCoverage]
    public static class StringExtension
    {
        public static T TrimStringProperties<T>(this object obj)
        {
            IEnumerable<PropertyInfo> stringProperties = obj.GetType().GetProperties().Where(p => p.PropertyType == typeof(string));

            foreach (PropertyInfo propertyInfo in stringProperties)
            {
                if (propertyInfo.GetValue(obj, null) is string value)
                    propertyInfo.SetValue(obj, value.Trim(), null);
            }
            return (T)obj;
        }
    }
}
