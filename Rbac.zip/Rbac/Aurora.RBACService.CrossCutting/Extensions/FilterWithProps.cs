﻿namespace Aurora.RBACService.CrossCutting.Extensions
{
    public static class FilterWithProps
    {
        public async static Task<IQueryable<T>> ApplyQueryParameters<T>(
            this IQueryable<T> query,
            PaginationQuery parameters)
        {
            if (parameters.Filters != null && parameters.Filters.Any())
            {
                foreach (var filter in parameters.Filters)
                {
                    // Split the filter key by "." to handle nested properties
                    var propertyPath = filter.Key.Split('.');
                    Expression? propertyAccess = null;
                    ParameterExpression parameter = Expression.Parameter(typeof(T), "p");

                    Type currentType = typeof(T);
                    Expression? innerCondition = null;

                    foreach (var propertyName in propertyPath)
                    {
                        PropertyInfo? propertyInfo = currentType.GetProperty(propertyName);
                        if (propertyInfo == null)
                        {
                            propertyAccess = null;
                            break; // Exit if any property in the path is missing
                        }

                        if (typeof(System.Collections.IEnumerable).IsAssignableFrom(propertyInfo.PropertyType)
                            && propertyInfo.PropertyType != typeof(string))
                        {
                            // Handle collection property with Any()
                            var itemType = propertyInfo.PropertyType.GenericTypeArguments[0];
                            var innerParameter = Expression.Parameter(itemType, "x");
                            var innerProperty = Expression.Property(innerParameter, propertyPath[^1]);
                            var filterValue = Convert.ChangeType(filter.Value, innerProperty.Type);

                            Expression collectionCondition;
                            if (innerProperty.Type == typeof(string))
                            {
                                collectionCondition = Expression.Call(innerProperty, nameof(FilterOperator.Contains), null, Expression.Constant(filterValue));
                            }
                            else
                            {
                                collectionCondition = Expression.Equal(innerProperty, Expression.Constant(filterValue));
                            }

                            var lambda = Expression.Lambda(collectionCondition, innerParameter);
                            propertyAccess = Expression.Call(
                                typeof(Enumerable),
                                "Any",
                                new Type[] { itemType },
                                propertyAccess ?? Expression.Property(parameter, propertyInfo),
                                lambda);

                            innerCondition = Expression.Lambda<Func<T, bool>>(propertyAccess, parameter);
                            query = query.Where((Expression<Func<T, bool>>)innerCondition);
                        }
                        else
                        {
                            // Standard property access
                            propertyAccess = Expression.Property(propertyAccess ?? (Expression)parameter, propertyInfo);
                            currentType = propertyInfo.PropertyType;
                        }
                    }

                    // If property path is invalid, skip this filter
                    if (propertyAccess == null || innerCondition != null)
                    {
                        continue;
                    }

                    // Handle nullable types by getting the underlying type
                    var nonNullableType = Nullable.GetUnderlyingType(currentType) ?? currentType;

                    // Convert filter value to the correct type
                    object? filterValueNonCollection = Convert.ChangeType(filter.Value, nonNullableType);

                    // Build the condition based on property type
                    Expression condition;
                    if (nonNullableType == typeof(string))
                    {
                        condition = Expression.Call(propertyAccess, nameof(FilterOperator.Contains), null, Expression.Constant(filterValueNonCollection));
                    }
                    else
                    {
                        condition = Expression.Equal(propertyAccess, Expression.Constant(filterValueNonCollection, currentType));
                    }

                    var lambdaCondition = Expression.Lambda<Func<T, bool>>(condition, parameter);
                    query = query.Where(lambdaCondition);
                }
            }
            return await Task.FromResult(query);
        }
    }
}
