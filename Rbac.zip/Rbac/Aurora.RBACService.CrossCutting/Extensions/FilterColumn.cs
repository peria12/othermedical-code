﻿namespace Aurora.RBACService.CrossCutting.Extensions
{
    public class FilterColumn
    {
        public FilterCondition Condition { get; set; }
        public FilterOperator Operator { get; set; }
        public required string Column { get; set; }
    }
}
