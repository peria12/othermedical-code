﻿namespace Aurora.RBACService.CrossCutting.Extensions
{
    public enum FilterCondition
    {
        OR,
        AND
    }
    public enum FilterOperator
    {
        Equals,
        DoesntEqual,
        GreaterThan,
        GreaterThanOrEqual,
        LessThan,
        LessThanOrEqual,
        Contains,
        NotContains,
        StartsWith,
        EndsWith,
        ContainsIgnoreCase,
        IsEmpty,
        IsNotEmpty,
        ContainsKey,
        NotContainsKey,
        ContainsValue,
        NotContainsValue
    }
}
