﻿namespace Aurora.RBACService.CrossCutting.Extensions
{
    [ExcludeFromCodeCoverage]
    public class PaginationQuery
    {
        public PaginationQuery(int pageNumber, int pageSize)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
        }
        public PaginationQuery()
        {

        }

        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;

        public string? GlobalFilterString { get; set; }
        [ModelBinder(BinderType = typeof(NestedModelFilterBinder))]
        public Dictionary<string, string>? Filters { get; set; } = new Dictionary<string, string>();
        public string? SortString { get; set; }
        public string? SortOrder { get; set; }
    }
}
