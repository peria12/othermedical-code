﻿namespace Aurora.RBACService.CrossCutting.Extensions
{
    public static class JsonSerializerExtensions
    {
        public static string SerializeWithCamelCase<T>(this T data)
        {
            return System.Text.Json.JsonSerializer.Serialize(data, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });
        }
    }
}
