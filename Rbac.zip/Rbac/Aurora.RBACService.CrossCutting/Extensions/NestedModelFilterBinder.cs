﻿namespace Aurora.RBACService.CrossCutting.Extensions
{
    public class NestedModelFilterBinder : IModelBinder
    {
        public Task BindModelAsync(ModelBindingContext bindingContext)
        {
            if (bindingContext.ModelType != typeof(Dictionary<string, string>))
            {
                bindingContext.Result = ModelBindingResult.Failed();
                return Task.CompletedTask;
            }

            var result = bindingContext.HttpContext.Request.Query
                .Where(kvp => kvp.Key.StartsWith("Filters.", StringComparison.OrdinalIgnoreCase))
                    .ToDictionary(
                        kvp => kvp.Key.Substring("Filters.".Length),
                        kvp => kvp.Value.ToString()
                    );

            bindingContext.Result = ModelBindingResult.Success(result);
            return Task.CompletedTask;
        }
    }
}

