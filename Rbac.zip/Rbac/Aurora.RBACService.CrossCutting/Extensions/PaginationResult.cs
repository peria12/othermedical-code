﻿namespace Aurora.RBACService.CrossCutting.Extensions
{
    [ExcludeFromCodeCoverage]
    public class PaginationResult<T>
    {
        public IQueryable<T> Records { get; set; } = new List<T>().AsQueryable();
        public int TotalCount { get; set; }
    }
}
