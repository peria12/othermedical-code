﻿namespace Aurora.RBACService.CrossCutting.Extensions
{
    [ExcludeFromCodeCoverage]
    public static class PaginationSortFilter
    {
        private static readonly Type _stringType = typeof(string);

        private static readonly MethodInfo? _toStringMethod = typeof(object).GetMethod("ToString");

        private static readonly MethodInfo? _stringContainsMethod = typeof(string).GetMethod("Contains", new Type[] { typeof(string) });
        private static readonly MethodInfo? _stringContainsMethodIgnoreCase = typeof(string).GetMethod("Contains", new Type[] { typeof(string), typeof(StringComparison) });
        private static readonly MethodInfo _enumerableContainsMethod = typeof(Enumerable).GetMethods().Where(x => string.Equals(x.Name, "Contains", StringComparison.OrdinalIgnoreCase)).Single(x => x.GetParameters().Length == 2).MakeGenericMethod(typeof(string));
        private static readonly MethodInfo _dictionaryContainsKeyMethod = typeof(Dictionary<string, string>).GetMethods().Single(x => string.Equals(x.Name, "ContainsKey", StringComparison.OrdinalIgnoreCase));
        private static readonly MethodInfo _dictionaryContainsValueMethod = typeof(Dictionary<string, string>).GetMethods().Single(x => string.Equals(x.Name, "ContainsValue", StringComparison.OrdinalIgnoreCase));
        private static readonly MethodInfo? _endsWithMethod = typeof(string).GetMethod("EndsWith", new Type[] { typeof(string) });
        private static readonly MethodInfo? _isNullOrEmtpyMethod = typeof(string).GetMethod("IsNullOrEmpty", new Type[] { typeof(string) });
        private static readonly MethodInfo? _startsWithMethod = typeof(string).GetMethod("StartsWith", new Type[] { typeof(string) });

        public static Expression<Func<TEntity, bool>> GetPredicate<TEntity>(string property, FilterOperator op, object value)
        {
            ParameterExpression param = Expression.Parameter(typeof(TEntity));
            return Expression.Lambda<Func<TEntity, bool>>(GetFilter(param, property, op, value), param);
        }

        public static Expression<Func<TEntity, object>> GetPropertyGetter<TEntity>(string property)
        {
            if (property == null)
                throw new ArgumentNullException(nameof(property));

            ParameterExpression param = Expression.Parameter(typeof(TEntity));
            MemberExpression prop = param.GetNestedProperty(property);
            UnaryExpression convertedProp = Expression.Convert(prop, typeof(object));
            return Expression.Lambda<Func<TEntity, object>>(convertedProp, param);
        }

        internal static Expression GetFilter(ParameterExpression param, string property, FilterOperator op, object value)
        {
            ConstantExpression constant = Expression.Constant(value);
            MemberExpression prop = param.GetNestedProperty(property);
            return CreateFilter(prop, op, constant);
        }

        internal static MemberExpression GetNestedProperty(this Expression param, string property)
        {
            string[] propNames = property.Split('.');
            MemberExpression propExpr = Expression.Property(param, propNames[0]);

            for (int i = 1; i < propNames.Length; i++)
            {
                propExpr = Expression.Property(propExpr, propNames[i]);
            }

            return propExpr;
        }

        private static Expression CreateFilter(MemberExpression prop, FilterOperator op, ConstantExpression constant)
        {
            return op switch
            {
                FilterOperator.Equals => RobustEquals(prop, constant),
                FilterOperator.GreaterThan => Expression.GreaterThan(prop, constant),
                FilterOperator.LessThan => Expression.LessThan(prop, constant),
                FilterOperator.ContainsIgnoreCase => RobustContainsIgnoreCase(prop, constant),
                FilterOperator.Contains => GetContainsMethodCallExpression(prop, constant),
                FilterOperator.NotContains => Expression.Not(GetContainsMethodCallExpression(prop, constant)),
                FilterOperator.ContainsKey => Expression.Call(prop, _dictionaryContainsKeyMethod, PrepareConstant(constant)),
                FilterOperator.NotContainsKey => Expression.Not(Expression.Call(prop, _dictionaryContainsKeyMethod, PrepareConstant(constant))),
                FilterOperator.ContainsValue => Expression.Call(prop, _dictionaryContainsValueMethod, PrepareConstant(constant)),
                FilterOperator.NotContainsValue => Expression.Not(Expression.Call(prop, _dictionaryContainsValueMethod, PrepareConstant(constant))),
                FilterOperator.StartsWith => RobustStartsWith(prop, constant),
                FilterOperator.EndsWith => RobustEndsWith(prop, constant),
                FilterOperator.DoesntEqual => Expression.Not(RobustEquals(prop, constant)),
                FilterOperator.GreaterThanOrEqual => Expression.GreaterThanOrEqual(prop, constant),
                FilterOperator.LessThanOrEqual => Expression.LessThanOrEqual(prop, constant),
                FilterOperator.IsEmpty => RobustIsEmpty(prop, constant),
                FilterOperator.IsNotEmpty => RobustIsNotEmpty(prop, constant),
                _ => throw new NotImplementedException()
            };
        }

        private static Expression RobustEquals(MemberExpression prop, ConstantExpression constant)
        {
            if (prop.Type == typeof(bool) && bool.TryParse(constant?.Value?.ToString(), out bool val))
            {
                return Expression.Equal(prop, Expression.Constant(val));
            }
            if (prop.Type == typeof(bool?) && bool.TryParse(constant?.Value?.ToString(), out bool boolVal))
            {
                return RobustEqualsBool(prop, boolVal);
            }
            if ((prop.Type == typeof(short) || prop.Type == typeof(short?))
                && short.TryParse(constant?.Value?.ToString(), out short int16val))
            {
                return RobustEqualsINT16(prop, int16val);
            }
            if ((prop.Type == typeof(byte) || prop.Type == typeof(byte?))
                 && byte.TryParse(constant?.Value?.ToString(), out byte byteVal))
            {
                return RobustEqualsByte(prop, byteVal);
            }
            if ((prop.Type == typeof(decimal?) || prop.Type == typeof(decimal))
                && decimal.TryParse(constant?.Value?.ToString(), out decimal decimalVal))
            {
                return RobustEqualsDecimal(prop, decimalVal);
            }
            if ((prop.Type == typeof(int) || prop.Type == typeof(int?))
            && int.TryParse(constant?.Value?.ToString(), out int int32val))
            {
                return RobustEqualsINT(prop, int32val);
            }
            if (prop.Type == typeof(DateTime?) || prop.Type == typeof(DateTime))
            {
                return RobustEqualsDateTime(prop, constant);
            }
            return Expression.Equal(prop, Expression.Constant(constant?.Value));
        }
        private static Expression RobustEqualsBool(MemberExpression prop, bool boolVal)
        {
            ConstantExpression constantVal = Expression.Constant(boolVal);
            Type propertyType = ((PropertyInfo)prop.Member).PropertyType;

            UnaryExpression valueExpression = Expression.Convert(constantVal, propertyType);
            return Expression.Equal(prop, valueExpression);
        }
        private static Expression RobustEqualsINT16(MemberExpression prop, short int16val)
        {
            ConstantExpression constantVal = Expression.Constant(int16val);
            Type propertyType = ((PropertyInfo)prop.Member).PropertyType;
            TypeConverter converter = TypeDescriptor.GetConverter(propertyType);
            if (!converter.CanConvertFrom(typeof(string)))
                throw new NotSupportedException();

            UnaryExpression valueExpression = Expression.Convert(constantVal, propertyType);
            return Expression.Equal(prop, valueExpression);
        }
        private static Expression RobustEqualsByte(MemberExpression prop, short byteval)
        {
            ConstantExpression constantVal = Expression.Constant(byteval);
            Type propertyType = ((PropertyInfo)prop.Member).PropertyType;
            TypeConverter converter = TypeDescriptor.GetConverter(propertyType);
            if (!converter.CanConvertFrom(typeof(string)))
                throw new NotSupportedException();

            UnaryExpression valueExpression = Expression.Convert(constantVal, propertyType);
            return Expression.Equal(prop, valueExpression);
        }
        private static Expression RobustEqualsDecimal(MemberExpression prop, decimal decimalVal)
        {
            ConstantExpression constantVal = Expression.Constant(decimalVal);
            Type propertyType = ((PropertyInfo)prop.Member).PropertyType;
            TypeConverter converter = TypeDescriptor.GetConverter(propertyType);
            if (!converter.CanConvertFrom(typeof(string)))
                throw new NotSupportedException();
            UnaryExpression valueExpression = Expression.Convert(constantVal, propertyType);
            return Expression.Equal(prop, valueExpression);
        }
        private static Expression RobustEqualsINT(MemberExpression prop, int int32val)
        {
            ConstantExpression constantVal = Expression.Constant(int32val);
            Type propertyType = ((PropertyInfo)prop.Member).PropertyType;
            TypeConverter converter = TypeDescriptor.GetConverter(propertyType);
            if (!converter.CanConvertFrom(typeof(string)))
                throw new NotSupportedException();

            UnaryExpression valueExpression = Expression.Convert(constantVal, propertyType);
            return Expression.Equal(prop, valueExpression);
        }
        private static Expression RobustEqualsDateTime(MemberExpression prop, ConstantExpression? constant)
        {
            DateTime? dtval = TryParseDateTimeNullable(constant?.Value?.ToString());
            ConstantExpression constantVal = Expression.Constant(dtval);

            Type propertyType = ((PropertyInfo)prop.Member).PropertyType;
            TypeConverter converter = TypeDescriptor.GetConverter(propertyType);
            if (!converter.CanConvertFrom(typeof(string)))
                throw new NotSupportedException();

            UnaryExpression valueExpression = Expression.Convert(constantVal, propertyType);
            return Expression.Equal(prop, valueExpression);
        }
        public static DateTime? TryParseDateTimeNullable(string? val)
        {
            return DateTime.TryParse(val, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime outValue) ? outValue : null;
        }
        private static Expression RobustContainsIgnoreCase(MemberExpression prop, ConstantExpression constant)
        {
            return _stringContainsMethodIgnoreCase == null
                ? constant
                : Expression.Call(prop, _stringContainsMethodIgnoreCase, PrepareConstant(constant), Expression.Constant(StringComparison.OrdinalIgnoreCase));
        }
        private static Expression RobustEndsWith(MemberExpression prop, ConstantExpression constant)
        {
            return _endsWithMethod == null ? constant : Expression.Call(prop, _endsWithMethod, PrepareConstant(constant));
        }
        private static Expression RobustStartsWith(MemberExpression prop, ConstantExpression constant)
        {
            return _startsWithMethod == null ? constant : Expression.Call(prop, _startsWithMethod, PrepareConstant(constant));
        }
        private static Expression RobustIsEmpty(MemberExpression prop, ConstantExpression constant)
        {
            return _isNullOrEmtpyMethod == null ? constant : Expression.Call(_isNullOrEmtpyMethod, prop);
        }
        private static Expression RobustIsNotEmpty(MemberExpression prop, ConstantExpression constant)
        {
            return _isNullOrEmtpyMethod == null ? constant : Expression.Not(Expression.Call(_isNullOrEmtpyMethod, prop));
        }

        private static Expression GetContainsMethodCallExpression(MemberExpression prop, ConstantExpression constant)
        {
            if (prop.Type == _stringType && _stringContainsMethod != null)
                return Expression.Call(prop, _stringContainsMethod, PrepareConstant(constant));
            else if (prop.Type.GetInterfaces().Contains(typeof(IDictionary)))
                return Expression.Or(Expression.Call(prop, _dictionaryContainsKeyMethod, PrepareConstant(constant)), Expression.Call(prop, _dictionaryContainsValueMethod, PrepareConstant(constant)));
            else if (prop.Type.GetInterfaces().Contains(typeof(IEnumerable)))
                return Expression.Call(_enumerableContainsMethod, prop, PrepareConstant(constant));

            throw new NotImplementedException($"{prop.Type} contains is not implemented.");
        }

        private static Expression PrepareConstant(ConstantExpression constant)
        {

            if (constant.Type == _stringType || _toStringMethod == null)
                return constant;

            UnaryExpression convertedExpr = Expression.Convert(constant, typeof(object));
            return Expression.Call(convertedExpr, _toStringMethod);
        }
    }
}
