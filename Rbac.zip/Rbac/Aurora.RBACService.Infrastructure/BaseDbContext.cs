﻿namespace Aurora.RBACService.Infrastructure
{
    /// <summary>
    /// Creation of connection string region wise and configure entities
    /// </summary>
    public abstract class BaseDbContext : DbContext
    {
        private readonly IConfiguration _configuration = null!;
        private readonly HttpContextAccessor _httpContextAccessor = new();

        protected BaseDbContext(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        protected BaseDbContext(DbContextOptions options) : base(options)
        {

        }

        protected BaseDbContext(DbContextOptions options, IConfiguration configuration) : base(options)
        {
            _configuration = configuration;
        }

        public virtual DbSet<Group> Groups { get; set; }
        public virtual DbSet<GroupRoleMapping> GroupRoleMappings { get; set; }
        public virtual DbSet<ResourceMaster> ResourceMasters { get; set; }
        public virtual DbSet<ResourceType> ResourceTypes { get; set; }
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<RoleResourceMasterMapping> RoleResourceMasterMappings { get; set; }
        public virtual DbSet<UserProfile> UserProfiles { get; set; }
        public virtual DbSet<DependentResource> DependentResources { get; set; }


        protected abstract override void OnConfiguring(DbContextOptionsBuilder optionsBuilder);

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<ResourceType>().HasData(GetSeedResourceTypes());
            ApplyEntityConfigurations(modelBuilder);
        }

        private static ResourceType[] GetSeedResourceTypes()
        {
            var createdBy = "s.basan@COLUMBIAASIA.COM";
            var createdDate = DateTime.UtcNow;

            return new[]
            {
                new ResourceType { Id = 1, ResourceTypeName = "Module", ResourceTypeDescription = "To control Module", CreatedBy = createdBy, CreatedDate = createdDate, IsDeleted = false },
                new ResourceType { Id = 2, ResourceTypeName = "Menu", ResourceTypeDescription = "To control Menu", CreatedBy = createdBy, CreatedDate = createdDate, IsDeleted = false },
                new ResourceType { Id = 3, ResourceTypeName = "Section", ResourceTypeDescription = "To control sections of a web page", CreatedBy = createdBy, CreatedDate = createdDate, IsDeleted = false },
                new ResourceType { Id = 4, ResourceTypeName = "Action-Controls", ResourceTypeDescription = "To control EF buttons", CreatedBy = createdBy, CreatedDate = createdDate, IsDeleted = false },
                new ResourceType { Id = 5, ResourceTypeName = "Input-Controls", ResourceTypeDescription = "To control in the web page and BE endpoints", CreatedBy = createdBy, CreatedDate = createdDate, IsDeleted = false },
                new ResourceType { Id = 6, ResourceTypeName = "Endpoint", ResourceTypeDescription = "To control APIs", CreatedBy = createdBy, CreatedDate = createdDate, IsDeleted = false }
            };
        }


        /// <summary>
        /// Apply the configuration for entities
        /// </summary>
        /// <param name="modelBuilder"></param>
        private static void ApplyEntityConfigurations(ModelBuilder modelBuilder)
        {
        }

        /// <summary>
        /// Create a connection string based on region code
        /// </summary>
        /// <param name="isReadOnlyIntent"></param>
        /// <returns></returns>
        protected string? PrepareConnectionString(bool isReadOnlyIntent)
        {
            string? connectionString = null;
            try
            {
                if (_httpContextAccessor.HttpContext?.Request.Headers
                    .TryGetValue(CommonConstants.HEADERREGIONCODE, out StringValues regionCode) ?? false)
                {
                    string connectionName = $"{AppConstants.CONNECTIONSTRINGPREFIX}{regionCode}{AppConstants.MICROSERVICECODE}ConnectionString";

                    //It's a feature flag
                    if (Convert.ToBoolean(_configuration["isKeyVaultConfigured"]))
                    {
                        connectionString = _configuration.GetSection(connectionName).Value;
                    }
                    else
                    {
                        connectionString = _configuration.GetConnectionString(connectionName);
                    }

                    if (!string.IsNullOrEmpty(connectionString))
                    {
                        var connectionParts = connectionString
                            .Split(';', StringSplitOptions.RemoveEmptyEntries)
                            .Where(x => !x.Equals("ApplicationIntent", StringComparison.OrdinalIgnoreCase))
                            .ToList();

                        string applicationIntent = isReadOnlyIntent
                            ? "ApplicationIntent=readonly"
                            : "ApplicationIntent=readwrite";
                        connectionParts.Add(applicationIntent);

                        if (isReadOnlyIntent)
                        {
                            int count = connectionParts.Count;
                            while (count > 1)
                            {
                                int i = Random.Shared.Next(count--);
                                (connectionParts[i], connectionParts[count]) = (connectionParts[count], connectionParts[i]);
                            }
                        }
                        connectionString = string.Join(';', connectionParts);
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Data.Add("BaseDbContext.PrepareConnectionString()",
                    "Error occured while preparing database connection");
                throw;
            }
            return connectionString;
        }
    }
}