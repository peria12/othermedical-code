﻿namespace Aurora.RBACService.Infrastructure
{
    /// <summary>
    /// Read write dbcontext configuration
    /// </summary>
    public class ReadWriteDbContext : BaseDbContext
    {
        public ReadWriteDbContext(IConfiguration configuration)
            : base(configuration)
        {
        }

        public ReadWriteDbContext(IConfiguration configuration, DbContextOptions<ReadWriteDbContext> options)
            : base(options, configuration)
        {
        }
        public ReadWriteDbContext(DbContextOptions<ReadWriteDbContext> options)
           : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                string? connStr = PrepareConnectionString(false);
                optionsBuilder.UseSqlServer(connStr);
            }
        }
    }
}
