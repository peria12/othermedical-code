﻿namespace Aurora.RBACService.Infrastructure
{
    [ExcludeFromCodeCoverage]
    public static class MigrationManager
    {
        /// <summary>
        /// Applying migration 
        /// </summary>
        /// <param name="serviceProvider"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public static async Task ApplyMigrations(IServiceProvider serviceProvider)
        {
            try
            {
                IConfiguration? configuration = serviceProvider.GetService<IConfiguration>();
                if (configuration != null)
                {
                    string? regionCode = configuration[CommonConstants.AURORAREGIONCODE];
                    string[] regions = !string.IsNullOrEmpty(regionCode) ? regionCode.Split(",") : Array.Empty<string>();

                    if (regions.Length == 0)
                    {
                        throw new InvalidOperationException($"{typeof(MigrationManager).Name}: {ResponseMessage.STATUS_INVALID_REGIONCODE} : {regionCode}");
                    }

                    foreach (string region in regions)
                    {
                        try
                        {
                            string? connectionString = PrepareConnectionString(region.Trim(), configuration);
                            using MigrationDbContext dbContext = new(configuration, connectionString);
                            await dbContext.Database.EnsureCreatedAsync();

                            IEnumerable<string> pendingMigrations = await dbContext.Database.GetPendingMigrationsAsync();
                            if (pendingMigrations.Any())
                            {
                                await dbContext.Database.MigrateAsync();
                            }
                        }
                        catch (Exception ex)
                        {
                            string methodName = System.Reflection.MethodBase.GetCurrentMethod()!.Name.ToString();
                            ex.Data.Add($"{typeof(MigrationManager).Name}.{methodName} - region", region);
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"An Error Occurred: {ex.Message}");
            }
        }

        /// <summary>
        /// Creating connection string on basis of region code
        /// </summary>
        /// <param name="regionCode"></param>
        /// <param name="configuration"></param>
        /// <returns></returns>
        public static string? PrepareConnectionString(string regionCode, IConfiguration configuration)
        {
            string? connectionString = null;
            try
            {
                string connectionName = $"{AppConstants.CONNECTIONSTRINGPREFIX}{regionCode}{AppConstants.MICROSERVICECODE}ConnectionString";

                if (Convert.ToBoolean(configuration[CommonConstants.ISKEYVAULTCONFIGURED]))
                {
                    connectionString = configuration.GetSection(connectionName).Value;
                }
                else
                {
                    connectionString = configuration.GetConnectionString(connectionName);
                }

                if (!string.IsNullOrEmpty(connectionString))
                {
                    List<string> connectionParts = connectionString
                       .Split(';', StringSplitOptions.RemoveEmptyEntries)
                       .Where(x => !x.Equals(CommonConstants.APPLICATIONINTENT, StringComparison.OrdinalIgnoreCase))
                       .ToList();

                    connectionParts.Add("ApplicationIntent=readwrite");
                    connectionString = string.Join(';', connectionParts);
                }
            }
            catch (Exception ex)
            {
                ex.Data.Add("MigrationManager.PrepareConnectionString()", CommonConstants.DATABASECONNECTIONERROR);
                throw;
            }
            return connectionString;
        }
    }
}