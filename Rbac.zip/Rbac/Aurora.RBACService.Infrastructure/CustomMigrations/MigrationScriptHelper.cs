﻿namespace Aurora.RBACService.Infrastructure.CustomMigrations
{
    public static class MigrationScriptHelper
    {
        // Define the file name for the generated SQL migration script.
        public const string EFMigrationScriptFileName = $"{nameof(Aurora)}.{nameof(RBACService)}_Ef_Migration_Script.sql";
        // Define the relative path to your infrastructure project folder.
        private const string infrastructurePath = $"..\\{nameof(Aurora)}.{nameof(RBACService)}.{nameof(Infrastructure)}";
        public static async Task GenerateMigrationScript(string migrationDbContext)
        {
            // Step 1: Build the migration command using EF Core CLI.
            // This command will generate an idempotent migration script targeting the specified DbContext.
            string migrationCmd = $"dotnet ef migrations script --idempotent --context {migrationDbContext} --output \"./Migrations/{EFMigrationScriptFileName}\"";
            try
            {
                // Step 2: Get the current directory and extract the drive letter.
                // This ensures the command prompt navigates to the correct drive on Windows.
                string currentDirectory = Directory.GetCurrentDirectory();
                string drive = Path.GetPathRoot(currentDirectory)?.Substring(0, 1) ?? string.Empty;
                // Step 3: Configure the process start info for cmd.exe.
                // The arguments change the drive, navigate to the project's infrastructure folder, then execute the migration command.
                ProcessStartInfo processStartInfo = new("cmd.exe")
                {
                    Arguments = $"/C {drive}: && cd \"{Path.GetFullPath(infrastructurePath)}\" && {migrationCmd}",
                    WorkingDirectory = Path.GetFullPath(infrastructurePath),
                    CreateNoWindow = false,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                };
                // Step 4: Create and configure the Process to run the migration command.
                using Process process = new() { StartInfo = processStartInfo, EnableRaisingEvents = true };
                // Step 5: Ensure that if the application exits, the process is terminated.
                AppDomain.CurrentDomain.ProcessExit += (sender, e) =>
                {
                    if (!process.HasExited)
                    {
                        process.Kill();
                        Console.WriteLine("cmd processor closed on exit");
                    }
                };
                // Step 6: Inform the user that script generation has started.
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.BackgroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Generating seeding script. Please wait...");
                Console.ResetColor();
                // Step 7: Attach event handlers to capture output and error messages.
                // These handlers provide real-time feedback during the process execution.
                process.OutputDataReceived += Process_OutputDataReceived;
                process.ErrorDataReceived += Process_ErrorDataReceived;
                process.Exited += ProcessExited;
                // Step 8: Start the process and begin reading its output/error streams asynchronously.
                process.Start();
                process.BeginOutputReadLine();
                process.BeginErrorReadLine();
                // Step 9: Wait asynchronously for the process to complete.
                await process.WaitForExitAsync();
            }
            catch (Exception ex)
            {
                // Step 10: In case of any error, output the error message in the console.
                Console.BackgroundColor = ConsoleColor.Red;
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine($"An exception occurred: {ex.Message}");
                Console.ResetColor();
                throw;
            }
        }
        // This event handler is triggered when the migration process exits.
        // It checks for the generated file and confirms its content.
        private static async void ProcessExited(object? sender, EventArgs e)
        {
            // Step 11: Build the full path to the generated migration script.
            string scriptPath = Path.Combine(Path.GetFullPath(infrastructurePath), "Migrations", EFMigrationScriptFileName);
            if (File.Exists(scriptPath))
            {
                // Step 12: Read the generated migration script.
                string scriptContent = await File.ReadAllTextAsync(scriptPath);
                // Check that the script includes a "GO" statement, a common SQL batch separator.
                if (scriptContent.Contains("GO"))
                {
                    // (Optional) You can modify or process the scriptContent before rewriting if needed.
                    await File.WriteAllTextAsync(scriptPath, scriptContent);
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("Migration script generated successfully.");
                    Console.ResetColor();
                }
                else
                {
                    Console.WriteLine("No 'GO' statement found in the script.");
                }
            }
            else
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.WriteLine($"Generated script file '{EFMigrationScriptFileName}' not found.");
                Console.ResetColor();
                throw new FileNotFoundException("Migration script not found.", scriptPath);
            }
        }
        // This handler captures and outputs error data from the process.
        private static void Process_ErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (!string.IsNullOrEmpty(e.Data))
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine($"Error: {e.Data}");
                Console.ResetColor();
            }
        }
        // This handler captures standard output from the process.
        private static void Process_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (!string.IsNullOrEmpty(e.Data))
            {
                // Optionally filter routine messages such as "Build succeeded".
                if (e.Data.Contains("Build succeeded"))
                {
                    return;
                }
                Console.BackgroundColor = ConsoleColor.White;
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.WriteLine($"Output: {e.Data}");
                Console.ResetColor();
            }
        }
    }
}
