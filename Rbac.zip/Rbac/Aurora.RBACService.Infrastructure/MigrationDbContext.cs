﻿namespace Aurora.RBACService.Infrastructure
{
    [ExcludeFromCodeCoverage]
    public class MigrationDbContext : BaseDbContext
    {
        private readonly string? _connectionString;
        public MigrationDbContext(IConfiguration configuration)
       : base(configuration)
        {
        }
        public MigrationDbContext(IConfiguration configuration, string? connectionString)
        : base(configuration)
        {
            _connectionString = connectionString;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(_connectionString);
            }
        }
    }
}
