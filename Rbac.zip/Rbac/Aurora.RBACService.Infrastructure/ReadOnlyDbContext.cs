﻿namespace Aurora.RBACService.Infrastructure
{
    /// <summary>
    /// Read only dbcontext configuration
    /// </summary>
    public class ReadOnlyDbContext : BaseDbContext
    {
        public ReadOnlyDbContext(IConfiguration configuration)
               : base(configuration)
        {
        }
        public ReadOnlyDbContext(IConfiguration configuration, DbContextOptions<ReadOnlyDbContext> options)
           : base(options, configuration)
        {
        }

        public ReadOnlyDbContext(DbContextOptions<ReadOnlyDbContext> options)
          : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                string? connStr = PrepareConnectionString(true);
                optionsBuilder.UseSqlServer(connStr);
            }
        }
        public static void GetPatientOverviewByIdAsync(string patientId)
        {
            throw new NotImplementedException();
        }
    }
}
