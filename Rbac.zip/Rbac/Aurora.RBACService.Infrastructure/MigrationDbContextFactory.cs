﻿namespace Aurora.RBACService.Infrastructure
{
    [ExcludeFromCodeCoverage]
    public class MigrationDbContextFactory : IDesignTimeDbContextFactory<MigrationDbContext>
    {
        public MigrationDbContext CreateDbContext(string[] args)
        {

            var basePath = Path.Combine(Directory.GetCurrentDirectory(), $"..\\Aurora.{CommonConstants.APIPrefix}.API");

            IConfiguration rootConfig = new ConfigurationBuilder()
                .SetBasePath(basePath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
               .AddEnvironmentVariables()
               .Build();

            var environment = rootConfig["env"]
                ?? throw new InvalidOperationException("Required configuration key 'env' is missing in appsettings.json.");



            IConfiguration appEnvConfig = new ConfigurationBuilder()
                .SetBasePath(basePath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true) // Reload main appsettings
                .AddJsonFile($"appsettings.{environment}.json", optional: true, reloadOnChange: true) // Load environment-specific settings
                .AddEnvironmentVariables()
                .Build();

            var vaultUri = appEnvConfig["VaultUri"];
            var identityClientId = appEnvConfig["IdentityClientId"];
            if (!string.IsNullOrEmpty(vaultUri) && !string.IsNullOrEmpty(identityClientId))
            {
                appEnvConfig = new ConfigurationBuilder()
                    .SetBasePath(basePath)
                    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                    .AddJsonFile($"appsettings.{environment}.json", optional: true, reloadOnChange: true)
                    .AddAzureKeyVault(
                        new Uri(vaultUri),
                        new DefaultAzureCredential(new DefaultAzureCredentialOptions
                        {
                            ExcludeSharedTokenCacheCredential = true,
                            ManagedIdentityClientId = identityClientId
                        }))
                    .AddEnvironmentVariables()
                    .Build();

                string? connectionString = MigrationManager.PrepareConnectionString("MYS", appEnvConfig);

                if (string.IsNullOrEmpty(connectionString))
                {
                    throw new InvalidOperationException("Connection string was not found.");
                }

                // Build DbContext options
                var optionsBuilder = new DbContextOptionsBuilder<MigrationDbContext>();
                optionsBuilder.UseSqlServer(connectionString);

            }
            return new MigrationDbContext(appEnvConfig);
        }
    }
}
